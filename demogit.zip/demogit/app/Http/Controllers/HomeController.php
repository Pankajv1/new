<?php

namespace App\Http\Controllers;

use App\Models\ActiveLicenses;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\CardDetail;
use App\Models\CustomerSubcription;
use Cartalyst\Stripe\Stripe;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Log;
use App\Models\Plans;
use Exception;
use DB;
use App\Models\CustomerInvoice;
use Illuminate\Support\Facades\Mail;
use Cartalyst\Stripe\Exception\NotFoundException;
use Cartalyst\Stripe\Exception\InvalidRequestException;
use Cartalyst\Stripe\Exception\UnauthorizedException;
use Cartalyst\Stripe\Exception\BadRequestException;
use Cartalyst\Stripe\Exception\ServerErrorException;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    private $stripe;
    public function __construct()
    {
        $this->stripe = Stripe::make(config('stripeapi.stripe.secret'));
       
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        try {
            if (Auth::user()->hasRole('customer')) {
                if (Session::has('previousUrl')) {
                    if (Session::has('previousUrl')) {
                        $plan = Session::get('plan_id');
                        Session::remove('plan_id');
                        Session::remove('previousUrl');
                    }
                    return redirect('purchase-plan/' . $plan);
                } else {
                    $data['activeLicense'] = ActiveLicenses::whereMonth('activation_date', date("m"))->where(['user_id' => Auth::user()->id])->whereDate('end_date', "<=", date("Y-m-d"))->get()->count();
                    return view('home')->with($data);
                }
            } else {
                Session::remove('plan_id');
                Session::remove('previousUrl');
            
                $allcustomer = User::role('customer')->orderBy('id', 'desc')->get();
                $customers = User::select('customer_invoices.subscription_start_date', 'customer_invoices.subscription_end_date', 
                'customer_invoices.id as invoice_id',
                'customer_invoices.status', 'users.id','users.first_name','users.email','users.company_name','users.phone')
                            ->Join('customer_invoices', function($join){ 
                                $join->on('customer_invoices.user_id', '=', 'users.id')
                                ->on('customer_invoices.id', '=', DB::raw("(SELECT max(id) from customer_invoices WHERE customer_invoices.user_id = users.id)")); 
                            })
                            ->where('customer_invoices.status', 'active')
                            ->role('customer')
                            ->orderBy('customer_invoices.user_id', 'desc')
                            ->get();
            
                $data['Activecustomers'] = count($customers);
                $data['InActivecustomers'] = count($allcustomer)-count($customers);
                $data['packages'] = Plans::where('status', 'Active')->get();
                $data['activeLicense'] = ActiveLicenses::whereMonth('activation_date', date("m"))->with('user')->orderBy('id', 'desc')->get();
                return view('home')->with($data);
            }
        } catch (\Exception $e) {
            Log::error("Error in HomeController method index : " . $e->getMessage());
            return redirect()->back()->with('error', 'Something went wrong. Please try again');
        }
    }
    
    /**
     * Method to redirect customer on successful payment
     */
    public function paymentSuccessful($subscription_id = 0, $invoice_id = 0, $header = "", $url = "", $subscription_status = "created") {
        try {
            $subscription = CustomerSubcription::where('id', base64_decode($subscription_id))->with('latestInvoice')->first();
            return view('message', ['subscription_details' => $subscription, 'header' => base64_decode($header), 'subscription_status' => $subscription_status]);
        } catch (\Exception $e) {
            Log::error("Error in HomeController method paymentSuccessful : " . $e->getMessage());
            return redirect(base64_decode($url))->with('error', 'Something went wrong. Please try again');
        }
    }

    /**
     * Method to create customer on Stripe
     */
    public function createStripeCustomer(Request $request)
    {
        try {
            $userID = auth()->user()->id;
            $stripeID =  auth()->user()->stripe_customer_id;
            $this->plan_id = $request->plan_id;
            $this->plan_amount = $request->plan_amount;
            $this->previousURL = url()->previous();
            if($request->has('card_id')) {
                $check_card_exist =   CardDetail::where('user_id',  $userID)->where('id',  $request->card_id)->first();
                $this->cno = base64_decode($check_card_exist->card_no);
                $this->exp_month = base64_decode($check_card_exist->exp_month);
                $this->exp_year = base64_decode($check_card_exist->exp_year);
            } else {
                $this->cardnumber =  $request->input('number');
                $this->cardnumber = trim(str_replace(" ", "", $this->cardnumber));
                $expiry =  explode('/', $request->input('expiry'));
                $this->cvc =  trim($request->input('cvc'));
                $this->name =  $request->input('name');
                $this->cno = substr(trim($this->cardnumber), -4);
                $this->exp_month = trim($expiry[0]);
                $this->exp_year = trim($expiry[1]);
            }
           

            if ($stripeID == "") {
                $customercreate = $this->stripe->customers()->create([
                    'email' => auth()->user()->email,
                ]);
                $user = User::find($userID);
                $user->stripe_customer_id  = $customercreate['id'];
                $user->update();
            }

            $cardfunction = $this->addCardInStripe();
           
            if ($cardfunction['status']) { // If card added successfully
                $subsriptionfunction = $this->subscribePlan();
                if ($subsriptionfunction['status']) {
                    if (is_array($subsriptionfunction) && !empty($subsriptionfunction)) {
                        if(str_contains($this->previousURL, 'update-plan')) {
                            $subsriptionfunction['header'] = "inside";
                        } else {
                            $subsriptionfunction['header'] = "outside";
                        }
                        return redirect('/success/'.base64_encode($subsriptionfunction['subscription_id']).'/'.base64_encode($subsriptionfunction['invoice_id']).'/'.base64_encode($subsriptionfunction['header']).'/'.base64_encode($this->previousURL).'/'.base64_encode($subsriptionfunction['subscription_status']));
                    } else {
                        return redirect()->back()->with('error', 'You have already subscribe');
                    }
                } else {
                    return redirect($this->previousURL)->with('error', $subsriptionfunction['message']);
                }
            } else {
                if($cardfunction['card_status']) {
                    return redirect($this->previousURL)->with('success', $cardfunction['message']);
                } else {
                    return redirect($this->previousURL)->with('error', $cardfunction['message']);
                }
                
            }
        } catch (NotFoundException $e) {
            Log::error("Error in Stripe (NotFoundException) HomeController method createStripeCustomer code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
            return redirect($this->previousURL)->with('error',  $e->getMessage());
        } catch (BadRequestException $e) {
            Log::error("Error in Stripe (BadRequestException) HomeController method createStripeCustomer code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
            return redirect($this->previousURL)->with('error',  $e->getMessage() );
        } catch (UnauthorizedException $e) {
            Log::error("Error in Stripe (UnauthorizedException) HomeController method createStripeCustomer code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
            return redirect($this->previousURL)->with('error',  $e->getMessage() );
        } catch (InvalidRequestException $e) {
            Log::error("Error in Stripe (InvalidRequestException) HomeController method createStripeCustomer code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
            return redirect($this->previousURL)->with('error',  $e->getMessage() );
        } catch (ServerErrorException $e) {
            Log::error("Error in Stripe (ServerErrorException) HomeController method createStripeCustomer code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
            return redirect($this->previousURL)->with('error',  $e->getMessage() );
        } catch (\Exception $e) {
            Log::error("Error in HomeController method createStripeCustomer : " . $e->getMessage());
            return redirect($this->previousURL)->with('error', 'Something went wrong. Please try again');
        }
    }
    
    /**
     * Method to save new card or make old card default
     */
    public function addCardInStripe() {
        try {
            $message = '';
            $userID = auth()->user()->id;
            $stripeID =  auth()->user()->stripe_customer_id;

            $Card_detail = new CardDetail;
            $check_card_exist =   $Card_detail::where('user_id',  $userID)->where('card_no',  base64_encode($this->cno))->first();
            $check_subscription = CustomerSubcription::where('user_id', $userID)->where('canceled_date', null)->first();
          
            $this->card_id = 0;
            if ($check_card_exist == null) {

                $Card_detail = new CardDetail;
                $token = $this->stripe->tokens()->create([
                    'card' => [
                        'number'    => $this->cardnumber,
                        'exp_month' => $this->exp_month,
                        'cvc'       => $this->cvc,
                        'exp_year'  => $this->exp_year,
                    ],
                ]);
                $card = $this->stripe->cards()->create($stripeID, $token['id']);
                $Card_detail->user_id = $userID;
                $Card_detail->card_id = $card['id'];
                $Card_detail->exp_month = base64_encode($card['exp_month']);
                $Card_detail->exp_year = base64_encode($card['exp_year']);
                $Card_detail->card_no = base64_encode($card['last4']);

                $Card_detail->save();
                $this->stripe->customers()->update($stripeID, [
                    'default_source' =>$card['id']
                ]);
                $this->card_id =  $Card_detail->id;
                $message = 'Your Card is Added for future Payment';
              
            } else {
                $this->stripe->customers()->update($stripeID, [
                    'default_source' => $check_card_exist->card_id
                ]);
                $this->card_id = $check_card_exist->id;
                $message = 'Your Card Already Added But Saved for Future Payment';    
            }
           
            if(!empty($check_subscription)) {
                if($this->plan_id == $check_subscription->plan_id) {
                    $check_subscription->card_id = $this->card_id;
                    $check_subscription->update();
                    $customer_invoice_update = CustomerInvoice::where('subscription_id',$check_subscription->id)->first();
                    $customer_invoice_update->card_id = $this->card_id;
                    $customer_invoice_update->update();
                    return $data = [
                        'message' =>  $message,
                        'card_status'=>true,
                        'status' => false
                    ];
                }
            }
           
            return $data = [
                'message' => "Card created successfully",
                'card_status' => true,
                'status' => true
            ];
        } catch (NotFoundException $e) {
            Log::error("Error in Stripe (NotFoundException) HomeController method addCardInStripe code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
            return $data = [
                'message' =>  $e->getMessage() ,
                'card_status'=> false,
                'status' => false
            ];
        } catch (BadRequestException $e) {
            Log::error("Error in Stripe (BadRequestException) HomeController method addCardInStripe code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
            return $data = [
                'message' => $e->getMessage() ,
                'card_status'=> false,
                'status' => false
            ];
        } catch (UnauthorizedException $e) {
            Log::error("Error in Stripe (UnauthorizedException) HomeController method addCardInStripe code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
            return $data = [
                'message' => $e->getMessage() ,
                'card_status'=> false,
                'status' => false
            ];
        } catch (InvalidRequestException $e) {
            Log::error("Error in Stripe (InvalidRequestException) HomeController method addCardInStripe code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
            return $data = [
                'message' =>  $e->getMessage() ,
                'card_status'=> false,
                'status' => false
            ];
        } catch (ServerErrorException $e) {
            Log::error("Error in Stripe (ServerErrorException) HomeController method addCardInStripe code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
            return $data = [
                'message' => $e->getMessage(),
                'card_status'=> false,
                'status' => false
            ];
        } catch (\Exception $e) {
            Log::error("Error in HomeController method addCardInStripe : " . $e->getMessage());
            return $data = [
                'message' => "Error in adding card - " . $e->getMessage(),
                'card_status'=> false,
                'status' => false
            ];
        }
    }

    /**
     * Method for random license number
     */
    function generateRandomString($length = 64) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString.time();
    }

    /**
     * Method for create & update subscription
     */
    function subscribePlan()
    {
        try {

            $plan = Plans::find($this->plan_id);
            $userID = auth()->user()->id;
            $licensekey =  $this->generateRandomString(); // generate license key
            $stripeID = auth()->user()->stripe_customer_id;
            $check_subscription = CustomerSubcription::where('user_id', $userID)->where('canceled_date', null)->first();
            if ($check_subscription == null) {

                // Create subscription for user
                $subscription = $this->stripe->subscriptions()->create($stripeID, [
                    'plan' => $plan->stripe_plan_id,
                ]);

                // Save customer subscription data
                $subcription = new CustomerSubcription;
                $subcription->user_id = $userID;
                $subcription->card_id = $this->card_id;
                $subcription->plan_id = $plan->id;
                $subcription->stripe_subscription_id = $subscription['id'];
                $subcription->license_key = $licensekey;
                $subcription->save();

                $this->subscriptionID =  $subcription->id;

                $this->invoice = $this->stripe->invoices()->find($subscription['latest_invoice']); // Get the latest invoice from Stripe

                // Save customer subscription invoice data
                $customer_invoice = new CustomerInvoice;
                $customer_invoice->user_id = $userID;
                $customer_invoice->subscription_id = $this->subscriptionID;
                $customer_invoice->plan_id = $plan->id;
                $customer_invoice->card_id = $this->card_id;
                $customer_invoice->invoice_id = $subscription['latest_invoice'];
                $customer_invoice->invoice_details = json_encode($this->invoice);
                $customer_invoice->subscription_start_date = date('Y-m-d', $subscription['current_period_start']);
                $customer_invoice->subscription_end_date =  date('Y-m-d', $subscription['current_period_end']);
                $customer_invoice->status = $subscription['status'];
                $customer_invoice->save();

                // Send Email to customer
                $this->sendRecieptEmail();

                $this->subscription_details = array();
                $this->subscription_details['subscription_id'] = $subcription->id;
                $this->subscription_details['invoice_id'] = $customer_invoice->id;
                $this->subscription_details['subscription_status'] = 'created';
                $this->subscription_details['status'] =  true;
                return  $this->subscription_details;
            } elseif (($check_subscription->plan_id != $this->plan_id) || ($check_subscription->card_id != $this->card_id)) {

                // Get the old license key
                $licensekey = $check_subscription->license_key;
                $old_invoice_id = $check_subscription->latestInvoice->id;
            
               
                if($check_subscription->stripe_subscription_id == null)
                {
                    $subscription = $this->stripe->subscriptions()->create($stripeID, [
                        'plan' => $plan->stripe_plan_id,
                    ]);
                }
               else
               {
                $subscription =  $this->stripe->subscriptions()->update($stripeID,  $check_subscription->stripe_subscription_id, [
                    'plan' => $plan->stripe_plan_id,
                ]);

               }
                // Update the customer data
                $subcription = CustomerSubcription::find($check_subscription->id);
                $subcription->card_id = $this->card_id;
                $subcription->plan_id = $plan->id;
                $subcription->stripe_subscription_id = $subscription['id'];
                $subcription->update();

                $this->subscriptionID = $check_subscription->id;
                $this->invoice = $this->stripe->invoices()->find($subscription['latest_invoice']);

                // Update old Invoice
                $oldInvocie = CustomerInvoice::find($old_invoice_id);
                $oldInvocie->status = 'cancel';
                $oldInvocie->canceled_date = date("Y-m-d H:i:s");
                $oldInvocie->save();

                // Save customer subscription invoice data
                $customer_invoice = new CustomerInvoice;
                $customer_invoice->user_id = $userID;
                $customer_invoice->subscription_id = $this->subscriptionID;
                $customer_invoice->plan_id = $plan->id;
                $customer_invoice->card_id = $this->card_id;
                $customer_invoice->invoice_id = $subscription['latest_invoice'];
                $customer_invoice->invoice_details = json_encode($this->invoice);
                $customer_invoice->subscription_start_date = date('Y-m-d', $subscription['current_period_start']);
                $customer_invoice->subscription_end_date =  date('Y-m-d', $subscription['current_period_end']);
                $customer_invoice->status = $subscription['status'];
                $customer_invoice->save();

                $this->sendRecieptEmail();

                $this->subscription_details = array();
                $this->subscription_details['subscription_id'] = $subcription->id;
                $this->subscription_details['invoice_id'] = $customer_invoice->id;
                $this->subscription_details['subscription_status'] = 'updated';
                $this->subscription_details['status'] =  true;

                return $this->subscription_details;
            } else {
                $this->subscription_details = array('message' => 'You have already subscribed.', 'status' => false);
                return $this->subscription_details;
            }
        } catch (NotFoundException $e) {
            Log::error("Error in Stripe (NotFoundException) HomeController method subscribePlan code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
            return $data = [
                'message' => $e->getMessage() ,
                'status' => false
            ];
        } catch (BadRequestException $e) {
            Log::error("Error in Stripe (BadRequestException) HomeController method subscribePlan code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
            return $data = [
                'message' =>  $e->getMessage() ,
                'status' => false
            ];
        } catch (UnauthorizedException $e) {
            Log::error("Error in Stripe (UnauthorizedException) HomeController method subscribePlan code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
            return $data = [
                'message' =>  $e->getMessage(),
                'status' => false
            ];
        } catch (InvalidRequestException $e) {
            Log::error("Error in Stripe (InvalidRequestException) HomeController method subscribePlan code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
            return $data = [
                'message' =>  $e->getMessage() ,
                'status' => false
            ];
        } catch (ServerErrorException $e) {
            Log::error("Error in Stripe (ServerErrorException) HomeController method subscribePlan code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
            return $data = [
                'message' => $e->getMessage() ,
                'status' => false
            ];
        } catch (\Exception $e) {
            Log::error("Error in HomeController method subscribePlan : " . $e->getMessage() . ' line no - ' . $e->getLine());
            return $data = [
                'message' => "Error in subscription - " . $e->getMessage(),
                'status' => false
            ];
        }
    }
    /**
     * Method for to show plan details for purchase
     */
      public function purchasePlan($plan_id = 0)
    {
        try 
        {
          
            $userID = auth()->user()->id;
           
            $plan = Plans::find($plan_id);
            if($plan == null)
            {
                return view('error.404');
            }
            $customerstripeID =  auth()->user()->stripe_customer_id;
            $subscription = CustomerSubcription::where('user_id', $userID)->where('canceled_date', null)->with('latestInvoice')->first();
            if($subscription != null  && $subscription->stripe_customer_id != null)
            {
                
                \Stripe\Stripe::setApiKey(config('stripeapi.stripe.secret'));
                $proration_date = time();
                $subscription_details = \Stripe\Subscription::retrieve($subscription->stripe_subscription_id);
                $items = [
                [
                    'id' => $subscription_details->items->data[0]['id'],
                    'price' => $plan->stripe_plan_id, # Switch to new price
                ],
                
                ];
                $invoice = \Stripe\Invoice::upcoming([
                'customer' => $customerstripeID,
                'subscription' => $subscription->stripe_subscription_id,
                'subscription_items' => $items,
                'subscription_proration_date' => $proration_date,
                ]);
                $subscription['amount_due'] = $invoice->amount_due;
           }

       
            return view('card', ['plan' => $plan, 'subscription' => $subscription]);
        } catch (\Exception $e) {
            Log::error("Error in HomeController method purchasePlan : " . $e->getMessage());
            return redirect()->back()->with('error', 'Plan not found');
        }
    }

    /**
     * Method for cancelling the subscription
     */
     public function cancelSubscription($subscriptionId = '')
    {
        try {
            $subscription_id = base64_decode($subscriptionId);
            $usersubscription = CustomerSubcription::where('id', $subscription_id)->with('user')->first();
            $cancel_customer_subscription = CustomerSubcription::find($usersubscription->id);
            if ($usersubscription == null) {
                return back()->with('error', 'Subscription not found.');
            }

            $stripe_customerID =  $usersubscription->user->stripe_customer_id;
            $subscriptionID = $usersubscription->stripe_subscription_id;
            $this->subscriptionId = $subscription_id;
            $cancel_subscription = array();
            if( $usersubscription->stripe_subscription_id == null)
            { 
                $cancel_subscription['canceled_at'] = strtotime(date('Y-m-d H:i:s'));
                $cancel_subscription['status'] = 'cancel';
            }
            else
            {
                $cancel_subscription = $this->stripe->subscriptions()->cancel($stripe_customerID, $subscriptionID);
            }
          
            if (is_array($cancel_subscription) && (!empty($cancel_subscription))) {
               
                $cancel_customer_subscription->canceled_date = date('Y-m-d H:i:s', $cancel_subscription['canceled_at']);
             
                $cancel_customer_subscription->update();

                $subscription_invoice = CustomerInvoice::where('subscription_id', $subscription_id)->orderBy('id', 'DESC')->first();
                $subscriptionInvoiceupdate = CustomerInvoice::find($subscription_invoice->id);
                $subscriptionInvoiceupdate->canceled_date = date('Y-m-d H:i:s', $cancel_subscription['canceled_at']);
                $subscriptionInvoiceupdate->status = $cancel_subscription['status'];
                $subscriptionInvoiceupdate->update();

                $this->sendCancelSubscriptionEmail();
                return redirect('/my-plans')->with('success', 'Subscription canceled Successfully.');
            } else {
                return redirect('/my-plans')->with('error', 'Something went wrong. Subscripition did not Canceled');
            }
        } catch (NotFoundException $e) {
            Log::error("Error in Stripe (NotFoundException) HomeController method cancelSubscription code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
            return redirect()->back()->with('error',  $e->getMessage() );
        } catch (BadRequestException $e) {
            Log::error("Error in Stripe (BadRequestException) HomeController method cancelSubscription code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
            return redirect()->back()->with('error', $e->getMessage());
        } catch (UnauthorizedException $e) {
            Log::error("Error in Stripe (UnauthorizedException) HomeController method cancelSubscription code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
            return redirect()->back()->with('error',  $e->getMessage());
        } catch (InvalidRequestException $e) {
            Log::error("Error in Stripe (InvalidRequestException) HomeController method cancelSubscription code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
            return redirect()->back()->with('error',  $e->getMessage() );
        } catch (ServerErrorException $e) {
            Log::error("Error in Stripe (ServerErrorException) HomeController method cancelSubscription code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
            return redirect()->back()->with('error',  $e->getMessage() );
        } catch (\Exception $e) {
            Log::error("Error in HomeController method cancelSubscription : " . $e->getMessage());
            return redirect()->back()->with('error', 'Something went wrong. Please try again');
        }
    }
    /**
     * Method for sending email on cancel subscription
     */
   public function sendCancelSubscriptionEmail() {
        try {

            $subcriptiondetails = CustomerSubcription::where('id', $this->subscriptionId)->with('plan')->with("latestInvoice")->first();
            if($subcriptiondetails->plan->duration == "trial")
            {
                $this->invoice['hosted_invoice_url'] ='';
            }
            else
            {
                $this->invoice =  $this->stripe->invoices()->find($subcriptiondetails->latestInvoice->invoice_id);
                $this->receipt_no = $this->invoice['receipt_number'];
            }
           
            $this->plan_type = $subcriptiondetails->plan->name;
            $data = array(
                'name' => auth()->user()->first_name,
                'url' => $this->invoice['hosted_invoice_url'],
                'subscription_id' => $subcriptiondetails->stripe_subscription_id,
                'start_date' => $subcriptiondetails->latestInvoice->subscription_start_date,
                'end_date' => $subcriptiondetails->latestInvoice->subscription_end_date,
                'license_key' => $subcriptiondetails->license_key,
                'Plan_name' => $subcriptiondetails->plan->name,
                'amount' => $subcriptiondetails->plan->amount,
                'cancel_date' => $subcriptiondetails->latestInvoice->subscription_end_date
            );

            Mail::send('email.cancel-subscription-email', ['user' => $data], function ($message)  use ($data) {
                $message->to(auth()->user()->email)->subject("Your " . ucfirst($this->plan_type) . " Subscription From B-soft Technology Canceled successfully");
                $message->from('pankajv@chetu.com', auth()->user()->first_name);
            });
        } catch (\Exception $e) { 
            Log::error("Error in HomeController method sendCancelSubscriptionEmail : " . $e->getMessage());
        }
    }
    
    /**
     * Method to send reciept on email
     */
    public function sendRecieptEmail()
    {
        try {
            $subcriptiondetails = CustomerSubcription::where('id', $this->subscriptionID)->with('latestInvoice')->with('plan')->first();
            $this->invoice =  $this->stripe->invoices()->find($subcriptiondetails->latestInvoice->invoice_id);
            $this->receipt_no = $this->invoice['receipt_number'];
            $this->plan_type = $subcriptiondetails['plan_name'];
            $data = array(
                'name' => auth()->user()->first_name,
                'url' => $this->invoice['hosted_invoice_url'],
                'subscription_id' => $subcriptiondetails->stripe_subscription_id,
                'start_date' => $subcriptiondetails->latestInvoice->subscription_start_date,
                'end_date' => $subcriptiondetails->latestInvoice->subscription_end_date,
                'license_key' => $subcriptiondetails->license_key,
                'Plan_name' => $subcriptiondetails->plan->name,
                'amount' => $subcriptiondetails->plan->amount
            );

            Mail::send('email.receipt-email', ['user' => $data], function ($message)  use ($data) {
                $message->to(auth()->user()->email)->subject("Your " . ucfirst($this->plan_type) . " Subscription From B-soft Technology Receipt #" . $this->receipt_no);
                $message->from('pankajv@chetu.com', auth()->user()->first_name);
            });
        } catch (\Exception $e) {
            Log::error("Error in HomeController method sendRecieptEmail : " . $e->getMessage());
        }
    }


    // public function subscription_invoice()
    // {
    //     try {
    //         $subcription_details  = CustomerSubcription::find(1);
    //         $invoice_detials =  $this->stripe->invoices()->find($subcription_details['invoice_id']);

    //         $receipt_array = array();
    //         $receipt_array['invoice_number'] = $invoice_detials['number'];
    //         $receipt_array['account_name'] = $invoice_detials['account_name'];
    //         $receipt_array['customer_email'] = $invoice_detials['customer_email'];
    //         $receipt_array['receipt_number'] = $invoice_detials['receipt_number'];
    //         $receipt_array['starting_balance'] = $invoice_detials['starting_balance'];
    //         $receipt_array['amount_paid'] = $invoice_detials['amount_paid'];
    //         $receipt_array['created'] = date('M d,Y', $invoice_detials['created']);
    //         $invoice_line_item = $invoice_detials['lines']['data'];
    //         $invoice_line_item_array = array();

    //         foreach ($invoice_line_item as $key => $value) {
    //             if ($value['description'] == "") {
    //                 $invoice_line_item_array[$key]['description'] = $value['plan']['name'];
    //             } else {
    //                 $invoice_line_item_array[$key]['description'] = $value['description'];
    //             }
    //             $invoice_line_item_array[$key]['amount'] = $value['amount'];
    //             $invoice_line_item_array[$key]['start'] = $value['period']['start'];
    //             $invoice_line_item_array[$key]['end'] = $value['period']['end'];
    //         }
    //         $invoice_line_item_array = array_reverse($invoice_line_item_array);
    //         $receipt_array['invoice_line_item'] = $invoice_line_item_array;
    //         $paymentIntent = $this->stripe->paymentIntents()->find('pi_3LI8AxHXrgHrQUUp1R09I9YZ');
    //         $receipt_array['cardname'] = $paymentIntent['charges']['data'][0]['payment_method_details']['card']['brand'];
    //         $receipt_array['lastdigit'] = $paymentIntent['charges']['data'][0]['payment_method_details']['card']['last4'];

    //         return view('user/invoice', compact('receipt_array'));
    //     } catch (Exception $e) {
    //         Log::error("Error in HomeController method subscription_invoice : " . $e->getMessage());
    //     }
    // }

    /**
     * Method to handle stripe events through webhook
     */
    public function webhook(Request $request) {
        // This is your Stripe CLI webhook secret for testing your endpoint locally.
		 Log::info('welcome webhook');
		 Log::info($request);
        $endpoint_secret = 'whsec_IYKz6LbleMNvIFpqvvzPwjnEjn2gU88W';
   
        $payload = @file_get_contents('php://input');
        $sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'];
        $event = null;

        try {
            $event = \Stripe\Webhook::constructEvent(
                $payload,
                $sig_header,
                $endpoint_secret
            );
        } catch (\UnexpectedValueException $e) {
            // Invalid payload
            Log::info('Invalid payload');
            http_response_code(400);
            exit();
        } catch (\Stripe\Exception\SignatureVerificationException $e) {
            // Invalid signature
            Log::info('Invalid signature');
            http_response_code(400);
            exit();
        }

     
		switch ($event->type) {
		    case 'invoice.paid':
                $invoice = $event->data->object;
                $customer_subscriptionId = $invoice->subscription;
                $customerdetails = CustomerSubcription::where('stripe_subscription_id',$customer_subscriptionId)->with('latestInvoice')->first();
                $checkinvoice = CustomerInvoice::where('invoice_id',$invoice->id)->first();
                if ($checkinvoice == null) {       
                        $invoiceupdate = CustomerInvoice::find($customerdetails->latestInvoice->id);
                        $invoiceupdate->status =  'expired';
                        $invoiceupdate->update();
                        $this->subscriptionID = $customerdetails->id;
                        $saveinvoice = new CustomerInvoice;
                        $saveinvoice->user_id = $customerdetails->latestInvoice->user_id;
                        $saveinvoice->subscription_id = $customerdetails->latestInvoice->subscription_id;
                        $saveinvoice->plan_id = $customerdetails->latestInvoice->plan_id;
                        $saveinvoice->card_id = $customerdetails->latestInvoice->card_id;
                        $saveinvoice->invoice_id = $invoice->id;
                        $saveinvoice->invoice_details = json_encode($invoice);
                        $saveinvoice->subscription_start_date =  date('Y-m-d', $invoice->lines->data[0]->period->start);
                        $saveinvoice->subscription_end_date =  date('Y-m-d', $invoice->lines->data[0]->period->end);
                        $saveinvoice->status =  $invoice->status;
                        $saveinvoice->save();
                        $this->sendRecieptEmail();
                        
                        Log::info('successs');
                        Log::info($invoice);
                } else {
                    Log::info('Invoice already exist');
				}
			    break;
		    case 'invoice.payment_failed':
                
                $invoice = $event->data->object;
                $customer_subscriptionId = $invoice->subscription;
                $customerdetails = CustomerSubcription::where('stripe_subscription_id',$customer_subscriptionId)->with('latestInvoice')->first();
                $checkinvoice = CustomerInvoice::where('invoice_id',$invoice->id)->first();
                $this->userID = $customerdetails->user_id;
                $this->planID = $customerdetails->plan_id;
                if ($checkinvoice == null) {
                    $invoiceupdate = CustomerInvoice::find($customerdetails->latestInvoice->id);
                    $invoiceupdate->status =  'expired';
                    $invoiceupdate->update();
                    $this->subscriptionID = $customerdetails->id;
                    $saveinvoice = new CustomerInvoice;
                    $saveinvoice->user_id = $customerdetails->latestInvoice->user_id;
                    $saveinvoice->subscription_id = $customerdetails->latestInvoice->subscription_id;
                    $saveinvoice->plan_id = $customerdetails->latestInvoice->plan_id;
                    $saveinvoice->card_id = $customerdetails->latestInvoice->card_id;
                    $saveinvoice->invoice_id = $invoice->id;
                    $saveinvoice->invoice_details = json_encode($invoice);;
                    $saveinvoice->subscription_start_date =  date('Y-m-d', $invoice->lines->data[0]->period->start);
                    $saveinvoice->subscription_end_date =  date('Y-m-d', $invoice->lines->data[0]->period->end);
                    $saveinvoice->canceled_date =  date('Y-m-d h:i:s');
                    $saveinvoice->status =  $invoice->status;
                    $saveinvoice->save();
                    $update_subscription = CustomerSubcription::find($customerdetails->id);
                    $update_subscription->canceled_date= date('Y-m-d h:i:s');
                    $update_subscription->update();
                    $this->sendRecieptEmailcancelplan();
                    Log::info('successs');
					Log::info($invoice);
			    } else{
				    Log::info('Invoice already exist');
				}
		        break;
            default:
                Log::info('default');
                echo 'Received unknown event type ' . $event->type;
        }
        http_response_code(200);
    }
    
    
    function sendRecieptEmailcancelplan() {
        try {
            $user = user::find($this->userID);
            $this->Plan = Plans::find($this->planID);
            $this->useremail = $user->email;
            $this->first_name = $user->first_name;
            Mail::raw('Dear,'.$this->first_name.' Your subscription Plan '. $this->Plan->name. ' payment has been failed!', function ($message) {
                $message->to($this->useremail)->subject('Cancel Your Subscription Plan'. $this->Plan->name);
            });
        } catch (Exception $e) {
            Log::error("Error in HomeController method sendRecieptEmailcancelplan : " . $e->getMessage());
        }
    }
}
