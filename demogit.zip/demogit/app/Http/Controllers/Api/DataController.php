<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\CustomerSubcription;
use App\Models\ActiveLicenses;
use Illuminate\Support\Facades\Log;

class DataController extends Controller
{

    /**
     *This function is used to add active license
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function activeLicenses(Request $request)
    {
        try {
          
            $validator = Validator::make($request->all(), [
                'licence_key' => 'required',
                'email' => 'required',
            ]);
            if ($validator->fails()) {
                return response()->json(['data' => [], 'code' => 400, 'status' => false, 'message' => 'Bad Request'], 400);
            }
            $domain = request()->getHost();
            $checkLicenceKey = CustomerSubcription::where('license_key', $request->licence_key)->with('plan')->with('latestActiveInvoice')->withCount('licenses')->first();
            
            $user = User::where('email', $request->email)->first();
            
            $activeLicence = ActiveLicenses::where('license_key', $request->licence_key)->where('domain_name', $domain)->get()->count();

            //validaton if license key is valid or not
            if ($checkLicenceKey !== null) {
                $licenseUser = User::find($checkLicenceKey->user_id);
                //validation if user is exists or not
                if ($user !== null) {

                    // Check if entered email & licensed email is matched
                    if($user->id !== $licenseUser->id) {
                        return response()->json(['message' => 'License and email details not matched', 'status' => false, 'code' => 201], 201);    
                    }

                    // Check if license is active or not
                    if($checkLicenceKey->latestActiveInvoice === null) {
                        return response()->json(['message' => 'License expired', 'status' => false, 'code' => 201], 201); 
                    }

                    // Check if license is expired
                    if(strtotime($checkLicenceKey->latestActiveInvoice->subscription_end_date) < strtotime(date("Y-m-d"))) {
                        return response()->json(['message' => 'License expired', 'status' => false, 'code' => 201], 201); 
                    }

                    // Check active license count
                    $checkActiveLicense = ActiveLicenses::leftjoin('customer_subscription', 'customer_subscription.id', '=', 'active_licenses.subscription_id')->leftjoin('customer_invoices', 'customer_invoices.subscription_id', '=', 'customer_subscription.id')->where('customer_subscription.id', $checkLicenceKey->id)->whereDate('customer_invoices.subscription_end_date', ">=" ,date("Y-m-d"))->where('customer_invoices.status', 'active')->where('customer_invoices.canceled_date', NULL)->get()->count();
                    
                    //validation if total no of domains already added
                    if ($checkLicenceKey->plan->no_of_domains > $checkActiveLicense) {

                        //check duplicate data in active_licenses
                        if ($activeLicence == 0) {

                            $data = [
                                'user_id' => $user->id,
                                'subscription_id' => $checkLicenceKey->id,
                                'domain_name' => $domain,
                                'license_key' => $request->licence_key,
                                'activation_date' => date('Y-m-d'),
                                'end_date' => $checkLicenceKey->latestActiveInvoice->subscription_end_date
                            ];
                            
                            ActiveLicenses::create($data); //store data in active_licenses
                            return response()->json(['message' => 'License and Domain added successfully', 'status' => true, 'code' => 200], 200);
                        } else {
                            return response()->json(['message' => 'License and Domain already Added', 'status' => false, 'code' => 201], 201);
                        }
                    } else {
                        return response()->json(['message' => 'You have used maximum number of domains for this license key', 'status' => false, 'code' => 201], 201);
                    }
                } else {
                    return response()->json(['message' => 'User Not Found', 'status' => false, 'code' => 201], 201);
                }
            } else {
                return response()->json(['message' => 'Invalid Licence Key', 'status' => false, 'code' => 201], 201);
            }
        } catch (\Exception $e) {
            Log::error("Error in DataController on activeLicenses method - ".$e->getMessage());
            return $response = ['code' => 500, 'message' => 'Internal Server Error. Contact Admin', 'status' => false];
        }
    }

    /**
     *This function is used to check expiration of license
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function checkLicense(Request $request)
    {
        try {
            $parentData = CustomerSubcription::where('license_key', $request->licence_key)->with('latestActiveInvoice')->first();
            $domain = request()->getHost();
            $activeLicence = ActiveLicenses::where('license_key', $request->licence_key)->where('domain_name', $domain)->first();
            if ($parentData === null) {
                return $response = ['message' => 'Invalid License Key', 'status' => false, 'code' => 202];
            } elseif($parentData->latestActiveInvoice !== null && strtotime($parentData->latestActiveInvoice->subscription_end_date) < strtotime(date("Y-m-d"))) {
                return $response = ['message' => 'License Has been Expired', 'status' => false, 'code' => 201];
            } else {
                if ($activeLicence === null) {
                    return $response = ['message' => 'Domain or License not verified', 'status' => false, 'code' => 201];
                } else {
                    return $response = ['message' => 'License is valid till ' . $parentData->latestActiveInvoice->subscription_end_date, 'status' => true, 'code' => 200];
                }
            }
        } catch (\Exception $e) {
            Log::error("Error in DataController on checkLicense method - ".$e->getMessage());
            return $response = ['message' => 'Internal Server Error. Contact Admin Team.', 'status' => false, 'code' => 500];
        }
    }
}
