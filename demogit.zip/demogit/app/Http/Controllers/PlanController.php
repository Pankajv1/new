<?php

namespace App\Http\Controllers;

use App\Models\Plans;
use Illuminate\Http\Request;
use Cartalyst\Stripe\Stripe;
use App\Models\CustomerSubcription;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Cartalyst\Stripe\Exception\NotFoundException;
use Cartalyst\Stripe\Exception\InvalidRequestException;
use Cartalyst\Stripe\Exception\UnauthorizedException;
use Cartalyst\Stripe\Exception\BadRequestException;
use Cartalyst\Stripe\Exception\ServerErrorException;
use App\Models\CardDetail;
use App\Models\CustomerInvoice;
use Illuminate\Support\Facades\Mail;

class PlanController extends Controller
{
    private $stripe;

    public function __construct()
    {
        $this->stripe = Stripe::make(config('stripeapi.stripe.secret'));
    }


    public function index()
    {
        $plans = Plans::orderBy('id', 'desc')->withCount('subscriptions')->get();
        return view('admin/plan/index', ['plans' => $plans]);
    }

    public function addPackage()
    {
        return view('admin/plan/add_plan');
    }

     public function savePackage(Request $request)
    {
        try {
            if ($request->duration == "trial") {
                $validator = Validator::make($request->all(), [
                    'name' => 'required|unique:plans,name,NULL,id,deleted_at,NULL',
                    'amount' => 'required',
                    'no_of_domains' => 'required|integer|min:1',
                    'duration' => 'required|unique:plans,duration,NULL,id,deleted_at,NULL',
                    'trial_days' => 'required|integer|min:1',
                    'features' => 'required',
                ]);
            } else {
                $validator = Validator::make($request->all(), [
                    'name' => 'required|unique:plans,name,NULL,id,deleted_at,NULL',
                    'amount' => 'required',
                    'no_of_domains' => 'required|integer|min:1',
                    'duration' => 'required|unique:plans,duration,NULL,id,deleted_at,NULL',
                    'features' => 'required',
                ]);
            }

            if ($validator->fails()) {
                return back()->withErrors($validator)->withInput();
            }
           
            $plan = new Plans;
            $plan->name = $request->name;
            $plan->amount = $request->amount;
            $plan->no_of_domains = $request->no_of_domains;
            $plan->duration = $request->duration;
            $plan->features = json_encode($request->features);
            $planduration = $request->duration;
            if ($request->duration != "trial") {
                $stripeplan = [
                    'name' => $plan->name,
                    'amount'  => trim(intval($plan->amount)),
                    'currency' => 'USD',
                    'interval'  => ($planduration == "month" || $planduration == "Every 3 Month" || $planduration == "Every 6 Month") ? 'month' : $planduration
                ];
                if ($request->duration == "Every 3 Month") {
                    $stripeplan['interval_count'] = 3;
                } elseif ($request->duration == "Every 6 Month") {
                    $stripeplan['interval_count'] = 6;
                }

                $create_stripe_plan =  $this->stripe->plans()->create($stripeplan);
                if (!empty($create_stripe_plan) && is_array($create_stripe_plan)) {
                    $plan->stripe_plan_id =  $create_stripe_plan['id'];
                    $plan->status =  'Active';
                    $plan->save();
                    return redirect('/packages')->with('success', 'Package created Successfully.');
                } else {
                    return redirect('/packages')->with('error', 'Package Not Insert Something Went Wrong');
                }
            } else {


                $plan->stripe_plan_id = '';
                $plan->status =  'InActive';
                $plan->trial_days =  $request->trial_days;
                $plan->save();
                return redirect('/packages')->with('success', 'Package created Successfully.');
            }
        } catch (NotFoundException $e) {
            Log::error("Error in Stripe (NotFoundException) PlanController method savePackage code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
            return redirect()->back()->with('error', "Error in Stripe (NotFoundException) code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
        } catch (BadRequestException $e) {
            Log::error("Error in Stripe (BadRequestException) PlanController method savePackage code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
            return redirect()->back()->with('error', "Error in Stripe (BadRequestException) code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
        } catch (UnauthorizedException $e) {
            Log::error("Error in Stripe (UnauthorizedException) PlanController method savePackage code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
            return redirect()->back()->with('error', "Error in Stripe (UnauthorizedException) code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
        } catch (InvalidRequestException $e) {
            Log::error("Error in Stripe (InvalidRequestException) PlanController method savePackage code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
            return redirect()->back()->with('error', "Error in Stripe (InvalidRequestException) code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
        } catch (ServerErrorException $e) {
            Log::error("Error in Stripe (ServerErrorException) PlanController method savePackage code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
            return redirect()->back()->with('error', "Error in Stripe (ServerErrorException) code - " . $e->getCode() . " , message - " . $e->getMessage() . " , type - " . $e->getErrorType());
        } catch (\Exception $e) {
            Log::error("Error in PlanController method savePackage : " . $e->getMessage() . ' on line no - ' . $e->getLine());
            return redirect()->back()->with('error', 'Something went wrong. Please try again');
        }
    }


    public function editPackage($id = 0)
    {
        $plane = Plans::find($id);
	//	dd($plane);
        return view('admin/plan/edit_plan', ['planeUser' => $plane]);
    }

     public function updatePackage(Request $request, $id = 0)
    {
        try {
            
            if ($request->check_duration == "trial") {

                $validator = Validator::make($request->all(), [
                    'name' => 'required|unique:plans,name,NULL,id,deleted_at,NULL,name,' . $id,
                    'no_of_domains' => 'required|integer|min:1',
                    'features' => 'required',
                    'trial_days' => 'required|min:1',
                ]);
            } else {
                $validator = Validator::make($request->all(), [
                   'name' => 'required|unique:plans,name,NULL,id,deleted_at,NULL,name,' . $id,
                    'no_of_domains' => 'required|integer|min:1',
                    'features' => 'required',
                ]);
            }
           
            if ($validator->fails()) {
				
                return back()->withErrors($validator)->withInput();
            }
    
            $plan = Plans::find($id);
            $plan->name = $request->name;
            $plan->no_of_domains = $request->no_of_domains;
            $plan->features = json_encode($request->features);
             
            if ($request->check_duration != "trial") {
                $planupdate = $this->stripe->plans()->update($plan->stripe_plan_id, ['name' => $request->name]);

                if (!empty($planupdate)) {
                    $plan->update();
                    return redirect('/packages')->with('success', 'Package details Updated Successfully');
                } else {
                    return redirect()->back()->with('error', 'Something went wrong. Please try again');
                }
            } else {
                $plan->trial_days = $request->trial_days;
                $plan->update();
                return redirect('/packages')->with('success', 'Package details Updated Successfully');
            }
        } catch (\Exception $e) {
            Log::error("Error in PlanController method updatePackage : " . $e->getMessage());
            return redirect()->back()->with('error', 'Something went wrong. Please try again');
        }
    }

   public function deletePackage($id = 0)
    {
        try {


            $plan = Plans::find($id);
            $this->plan_name = $plan->name;
            if ($plan->duration != "trial") {
                $delete_stripe_plan = $this->stripe->plans()->delete($plan->stripe_plan_id);
                if (is_array($delete_stripe_plan) && !empty($delete_stripe_plan)) {
                    $plan->delete();
                    $subscription_customer_list = CustomerSubcription::where('plan_id', $id)->where('canceled_date', null)->with('user')->get();
                    foreach ($subscription_customer_list as $key => $cusmtoerdetails) {

                        $this->useremail = $cusmtoerdetails->user->email;
                        $this->first_name = $cusmtoerdetails->user->first_name;

                        Mail::raw('Dear,' . $this->first_name . ' Your subscription Plan ' . $this->plan_name . ' has been Deleted! If you want to continue Please visit Website and select Plan', function ($message) {
                            $message->to($this->useremail)->subject('Deleted Subscription Plan' . $this->plan_name);
                        });
                    }
                    return redirect()->back()->with('status', 'Plan details Deleted Successfully');
                } else {

                    return redirect()->back()->with('error', 'Somthing Wend Wrong');
                }
            } else {
                $plan->delete();
                $subscription_customer_list = CustomerSubcription::where('plan_id', $id)->where('canceled_date', null)->with('user')->get();
                foreach ($subscription_customer_list as $key => $cusmtoerdetails) {

                    $this->useremail = $cusmtoerdetails->user->email;
                    $this->first_name = $cusmtoerdetails->user->first_name;

                    Mail::raw('Dear,' . $this->first_name . ' Your subscription Plan ' . $this->plan_name . ' has been Deleted! If you want to continue Please visit Website and select Plan', function ($message) {
                        $message->to($this->useremail)->subject('Deleted Subscription Plan' . $this->plan_name);
                    });
                }
                return redirect()->back()->with('status', 'Plan details Deleted Successfully');
            }
        } catch (\Exception $e) {
            Log::error("Error in PlanController method deletePackage : " . $e->getMessage());
            return redirect()->back()->with('error', 'Something went wrong. Please try again');
        }
    }



    public function subscriptionPlan()
    {
        $plans = Plans::where('status', 'Active')->get();
        return view('subscription-plan', ['plans' => $plans]);
    }

     public function myPlans()
    {
        try {
            $plans = Plans::where('status', 'Active')->get();
            $delete_plans = null;
            $subscription = CustomerSubcription::where('user_id', Auth::user()->id)->where('canceled_date', null)->with('latestInvoice')->orderBy('customer_subscription.id', 'desc')->first();
            if ($subscription !== null) {
                $delete_plans = Plans::withTrashed()->where('id', $subscription->plan_id)
                    ->Where(function ($query) {
                        $query->where('deleted_at', '<>', null)->orWhere('status', 'InActive');
                    })
                    ->get();
            }
            return view('customers.my-plans', ['plans' => $plans, 'subscription' => $subscription, 'delete_plan' => $delete_plans]);
        } catch (\Exception $e) {
            Log::error("Error in PlanController method myPlans : " . $e->getMessage());
            return redirect()->back()->with('error', 'Something went wrong. Please try again');
        }
    }

    public function showUpdatePlan($subscription_id = 0)
    {
        try {
            $subscription_id = base64_decode($subscription_id);
            $subscription = CustomerSubcription::where('id', $subscription_id)->with('latestInvoice')->first();
            $plan = $subscription->plan;
            return view('customers.update-plans', ['plan' => $plan, 'subscription' => $subscription]);
        } catch (\Exception $e) {
            Log::error("Error in PlanController method showUpdatePlan : " . $e->getMessage());
            return redirect()->back()->with('error', 'Something went wrong. Please try again');
        }
    }
     public function showNewPlanUpdate($plan_id = 0)
    {
        try {

            $userID = auth()->user()->id;
            $plan_id = base64_decode($plan_id);
            $plan = Plans::find($plan_id);
            $customerstripeID =  auth()->user()->stripe_customer_id;
            $subscription = CustomerSubcription::where('user_id', $userID)->where('canceled_date', null)->with('latestInvoice')->first();
            if ($subscription != null && $subscription->stripe_subscription_id != null) {

                \Stripe\Stripe::setApiKey(config('stripeapi.stripe.secret'));
                $proration_date = time();
                $subscription_details = \Stripe\Subscription::retrieve($subscription->stripe_subscription_id);
                $items = [
                    [
                        'id' => $subscription_details->items->data[0]['id'],
                        'price' => $plan->stripe_plan_id, # Switch to new price
                    ],

                ];
                $invoice = \Stripe\Invoice::upcoming([
                    'customer' => $customerstripeID,
                    'subscription' => $subscription->stripe_subscription_id,
                    'subscription_items' => $items,
                    'subscription_proration_date' => $proration_date,
                ]);
                $subscription['amount_due'] = $invoice->amount_due;
            }

            return view('customers.update-plans', ['plan' => $plan, 'subscription' => $subscription]);
        } catch (\Exception $e) {
            Log::error("Error in PlanController method showNewPlanUpdate : " . $e->getMessage());
            return redirect()->back()->with('error', 'Something went wrong. Please try again');
        }
    }

    public function updatePlan(Request $request, $subscription_id = 0)
    {
        try {
            $subscription_id = base64_decode($subscription_id);
            $subscription = CustomerSubcription::find($subscription_id);
            $plan = $subscription->plan;
            if ($request->has('number')) {
                $this->cardnumber = trim(intval(str_replace(" ", "", $request->number)));
                $expiry = explode('/', $request->expiry);
                $this->exp_month = trim(intval($expiry[0]));
                $this->exp_year = trim(intval($expiry[1]));
                $this->cvc =  trim(intval($request->cvc));
                $this->name =  $request->name;
                $this->cno = substr(trim($this->cardnumber), -4);

                $userID = Auth::user()->id;
                $stripeID =  Auth::user()->stripe_customer_id;

                $check_card_exist =   CardDetail::where('user_id',  $userID)->where('card_no',  $this->cno)->get();
                if ($check_card_exist->isEmpty()) {
                    $token = $this->stripe->tokens()->create([
                        'card' => [
                            'number'    => $this->cardnumber,
                            'exp_month' => $this->exp_month,
                            'cvc'       => $this->cvc,
                            'exp_year'  => $this->exp_year,
                        ],
                    ]);

                    $Card_detail = new CardDetail;
                    $card = $this->stripe->cards()->create($stripeID, $token['id']);
                    $Card_detail->user_id = $userID;
                    $Card_detail->card_id = $card['id'];
                    $Card_detail->exp_month = $card['exp_month'];
                    $Card_detail->exp_year = $card['exp_year'];
                    $Card_detail->card_no = $card['last4'];
                    $Card_detail->save();
                } else {
                    return view('customers.update-plans', ['plan' => $plan, 'subscription' => $subscription])->with('error', 'Card already added.');
                }
            } else {
            }


            return view('customers.update-plans', ['plan' => $plan, 'subscription' => $subscription]);
        } catch (\Exception $e) {
            Log::error("Error in PlanController method updatePlan : " . $e->getMessage());
            return redirect()->back()->with('error', 'Something went wrong. Please try again');
        }
    }

    function changePakagestatus(Request $request)
    {
        try {
            $plan_id =  $request->plan_id;
            $plandata = Plans::find($plan_id);
            $plan_status = $plandata->status;
            $plan_status == "Active"  ? $plandata->status = 'InActive' :   $plandata->status = 'Active';
            $check =  $plandata->update();

            if ($check) {
                return $plandata->status;
            } else {
                return 'error';
            }
        } catch (\Exception $e) {
            Log::error("Error in PlanController method changePakagestatus : " . $e->getMessage());
            return 'error';
        }
    }

      public function invoices()
    {
        try {
            $data['invoices'] = CustomerInvoice::where('customer_invoices.user_id', Auth::user()->id)->with('subscription')->with('card')->with('plan')->orderBy('customer_invoices.id', 'desc')->get();
            $delete_plan_array = array();
            $deleted_plan = Plans::onlyTrashed()->get();
            if ($deleted_plan != null) {
                foreach ($deleted_plan as $plan) {
                    $delete_plan_array[$plan->id]['id'] = $plan->id;
                    $delete_plan_array[$plan->id]['name'] = $plan->name;
                    $delete_plan_array[$plan->id]['duration'] = $plan->duration;
                }
            }
            $data['deleted_plan'] = $delete_plan_array;
            
            return view('customers.invoices')->with($data);
        } catch (\Exception $e) {
            Log::error("Error in PlanController method invoices : " . $e->getMessage());
            return back()->with('error', 'Something went wrong. Try again later.');
        }
    }


    public function deletecard($cardID = 0)
    {
        try {
            $cardID =  base64_decode($cardID);
            $card = CardDetail::find($cardID);

            $delete_stripe_card = $this->stripe->cards()->delete(auth()->user()->stripe_customer_id, $card->card_id);
            if ($delete_stripe_card['deleted']) {
                $card->delete();
                return back()->with('success', 'Card Deleted Successfully');
            }
            return back()->with('error', 'Something went wrong. Try again later.');
        } catch (\Exception $e) {
            Log::error("Error in PlanController method deletecard : " . $e->getMessage());
            return back()->with('error', 'Something went wrong. Try again later.');
        }
    }
	function generateRandomString($length = 64)
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString . time();
    }
    function trial_period(Request $request)
    {
        try {
           
            $userID = $request->userID;
            $check_free_trial = Plans::where('duration', 'trial')->where('deleted_at', null)->first();
            if ($check_free_trial != null) {
                $licensekey =  $this->generateRandomString();
                $check_user_subscription = CustomerSubcription::where('user_id', $userID)->where('canceled_date', null)->first();
                if ($check_user_subscription == null) {
                    $subcription = new CustomerSubcription;
                    $subcription->user_id = $userID;
                    $subcription->card_id = null;
                    $subcription->plan_id = $check_free_trial->id;
                    $subcription->stripe_subscription_id = null;
                    $subcription->license_key = $licensekey;
                    $subcription->save();
                    $this->subscriptionID =  $subcription->id;
                    $customer_invoice = new CustomerInvoice;
                    $customer_invoice->user_id = $userID;
                    $customer_invoice->subscription_id = $this->subscriptionID;
                    $customer_invoice->plan_id = $check_free_trial->id;
                    $customer_invoice->card_id = null;
                    $customer_invoice->invoice_id = null;
                    $customer_invoice->invoice_details = null;
                    $customer_invoice->subscription_start_date = date('Y-m-d');
                    $customer_invoice->subscription_end_date =  date('Y-m-d', strtotime("+" . $check_free_trial->trial_days . " days"));
                    $customer_invoice->status = 'active';
                    $customer_invoice->save();
                    $this->sendRecieptEmail();
                    return 'success';
                } else {
                    return 'User Already assign';
                }
            } else {
                return 'Free Plan Not exist Please  Insert Free Plan';
            }
        } catch (\Exception $e) {
            Log::error("Error in PlanController method trial_period : " . $e->getMessage());
            return back()->with('error', 'Something went wrong. Try again later.');
        }
    }
    public function showtrialPlanUpdate($plan_id = 0)
    {
        try {

            $userID = auth()->user()->id;
            $plan_id = base64_decode($plan_id);
            $plan = Plans::find($plan_id);
            if ($plan != null) {
                $licensekey =  $this->generateRandomString();
                $check_user_subscription = CustomerSubcription::where('user_id', $userID)->where('canceled_date', null)->first();
                if ($check_user_subscription == null) {
                    $this->previousURL = url()->previous();
                    $subcription = new CustomerSubcription;
                    $subcription->user_id = $userID;
                    $subcription->card_id = null;
                    $subcription->plan_id = $plan->id;
                    $subcription->stripe_subscription_id = null;
                    $subcription->license_key = $licensekey;
                    $subcription->save();
                    $this->subscriptionID =  $subcription->id;
                    $customer_invoice = new CustomerInvoice;
                    $customer_invoice->user_id = $userID;
                    $customer_invoice->subscription_id = $this->subscriptionID;
                    $customer_invoice->plan_id = $plan->id;
                    $customer_invoice->card_id = null;
                    $customer_invoice->invoice_id = null;
                    $customer_invoice->invoice_details = null;
                    $customer_invoice->subscription_start_date = date('Y-m-d');
                    $customer_invoice->subscription_end_date =  date('Y-m-d', strtotime("+" . $plan->trial_days . " days"));
                    $customer_invoice->status = 'active';
                    $customer_invoice->save();
                    $this->sendRecieptEmail();
                    $this->subscription_details = array();
                    $this->subscription_details['subscription_id'] = $this->subscriptionID;
                    $this->subscription_details['invoice_id'] = $customer_invoice->id;
                    $this->subscription_details['subscription_status'] = 'created';
                    $this->subscription_details['status'] =  true;
                    $this->subscription_details['header'] ='inside';
                    return redirect('/success/'.base64_encode($this->subscription_details['subscription_id']).'/'.base64_encode($this->subscription_details['invoice_id']).'/'.base64_encode($this->subscription_details['header']).'/'.base64_encode($this->previousURL).'/'.base64_encode($this->subscription_details['subscription_status']));
                   
                } else {
                    return redirect()->back()->with('error', 'Free Package will be assign when No Package assign for you');
                }
            } else {
                return 'Free Plan Not exist Please  Insert Free Plan';
            }
        } catch (\Exception $e) {
            Log::error("Error in PlanController method showNewPlanUpdate : " . $e->getMessage());
            return redirect()->back()->with('error', 'Something went wrong. Please try again');
        }
    }
    public function sendRecieptEmail()
    {
        try {
            $subcriptiondetails = CustomerSubcription::where('id', $this->subscriptionID)->with('latestInvoice')->with('plan')->first();
           
            $this->plan_type = $subcriptiondetails->plan_name;
            $data = array(
                'name' => auth()->user()->first_name,
                'url' => '',
                'subscription_id' => $subcriptiondetails->stripe_subscription_id,
                'start_date' => $subcriptiondetails->latestInvoice->subscription_start_date,
                'end_date' => $subcriptiondetails->latestInvoice->subscription_end_date,
                'license_key' => $subcriptiondetails->license_key,
                'Plan_name' => $subcriptiondetails->plan->name,
                'amount' => $subcriptiondetails->plan->amount
            );

            Mail::send('email.receipt-email', ['user' => $data], function ($message)  use ($data) {
                $message->to(auth()->user()->email)->subject("Your " . ucfirst($this->plan_type) . " Subscription From B-soft Technology");
                $message->from('pankajv@chetu.com', auth()->user()->first_name);
            });
        } catch (\Exception $e) {
            Log::error("Error in HomeController method sendRecieptEmail : " . $e->getMessage());
        }
    }
}