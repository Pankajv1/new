<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\subcription;
use App\Models\ActiveLicenses;

class DataController extends Controller
{

     /**
     *This function is used to add active license
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function activeLicenses(Request $request){
        try{
            $validator = Validator::make($request->all(), [
            'licence_key' => 'required',
            'email_id' => 'required',
            ]);
            if ($validator->fails()) {
                return response()->json(['data' => [],'code' => 400,'message' => 'Bad Request'], 400);
            }
            $domain=request()->getHost();
            $checkLicenceKey=subcription::where('license_key',$request->licence_key)->get()->toArray();
            $user=User::where('email',$request->email_id)->get()->toArray();
            $activeLicence=ActiveLicenses::where('license_key',$request->licence_key)
            ->where('domain_name',$domain)->get()->toArray();
            //validaton if license key is valid or not
            if(count($checkLicenceKey)>0){

                //validation if user is exists or not
                if(count($user)>0){
                    $subcriptionId=subcription::where('license_key',$request->licence_key)->orderBy('created_at', 'desc')->first();
                    $no_of_domains=$subcriptionId->no_of_domains;
                    $activeLicence1=ActiveLicenses::where('license_key',$request->licence_key)->get()->toArray();
                    $totalEntry=count($activeLicence1);

                    //validation if total no of domains already added
                    if($no_of_domains!=$totalEntry){
                        
                        //check duplicate data in active_licenses
                        if(count($activeLicence)<=0){
                            $user=User::where('email',$request->email_id)->first();
                            $data=[
                            'user_id'=>$user->id,
                            'customer_subcription_id'=>$subcriptionId->id,
                            'domain_name'=>$domain,
                            'license_key'=>$request->licence_key,
                            'activation_date'=> date('y-m-d')
                            ];
                            ActiveLicenses::create($data);//store data in active_licenses
                            return response()->json(['message' => 'Data Added Successfully','code' => 201], 201);
                        }else{
                            return response()->json(['message' => 'Data already Added','code' => 201], 201);
                        }
                }else{
                    return response()->json(['message' => 'You have reached total number of domains','code' => 201], 201);
                }
                }else{
                    return response()->json(['message' => 'User Not Found','code' => 201], 201);
                }
            }else{
                return response()->json(['message' => 'Invalid Licence Key','code' => 201], 201);
            }
        }
        catch (\Exception $e){
            return $response = ['data' => [], 'code' => 500, 'message' => $e->getMessage().$e->getLine()];
        }
    }

    /**
     *This function is used to check expiration of license
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function checkSubcription($licencekey = ""){
        try{

            $parentData=subcription::join('active_licenses','active_licenses.license_key','customer_subcription.license_key')->where('customer_subcription.license_key', $licencekey)->orderBy('customer_subcription.id', 'desc')->first();
            if($parentData === null) {
                return $response = ['message' => 'Invalid License Key'];

            }else {
                if($parentData->end_date<date('Y-m-d')){
                    return $response = ['message' => 'License Has been Expired'];
                }else{
                    return $response = ['message' => 'License is valid till '.$parentData->end_date];
                }  
            }

        }catch (\Exception $e){
            return $response = ['data' => [], 'code' => 500, 'message' => $e->getMessage().$e->getLine()];
        }
    }
}
