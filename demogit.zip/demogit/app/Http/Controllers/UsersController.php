<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Models\ActiveLicenses;
use App\Models\Authentication_log;
use App\Rules\MatchOldPassword;
use Illuminate\Support\Facades\Session;

class UsersController extends Controller
{
    /**
     * Method to show update password view
     */
    public function changePassword()
    {
        try {
            return view('changepassword');
        } catch (\Exception $e) {
            Log::error("Error in UsersController method changePassword : " . $e->getMessage());
            return redirect()->back()->with('error', 'Something went wrong. Try again later.');
        }
    }

    /**
     * Method to update user password
     */
    public function updatePassword(Request $request)
    {
        try {
            $message = '';
            $request->validate([
                'current_password' => ['required', new MatchOldPassword],
                'new_password' => ['required'],
                'new_confirm_password' => ['same:new_password'],
            ]);
            $encode_password =  base64_encode($request->new_password);
            User::find(auth()->user()->id)->update(array(['password' => Hash::make($request->new_password)], 'show_password' => $encode_password));
            Session::flash('message', 'Your Password has been successfully updated!');
            return redirect('/home');
        } catch (\Exception $e) {
            Log::error("Error in UsersController method updatePassword : " . $e->getMessage());
            return redirect()->back()->with('error', 'Something went wrong. Try again later.');
        }
    }

    /**
     * Method to show user listing
     */
    public function registered()
    {
        try {
            $data = User::role('user')->get();
            return view('admin.user.index', ['users' => $data]);
        } catch (\Exception $e) {
            Log::error("Error in UsersController method registered : " . $e->getMessage());
            return redirect()->back()->with('error', 'Something went wrong. Try again later.');
        }
    }


    /**
     * Method to save user data
     */
    public function saveUser(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'first_name' => 'required',
                'email' => 'required|email|unique:users'
            ]);

            if ($validator->fails()) {
                return response()->json(["status" => false, "message" => $validator->errors()->first()]);
            }

            $user = new User;
            $user->first_name = $request->first_name;
            $user->last_name = $request->last_name ?? '';
            $user->email = $request->email;
            $user->company_name = $request->company_name ?? '';
            $user->phone = $request->phone ?? '';
            $userpassword = Str::random(8);
            $user->password = Hash::make($userpassword);
            $user->show_password = base64_encode($userpassword);
            if ($user->save()) {
                $user->assignRole('user');
                Mail::send('email.user-registration-email', ['user' => $user, 'password' => $userpassword], function ($m) use ($user) {
                    $m->from('pankajv@chetu.com', 'Bsoft Technology');
                    $m->subject('Account Created Successfully');
                    $m->to($user->email);
                });
                if (Mail::failures()) {
                    $user->removeRole('user');
                    $user->delete();
                    return response()->json(["status" => false, "message" => "Something went wrong. Please try again."]);
                }
                return response()->json(["status" => true, "message" => "Admin created successfully"]);
            } else {
                return response()->json(["status" => false, "message" => "Something went wrong. Please try again."]);
            }
        } catch (\Exception $e) {
            $user->removeRole('user');
            $user->delete();
            Log::error("Error in UsersController method saveUser : " . $e->getMessage());
            return response()->json(["status" => false, "message" => "Something went wrong. Please try again."]);
        }
    }

    /**
     * Method to fetch user data
     */
    public function fetchUser(Request $request)
    {
        try {
            if (isset($request->id)) {
                $data = User::find($request->id);
                return response()->json(['status' => true, 'data' => $data]);
            } else {
                return response()->json(['status' => false, 'data' => [], 'msg' => 'User not found.']);
            }
        } catch (\Exception $e) {
            Log::error("Error in UsersController method fetchUser : " . $e->getMessage());
            return response()->json(["status" => false, "message" => "Something went wrong. Please try again."]);
        }
    }

    /**
     * Method to fetch user data
     */
    public function updateUser(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'first_name' => 'required',
                'email' => 'required|email|unique:users,email,' . $request->id,
            ]);

            if ($validator->fails()) {
                return response()->json(["status" => false, "message" => $validator->errors()->first()]);
            }
            $data = User::find($request->id);
            $data->first_name = $request->first_name;
            $data->last_name = $request->last_name ?? '';
            $data->email = $request->email;
            $data->company_name = $request->company_name;
            $data->phone = $request->phone ?? '';

            if ($data->update()) {
                return response()->json(["status" => true, "message" => "Successfully Updated"]);
            } else {
                return response()->json(["status" => false, "message" => "failure"]);
            }
        } catch (\Exception $e) {
            Log::error("Error in UsersController method updateUser : " . $e->getMessage());
            return response()->json(["status" => false, "message" => "Something went wrong. Please try again."]);
        }
    }

    /**
     * Method to fetch user data
     */
    public function deleteUser(Request $request)
    {
        try {
            $data = User::find($request->id);
            if ($data->delete()) {
                return response()->json(['status' => true, 'message' => 'Record deleted successfully']);
            } else {
                return response()->json(['status' => false, 'message' => 'Something went wrong. Try again Later.']);
            }
        } catch (\Exception $e) {
            Log::error("Error in UsersController method deleteUser : " . $e->getMessage());
            return response()->json(["status" => false, "message" => "Something went wrong. Please try again."]);
        }
    }

    /**
     * Method to fetch customer listing
     */
    public function customerList($status = '')
    {
        try {

            if ($status == 'Inactive') {
                //return 1;
                $customerId = array();
                $activecustomer = User::select(DB::raw('group_concat(users.id) as userID'))
                    ->join('customer_subscription', 'customer_subscription.user_id', '=', 'users.id')
                    ->where('customer_subscription.canceled_date', null)
                    ->groupBy('users.id')
                    ->get();
                foreach ($activecustomer as $key => $value) {
                    $customerId[$key] = $value['userID'];
                }
                //echo '<pre>'; print_r($customerId); die();
                $customers = User::select(
                    'customer_invoices.subscription_start_date',
                    'customer_invoices.subscription_end_date',
                    'customer_invoices.id as invoice_id',
                    'customer_invoices.status',
                    'plans.name',
                    'users.id',
                    'users.first_name',
                    'users.email',
                    'users.company_name',
                    'users.phone',
                    'users.show_password',
                    'users.last_name',
                    'users.active_status'
                )
                    ->leftJoin('customer_invoices', function ($join) {
                        $join->on('customer_invoices.user_id', '=', 'users.id')
                            ->on('customer_invoices.id', '=', DB::raw("(SELECT max(id) from customer_invoices WHERE customer_invoices.user_id = users.id)"));
                    })
                    //  ->join('customer_subscription', 'customer_subscription.user_id', '=', 'users.id')
                    ->leftJoin('plans', 'plans.id', '=', 'customer_invoices.plan_id')
                    ->whereNotIn('users.id', $customerId)
                    ->role('customer')
                    ->orderBy('customer_invoices.subscription_end_date', 'desc')
                    ->get();
            } else if ($status == 'Active') {
                $customers = User::select(
                    'customer_invoices.subscription_start_date',
                    'customer_invoices.subscription_end_date',
                    'customer_invoices.id as invoice_id',
                    'customer_invoices.status',
                    'plans.name',
                    'users.id',
                    'users.first_name',
                    'users.email',
                    'users.company_name',
                    'users.phone',
                    'users.show_password',
                    'users.last_name',
                    'users.active_status'
                )
                    ->leftJoin('customer_invoices', function ($join) {
                        $join->on('customer_invoices.user_id', '=', 'users.id')
                            ->on('customer_invoices.id', '=', DB::raw("(SELECT max(id) from customer_invoices WHERE customer_invoices.user_id = users.id)"));
                    })
                    ->join('customer_subscription', 'customer_subscription.user_id', '=', 'users.id')
                    ->leftJoin('plans', 'plans.id', '=', 'customer_invoices.plan_id')
                    ->where('customer_subscription.canceled_date', null)
                    ->role('customer')
                    ->orderBy('customer_invoices.subscription_end_date', 'desc')
                    ->get();
            } else {
                $customers = User::select(
                    'customer_invoices.subscription_start_date',
                    'customer_invoices.subscription_end_date',
                    'customer_invoices.id as invoice_id',
                    'customer_invoices.status',
                    'plans.name',
                    'users.id',
                    'users.first_name',
                    'users.email',
                    'users.company_name',
                    'users.phone',
                    'users.show_password',
                    'users.last_name',
                    'users.active_status'
                )
                    ->leftJoin('customer_invoices', function ($join) {
                        $join->on('customer_invoices.user_id', '=', 'users.id')
                            ->on('customer_invoices.id', '=', DB::raw("(SELECT max(id) from customer_invoices WHERE customer_invoices.user_id = users.id)"));
                    })
                    //  ->join('customer_subscription', 'customer_subscription.user_id', '=', 'users.id')
                    ->leftJoin('plans', 'plans.id', '=', 'customer_invoices.plan_id')
                    //->where('customer_subscription.canceled_date',null)
                    ->role('customer')
                    ->orderBy('customer_invoices.subscription_end_date', 'desc')
                    ->get();
            }

            return view('users.index', compact('customers'));
        } catch (\Exception $e) {
            Log::error("Error in UsersController method customerList : " . $e->getMessage());
            return redirect()->back()->with('error', 'Something went wrong. Try again later.');
        }
    }

    /**
     * Method to fetch user active domains
     */
    public function userActiveDomains()
    {
        try {
            $data['activeLicense'] = ActiveLicenses::leftjoin('customer_subscription', 'customer_subscription.id', '=', 'active_licenses.subscription_id')->leftjoin('customer_invoices', 'customer_invoices.subscription_id', '=', 'customer_subscription.id')->where('customer_subscription.user_id', Auth::user()->id)->whereDate('customer_invoices.subscription_end_date', ">=", date("Y-m-d"))->where('customer_invoices.status', 'active')->where('customer_invoices.canceled_date', NULL)->get();
            return view('customers.active-licenses')->with($data);
        } catch (\Exception $e) {
            Log::error("Error in UsersController method userActiveDomains : " . $e->getMessage());
            return redirect()->back()->with('error', 'Something went wrong. Try again later.');
        }
    }

    /**
     * * methord save customer
     */
    public function savecustomer(Request $request)
    {
        try {
            $user = new User;
            $validator = Validator::make($request->all(), [
                'first_name' => 'required',
                'email' => 'required|email|unique:users'
            ]);

            if ($validator->fails()) {
                return response()->json(["status" => false, "message" => $validator->errors()->first()]);
            }


            $user->first_name = $request->first_name;
            $user->last_name = $request->last_name ?? '';
            $user->email = $request->email;
            $user->company_name = $request->company_name ?? '';
            $user->phone = $request->phone ?? '';
            $userpassword = Str::random(8);
            $user->password = Hash::make($userpassword);
            $user->show_password = base64_encode($userpassword);

            if ($user->save()) {
                $user->assignRole('customer');
                Mail::send('email.user-registration-email', ['user' => $user, 'password' => $userpassword], function ($m) use ($user) {
                    $m->from('pankajv@chetu.com', 'Bsoft Technology');
                    $m->subject('Account Created Successfully');
                    $m->to($user->email);
                });
                if (Mail::failures()) {
                    $user->removeRole('customer');
                    $user->delete();
                    return response()->json(["status" => false, "message" => "Something went wrong. Please try again."]);
                }
                return response()->json(["status" => true, "message" => "Admin created successfully"]);
            } else {
                return response()->json(["status" => false, "message" => "Something went wrong. Please try again."]);
            }
        } catch (\Exception $e) {
            $user->removeRole('customer');
            $user->delete();
            Log::error("Error in UsersController method savecustomer : " . $e->getMessage());
            return response()->json(["status" => false, "message" => "Something went wrong. Please try again."]);
        }
    }
    public function resetpassword(Request $request)
    {
     try {
        $userID =  $request->hidden_userID;
        $user =  User::find($userID);
        $userpassword = $request->new_password;
        $user->show_password = base64_encode($request->new_password);

        $user->password = Hash::make($userpassword);
        Mail::send('email.reset-password', ['user' => $user, 'password' => $userpassword], function ($m) use ($user) {
            $m->from('pankajv@chetu.com', 'Bsoft Technology');
            $m->subject('Password Reset Successfully');
            $m->to($user->email);
        });
        if (Mail::failures()) {
            $user->removeRole('customer');
            $user->delete();
            return back()->with('error', 'Something Went Wrong');
        }
        if ($user->update()) {
            return back()->with('success', 'Pasword Reset successfully');
        } else {
            return response()->json(["error" =>  "failure"]);
        }
      }
      catch (\Exception $e) {
        
        Log::error("Error in UsersController method resetpassword : " . $e->getMessage());
            return redirect()->back()->with('error', 'Something went wrong. Try again later.');
    }
    }
    public function history(Request $request)
    {
        try
        {
            
               $userID =  $request->userID;
                $user =  Authentication_log::where('authenticatable_id',$userID)->get();
              //  echo '<pre>'; print_r($user);
                return response()->json(["status" => true, "data" => $user]);

        }
        catch (\Exception $e) {
            
            Log::error("Error in UsersController method resetpassword : " . $e->getMessage());
                return redirect()->back()->with('error', 'Something went wrong. Try again later.');
        }
        
        
    }
    public function changeuserstatus(Request $request)
    {
        try
        {
            
               $userID =  $request->userID;
              
                $user =  User::find($userID);
                $user_status = $user->active_status;
                $user_status == "Active"  ? $user->active_status = 'InActive' :   $user->active_status = 'Active';
                $check =  $user->update();
    
                if ($check) {
                    return $user->active_status;
                } else {
                    return 'error';
                }
               

        }
        catch (\Exception $e) {
            
            Log::error("Error in UsersController method changeuserstatus : " . $e->getMessage());
            return 'error';
        }
        
        
    }
}
