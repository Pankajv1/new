<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Auth;

class CheckRole
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {   
       
        if(isset(Auth::user()->role_id) && Auth::user()->role_id == env('SUPERADMIN_ROLE_ID')) {
            return $next($request);
        }

        if(Auth::user()->role_id == env('ADMIN_ROLE_ID') && $request->path() == 'user-list') {
            return $next($request);
        }

        if(Auth::user()->role_id == env('CUSTOMER_ROLE_ID') && $request->path() == 'subscription-plan') {
            return $next($request);
        }
       
        abort(401);
        
    }
}
