<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CardDetail extends Model
{
    use HasFactory;
    protected $table = 'card_details';
    protected $fillable = [
        'user_id',
        'card_id',
        'exp_month',
        'exp_year',
        'card_no',
    ];
    
    /**
     * Get the user that owns the card.
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the subscription for the card.
     */
    public function subscription()
    {
        return $this->hasOne(CustomerSubcription::class);
    }

    /**
     * Get the invoices for the card.
     */
    public function invoices()
    {
        return $this->hasOne(CustomerInvoice::class);
    }
}
