<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ActiveLicenses extends Model
{
    protected $table ="active_licenses";
    /**
    * The attributes that are mass assignable.
    *
    * @var array
    */
    protected $fillable =['user_id','subscription_id','domain_name','license_key','activation_date', 'end_date'];

    /**
     * Get the subscription that owns the license.
     */
    public function subscription()
    {
        return $this->belongsTo(CustomerSubcription::class);
    }

    /**
     * Get the user that owns the license.
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }
   
}
