<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Plans extends Model
{
    use HasFactory;

    use SoftDeletes;

    protected $table = 'plans';
    
    protected $fillable = [
        'name',
        'amount',
        'duration',
        'no_of_domains',
        'stripe_plan_id',
        'features',
    ];
    
    /**
     * Get the subscription for the plan.
     */
    public function subscriptions()
    {
        return $this->hasMany(CustomerSubcription::class, 'plan_id', 'id');
    }

    /**
     * Get the invoices for the plan.
     */
    public function invoices()
    {
        return $this->hasMany(CustomerInvoice::class, 'plan_id', 'id');
    }
}
