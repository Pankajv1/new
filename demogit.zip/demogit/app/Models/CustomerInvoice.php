<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CustomerInvoice extends Model
{
    use HasFactory;
    protected $table = 'customer_invoices';
    protected $fillable = [
        'user_id',
        'subscription_id',
        'plan_id',
        'card_id',
        'invoice_id',
        'invoice_details',
        'subscription_start_date',
        'subscription_end_date',
        'status',
        'canceled_date',
    ];

    /**
     * Get the subscription that owns the invoice.
     */
    public function subscription()
    {
        return $this->belongsTo(CustomerInvoice::class, 'subscription_id');
    }

    /**
     * Get the card that owns the invoice.
     */
    public function card()
    {
        return $this->belongsTo(CardDetail::class);
    }

    /**
     * Get the plan that owns the invoice.
     */
    public function plan()
    {
        return $this->belongsTo(Plans::class, 'plan_id');
    }
}
