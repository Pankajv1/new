<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CustomerSubcription extends Model
{
    use HasFactory;
    protected $table = 'customer_subscription';
    protected $fillable = [
        'user_id',
        'card_id',
        'plan_id',
        'stripe_subscription_id',
        'license_key',
    ];

    /**
     * Get the plan that owns the subscription.
     */
    public function plan()
    {
        return $this->belongsTo(Plans::class)->withTrashed();
    }

    /**
     * Get the user that owns the subscription.
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the card that owns the subscription.
     */
    public function card()
    {
        return $this->belongsTo(CardDetail::class);
    }

    /**
     * Get the invoices for the subscription.
     */
    public function invoices()
    {
        return $this->hasMany(CustomerInvoice::class, 'subscription_id', 'id');
    }
  
    /**
     * Get the latest invoice for the subscription.
     */
    public function latestInvoice()
    {
        return $this->hasOne(CustomerInvoice::class, 'subscription_id', 'id')->latest();
    }

    /**
     * Get the latest atcive invoice for the subscription.
     */
    public function latestActiveInvoice()
    {
        return $this->hasOne(CustomerInvoice::class, 'subscription_id', 'id')->where('status','=', 'active')->latest();
    }

    /**
     * Get the licenses for the subscription.
     */
    public function licenses()
    {
        return $this->hasMany(ActiveLicenses::class, 'subscription_id', 'id');
    }
}
