<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PlanController;
use App\Http\Controllers\UsersController;
use App\Http\Controllers\Auth\ResetPasswordController;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\Auth\LoginController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('login/{plan}', [LoginController::class, 'showLoginForm'])->name('login.user');
Auth::routes();
Route::get('logout', '\App\Http\Controllers\Auth\LoginController@logout');
Route::post('login', '\App\Http\Controllers\Auth\LoginController@login');
Route::get('/', function () {
    return redirect('/subscription-plan');
});
Route::get('subscription-plan', [PlanController::class, 'subscriptionPlan'])->name('subscription.plan');

Route::middleware(['auth'])->group(function () {
    
    Route::get('/home', [HomeController::class, 'index'])->name('home'); 
    // Change Password Routes
    Route::get('/changepassword', [UsersController::class, 'changePassword'])->name('changepassword');
    Route::post('change-password', [UsersController::class, 'updatePassword'])->name('change.password');
    
    Route::post('/stripecustomer', [HomeController::class, 'createStripeCustomer'])->name('stripecustomer');
    Route::get('/purchase-plan/{plan_id}', [HomeController::class, 'purchasePlan'])->name('purchase.plan');
    Route::get('/success/{subscription_id}/{invoice_id}/{header}/{url}/{subscription_status}', [HomeController::class, 'paymentSuccessful'])->name('payment.success');
    
    // Customer Listing
    Route::get('customer-list/{status?}', [UsersController::class, 'customerList'])->name('customer.list');
    

    // For Customer subscription
    Route::get('my-plans', [PlanController::class, 'myPlans'])->name('my.plans');
    Route::get('update-plan/{subscription_id}', [PlanController::class, 'showUpdatePlan'])->name('show.update.plan');
    Route::get('update-plannew/{plan_id}', [PlanController::class, 'showNewPlanUpdate'])->name('show.update.newplan');
	Route::get('update-trial_plan/{plan_id}', [PlanController::class, 'showtrialPlanUpdate'])->name('show.update.trialplan');
  
    Route::get('invoices', [PlanController::class,'invoices'])->name('invoices');
    Route::get('active-domains', [UsersController::class,'userActiveDomains'])->name('active.domains');
    Route::get('cancel-plan/{subscription_id}', [HomeController::class, 'cancelSubscription'])->name('cancel.plan');
    Route::post('/savecustomer', [UsersController::class, 'savecustomer'])->name('save.customer');
    Route::post('/delete-user', [UsersController::class,'deleteUser'])->name('delete.user');
    Route::get('/fetch-user', [UsersController::class, 'fetchUser'])->name('fetch.user');
    Route::post('/update-user', [UsersController::class, 'updateUser'])->name('update.user');
    // Only Admin Routes
    Route::group(['middleware' => ['role:admin']], function () {
        // Package Routes
        Route::get('packages', [PlanController::class, 'index'])->name('view.packages');
        Route::get('add-package', [PlanController::class, 'addPackage'])->name('add.package');
        Route::post('save-package', [PlanController::class, 'savePackage'])->name('save.package');
        Route::get('edit-package/{id}', [PlanController::class, 'editPackage'])->name('edit.package');
        Route::put('update-package/{id}', [PlanController::class, 'updatePackage'])->name('update.package');
        Route::get('delete-package/{id}', [PlanController::class, 'deletePackage'])->name('delete.package');
    
        // Staff Routes
        Route::get('user-list', [UsersController::class, 'registered'])->name('user.list');
        Route::post('/saveuser', [UsersController::class, 'saveUser'])->name('user.save');
	    Route::post('/trial_period', [PlanController::class,'trial_period'])->name('trial.period');

        // route customer
        Route::post('reset-password-user', [UsersController::class, 'resetpassword'])->name('reset.password');
        
        //// package status
        Route::post('change-status', [PlanController::class,'changePakagestatus'])->name('change-status');

        Route::post('change-user-status', [UsersController::class,'changeuserstatus'])->name('change-user-status');
    });
    Route::get('/delete-card/{card_id}', [PlanController::class, 'deletecard'])->name('delete.card');
    Route::post('/history', [UsersController::class, 'history'])->name('user.history');
});
Route::post('reset-password', [ResetPasswordController::class, 'resetPassword'])->name('reset.password.post');
Route::post('/webhook', [HomeController::class, 'webhook']);  