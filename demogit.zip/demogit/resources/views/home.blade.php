@extends('layouts.appdashboard')
@section('content')

    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Dashboard</h1>
                    </div>
                    <div class="col-sm-5">
                       
                    </div>
                    <div class="col-sm-1">
                        
                        <button type="button" class="close">
                            
                            <span ><a target="_blank" href="{{ asset('img/BsoftTechnology_SCMS_plugin.zip') }}"><i class="fa fa-plug" aria-hidden="true" data-toggle="tooltip" title="Download Plugin"></i></a></span>
                        </button>
                        
                    </div>
                </div>
                <div class="dashboardSection">
                    @if(Session::has('message'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>Great!</strong> {{Session::get('message') }}
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    @endif
                    <div class="row">
                        @php
                            if(Auth::user()->hasRole('admin')) {
                                $col = '3'; 
                            } elseif(Auth::user()->hasRole('user')) {
                                $col = '4'; 
                            } else {
                                $col = '6'; 
                            }
                        @endphp
                        <div class="col-md-{{ $col }}">
                            <div class="card">
                                <div class="d-flex justify-content-between pb-2">
                                    <div class="lefticon position-relative">
                                        <h5>Hi {{ Auth::user()->first_name }}</h5>
                                        <h2 class="greeting"></h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @if (Auth::user()->hasRole('admin'))
                            <div class="col-md-3" >
                                <div class="card">
                                    <div class="d-flex justify-content-between">
                                        <div class="lefticon">
                                            <a href="{{ route('view.packages') }}">
                                                <i class="nav-icon fas fa-file"></i>
                                            </a>
                                        </div>
                                        <div class="rightcontnt">
                                            <span>  <a href="{{ route('view.packages') }}">Packages  </a></span>
                                            <h4>{{ $packages->count() }}</h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endif
                        @if (Auth::user()->hasRole('admin') || Auth::user()->hasRole('user'))
                            <div class="col-md-{{(Auth::user()->hasRole('admin')) ? '3' : '4'}}">
                                <div class="card">
                                    <div class="d-flex justify-content-between">
                                        <div class="lefticon">
                                            <a href="{{ route('customer.list',['Active']) }}">
                                                <i class="nav-icon fas fa-users"></i>
                                            </a>
                                        </div>
                                        <div class="rightcontnt">
                                            <span> <a href="{{ route('customer.list',['Active']) }}">Active Customers</a></span>
                                            <h4>{{ $Activecustomers }}</h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-{{(Auth::user()->hasRole('admin')) ? '3' : '4'}}">
                                <div class="card">
                                    <div class="d-flex justify-content-between">
                                        <div class="lefticon">
                                            <a href="{{ route('customer.list',['Inactive']) }}">
                                                <i class="nav-icon fas fa-users"></i>
                                            </a>
                                        </div>
                                        <div class="rightcontnt">
                                            <span><a href="{{ route('customer.list',['Inactive']) }}">InActive Customers </a></span>
                                            <h4>{{ $InActivecustomers }}</h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @else
                            <div class="col-md-6">
                                <div class="card">
                                    <div class="d-flex justify-content-between">
                                        <div class="lefticon">
                                            <a href="{{ route('active.domains') }}">
                                                <i class="nav-icon fas fa-users"></i>
                                            </a>
                                        </div>
                                        <div class="rightcontnt">
                                            <span><a href="{{ route('active.domains') }}">Active Domains</a></span>
                                            <h4>{{@$activeLicense}}</h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endif
                    </div>
                    
                    @if (Auth::user()->hasRole('admin') || Auth::user()->hasRole('user'))  
                        <div class="listSection">
                            <div class="row">
                                <div class="col-md-12 col-lg-12">
                                    <div class="card px-0">
                                        <h4>Registered Domains This Month</h4>
                                        <table class="table">
                                            <thead>
                                              <tr>
                                                <th scope="col">Domain Name</th>
                                                <th scope="col">Activation Date</th>
                                                <th scope="col">License Expiry Date</th>
                                                <th scope="col">Customer Name</th>
                                              </tr>
                                            </thead>
                                            <tbody>
                                                @foreach($activeLicense as $license)
                                                <tr>
                                                    <th ><a href="http://{{ $license->domain_name }}" target="_blank">{{ $license->domain_name }}</a></th>
                                                    <td>{{ date("M d, Y", strtotime($license->activation_date)) }}</td>
                                                    <td>{{ date("M d, Y", strtotime($license->end_date)) }}</td>
                                                    <td>{{ $license->user->first_name }}</td>
                                                  </tr>
                                             
                                                  @endforeach
                                            </tbody>
                                          </table>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
@endsection
@section('script')
<script>
    var today = new Date()
    var curHr = today.getHours();
    if (curHr < 12) {
        $(".greeting").text('Good morning')
    } else if (curHr < 18) {
        $(".greeting").text('Good afternoon')
    } else {
        $(".greeting").text('Good evening')
    }
    $('[data-toggle="tooltip"]').tooltip(); 
</script>
@endsection