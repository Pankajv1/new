@extends('layouts.app')

@section('content')
<div class="alert alert-success text-center">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
    <p>Dear  @if (Auth::check())  {{ Auth::user()->name }} @endif  Your Subscription Has been successfully !</p>
</div>

<section>
    <div class="container">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6 text-center">
              
                <h3>Plan: {{ Str::ucfirst($subscription_details['plan_name']) }}</h3>
                <h3>Amount: ${{$subscription_details['plan_amount'] }}</h3>
                <h3>Plan Start : {{ date("m-d-Y", strtotime($subscription_details['create_date'])) }}</h3>
                <h3>Plan End : {{ date("m-d-Y", strtotime($subscription_details['end_date'])) }}</h3>
                <h3>Subscription ID : {{ $subscription_details['subscriptionID'] }}</h3>

            </div>
            <div class="col-md-3"></div>
            <div class="col-md-3"></div>
            <div class="col-md-6">
               
            </div>
            <div class="col-md-3"></div>
        </div>
    </div>
</section>

@endsection
