@extends('layouts.appdashboard')
@section('content')
<div class="content-wrapper mb-5">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="{{ route('home') }}">Dashboard</a></li>
                        <li class="breadcrumb-item active">Add Package</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="container mt-2">
        <div class="row justify-content-center">
            <div class="col-md-6">
                @include('includes.message')

                <div class="card">
                    <div class="card-header">
                        <h4>Add Package Details</h4>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('save.package') }}" id="addPackage" method="POST">
                            @csrf
                            <div class="form-group mb-3">
                                <label for="">Package Name</label>
                                <input type="text" name="name" class="form-control" value="{{old('name')}}" autofocus onkeydown="return /[a-z ]/i.test(event.key)">
                                @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            <div class="form-group mb-3">
                                <label for="">Amount</label>
                                <input id="numberonly" type="text" name="amount" class="form-control" value="{{old('amount')}}" >
                                @error('amount')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            <div class="form-group mb-3">
                                <label for="">No of Domains</label>
                                <input type="text" name="no_of_domains" class="form-control" value="{{old('no_of_domains')}}">
                                @error('no_of_domains')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            <div class="form-group mb-3">
                                <label for="Plane Duration">Duration</label>
                                <select name="duration" id="duration" class="form-control">
								    <option value="trial" {{ old('duration') == "trial" ? "selected" : "" }}>Trial</option>
                                    <option value="week" {{ old('duration') == "week" ? "selected" : "" }}>Weekly</option>
                                    <option value="month" {{ old('duration') == "month" ? "selected" : "" }}>Monthly</option>
                                    <option value="Every 3 Month" {{ old('duration') == "Every 3 Month" ? "selected" : "" }}>Every 3 Month</option>
                                    <option value="Every 6 Month" {{ old('duration') == "Every 3 Month" ? "selected" : "" }}>Every 6 Month</option>
                                    <option value="year" {{ old('duration') == "year" ? "selected" : "" }}>Yearly</option>
                                </select>
                                @error('duration')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
							 <div class="form-group mb-3" id="t_days">
                                <label for="">Trial Days</label>
                                <input type="text" name="trial_days" id="trial_days" class="form-control" value="{{old('trial_days')}}" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))">
                                @error('trial_days')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            <div class="input_fields_remove">
                                <label for="">Features</label>
                                <div class="features">
                                    <input type="text" name="features[]" class="form-control feature" autocomplete="features[]" >
                                    <a class="add_field_button btn btn-dark" style="margin-left: 10px !important;"><i class="fa fa-plus" aria-hidden="true"></i></a>
                                </div>
                            </div><br>
                            <div class="form-group mb-3 text-right">
                                <a href="{{ route('view.packages') }}" class="btn btn-secondary">Back</a>
                                <button type="submit" class="btn btn-dark ml-4">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('script')
    <script>
        $(document).ready(function() {
            var max_fields = 10;
            var remove = $(".input_fields_remove");
            var add_button = $(".add_field_button");

            var x = 1;
            $(add_button).click(function(e) {
                if (x < max_fields) {
                    x++;
                    $(remove).append(
                        '<div class="features"><input type="text" class="form-control feature" name="features[]"/ ><a class="remove_field btn btn-secondary" style="margin-left: 10px !important;"> <i class="fa fa-minus" aria-hidden="true"></i></a></div>'
                    );
                }
            });

            $(document).on("click", ".remove_field", function(e) {
                e.preventDefault();
                $(this).parent('div').remove();
                x--;
            })
            //validate Letters and spaces only
            jQuery.validator.addMethod("alphanumeric", function(value, element) {
                return this.optional(element) || /^[\w.," "]+$/i.test(value);
            }),
            // Form data validation
            $('#addPackage').validate({
                rules: {
                    name: {
                        required: true,
                        minlength: 3
                    },
                    amount: {
                        required: true,
                       number: true,
                    },
                    no_of_domains: {
                        required: true,
                        number: true,
                        digit:true
                    },
                    duration: {
                        required: true
                    },
                    features: {
                        required: true,
                    },
                },
                messages: {
                    name: {
                        required: "Package name is required",
                        minlength: "Please enter minimum 3 characters",
                    },
                    amount: {
                        required: "Amount is required",
                        number: "Please enter amount in digits only"
                    },
                    no_of_domains: {
                        required: "Number of domains is required",
                        number: "Please enter numbers only",
                        digit: "Please enter digits only"
                    },
                    duration: {
                        required: "Duration is required"
                    },
                    features: {
                        required: "Please add plan features",
                    },
                },
                errorPlacement: function(label, element) {
                    label.addClass('mt-2 text-danger');
                    element.parent().append(label);
                },
                submitHandler: function(form) {
                    $(form).submit();
                }
            });
            $("#numberonly").keypress(function (e){
            var charCode = (e.which) ? e.which : e.keyCode;
            if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                return false;
            }
            });
			  $("#duration").change(function(){
               var duration = $('#duration').val();
               if(duration == "trial")
               {
                $('#t_days').show();
				 
               }
               else
               {
                $('#t_days').hide();
				 
               }
            });
        });
        
    </script>
@endsection
