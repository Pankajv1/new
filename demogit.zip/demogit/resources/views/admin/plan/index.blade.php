@extends('layouts.appdashboard')
@section('content')
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Packages</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="{{ route('home') }}">Dashboard</a></li>
                            <li class="breadcrumb-item active">Packages</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    @include('includes.message')
                </div>
                <div class="col-md-6">
                </div>
                <div class="col-md-6 text-right">
                    <a href="{{ route('add.package') }}" class="btn btn-dark float-end" data-placement="bottom" title="Add package">Add Package</a>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-md-12">
                    <table class="table table-bordered table-striped" id="myTable">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Amount</th>
                                <th>Duration</th>
                                <th>No. of Domains</th>
								<th>Trial Days</th>
                                <th>Features</th>
                                <th style="width: 160.8px !important;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
						
                            @foreach ($plans as $plan)
                                <tr>
                                    <td>{{ Str::ucfirst($plan->name) }}</td>
                                    <td>{{ $plan->amount }}</td>
                                    <td>{{ Str::ucfirst($plan->duration)}}</td>
                                    <td>{{ $plan->no_of_domains }}</td>
									<td>{{ $plan->trial_days }}</td>
                                    <td>
                                        {{ implode(',', json_decode($plan->features)) }}
                                    </td>
                                    <td>
                                        <a href="{{ url('edit-package/' . $plan->id) }}" class="btn btn-secondary btn-md" data-placement="bottom" title="Edit">
                                            <i class="fas fa-pen"></i>
                                        </a>
                                       
                                            <a href="{{ url('delete-package/' . $plan->id) }}" class="btn btn-dark btn-md" data-placement="bottom" title="Delete" onclick="deletepackage(event)" >
                                                <i class="fas fa-trash"></i>
                                            </a>
                                 
                                        <label class="switch" data-placement="bottom" title="Status">

                                            <input type="checkbox" @if($plan->status =="Active") checked @endif data-id ={{ $plan->id}} class="status_update" >
                                            <span class="slider round"></span>
                                          </label>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('script')
<script>
    $(document).ready(function() {
        $('#myTable').DataTable();
    });
    $(".status_update").click(function(e){
       var plan_id =  $(this).closest('.status_update').attr('data-id');
       var csrf_token="{{csrf_token()}}";
            jQuery.ajax({
                url: "/change-status",
                method: 'post',
                data: {
                plan_id: plan_id,
                '_token':csrf_token
                
                },
                success: function(result){
                    if(result == 'error') {
						swal({
                            title: "Something Went Wrong !",
                            icon: "warning",
                            dangerMode: true,
                        });
                        
                    } else {
                        swal("Package "+result+" successfully!", "", "success");
                    } 
                }
            });
        });
        function deletepackage(ev)
        {
            
            ev.preventDefault();
            var urlToRedirect = ev.currentTarget.getAttribute('href'); // use currentTarget because the click may be on the nested i tag and not a tag causing the href to be empty
            console.log(urlToRedirect); // verify if this is the right URL
            swal({
                title: "Are you sure you want to delete?",
                text: "Delete Package",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                // redirect with javascript here as per your logic after showing the alert using the urlToRedirect value
                if (willDelete) {
                    window.location.href = urlToRedirect;
                }
            });
    
        }
</script>
@endsection
