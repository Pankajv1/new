@extends('layouts.appdashboard')
@section('content')
<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="{{ route('home') }}">Dashboard</a></li>
                        <li class="breadcrumb-item active">Edit Pacakge</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                @include('includes.message')
                <div class="card">
                    <div class="card-header">
                        <h4 class="mt-2">Update Package Details</h4>
                    </div>
                    <div class="card-body">
                        <form action="{{ url('update-package/' . $planeUser->id) }}" id="updatePackage" method="POST">
                            @csrf
                            @method('PUT')
							 <input type="hidden" name="check_duration" class="form-control" value="{{ $planeUser->duration }}" >
                            <div class="form-group mb-3">
                                <label for="">Name</label>
                                <input type="text" name="name" class="form-control" value="{{ $planeUser->name }}" autofocus onkeydown="return /[a-z ]/i.test(event.key)">
                                @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            <div class="form-group mb-3">
                                <label for="">Amount</label>
                                <input type="text" name="amount" value="{{ $planeUser->amount }}" class="form-control" readonly>
                                @error('amount')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            <div class="form-group mb-3">
                                <label for="">No of Domains</label>
                                <input type="text" name="no_of_domains" class="form-control" value="{{ $planeUser->no_of_domains }}">
                                @error('no_of_domains')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            <div class="form-group mb-3">
                                <label for="">Duration</label>
                                <select name="duration" id="plane_duration" class="form-control" readonly disabled>
								    <option value="trial" {{ $planeUser->duration == "trial" ? "selected" : "" }}>Trial</option>
                                    <option value="week" {{ $planeUser->duration == "week" ? "selected" : "" }}>Weekly</option>
                                    <option value="month" {{ $planeUser->duration == "month" ? "selected" : "" }}>Monthly</option>
                                    <option value="Every 3 Month" {{ $planeUser->duration == "Every 3 Month" ? "selected" : "" }}>Every 3 Month</option>
                                    <option value="Every 6 Month" {{ $planeUser->duration == "Every 6 Month" ? "selected" : "" }}>Every 6 Month</option>
                                    <option value="year" {{ $planeUser->duration == "year" ? "selected" : "" }}>Yearly</option>
                                </select>
                                @error('duration')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
							 @if($planeUser->duration == "trial")
                            <div class="form-group mb-3" id="t_days">
                                <label for="">Trial Days</label>
                                 <input type="text" name="trial_days" id="trial_days" class="form-control" value="{{$planeUser->trial_days}}" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))">
                                @error('trial_days')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            @endif
                            <div class="input_fields_remove" id="addrow">
                                @foreach (json_decode($planeUser->features) as $key => $feature)
                                    @if($key ==0)
                                        <label for="">Features</label>
                                    @endif
                                    <div class="features">
                                        <input type="text" name="features[]" class="form-control feature" value="{{ $feature }}">
                                        @if ($key != 0)
                                            <a class="remove_field btn btn-secondary" style="margin-left: 10px !important;"><i class="fa fa-minus" aria-hidden="true" ></i></a>
                                        @else 
                                            <a class="add_field_button btn btn-dark" style="margin-left: 10px !important;"><i class="fa fa-plus" aria-hidden="true"></i></a>
                                        @endif
                                    </div>
                                @endforeach
                            </div>
                            <div class="form-group float-end mb-3">
                                <a href="{{ route('view.packages') }}" class="btn btn-secondary">Back</a>
                                <button type="submit" class="btn btn-dark ml-4">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('script')
    <script>
        $(document).ready(function() {
            var max_fields = 10;
            var remove = $(".input_fields_remove");
            var add_button = $(".add_field_button");
            var x = 1;
            $(add_button).click(function(e) {
                if (x < max_fields) {
                    x++;
                    $(remove).append(
                        '<div class="features"><input type="text" class="form-control feature" name="features[]"/><a class="remove_field btn btn-secondary" style="margin-left: 10px !important;"> <i class="fa fa-minus" aria-hidden="true"></i></a></div>'
                    );
                }
            });

            $(document).on("click", ".remove_field", function(e) {
                e.preventDefault();
                $(this).parent('div').remove();
                x--;
            });

            jQuery.validator.addMethod("alphanumeric", function(value, element) {
                return this.optional(element) || /^[\w.," "]+$/i.test(value);
            }),

            // Form data validation
            $('#updatePackage').validate({
                rules: {
                    name: {
                        required: true,
                        minlength: 3
                    },
                    amount: {
                        required: true,
                        number: true,
                       
                    },
                    no_of_domains: {
                        required: true,
                        number: true,
                        digit:true
                    },
                    duration: {
                        required: true
                    },
                    features: {
                        required: true
                    }
                },
                messages: {
                    name: {
                        required: "Package name is required",
                        minlength: "Please enter minimum 3 characters",
                    },
                    amount: {
                        required: "Amount is required",
                       
                        number: "Please enter amount in digits only"
                    },
                    no_of_domains: {
                        required: "Number of domains is required",
                        number: "Please enter numbers only",
                        digit: "Please enter digits only"
                    },
                    duration: {
                        required: "Duration is required"
                    },
                    features: {
                        required: "Features is required"
                    },
                },
                errorPlacement: function(label, element) {
                    label.addClass('mt-2 text-danger');
                    element.parent().append(label);
                },
                submitHandler: function(form) {
                    // $(form).submit();
                }
            });
        });

    </script>
@endsection
