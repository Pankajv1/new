<!doctype html>

<html>
    <body>
            <main >
            @yield('content')
        </main>
    </div>
</body>
</html>
