@extends('layouts.apptest')

@section('content')
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard v1</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">

            @if (session('status'))
                <h6 class="alert alert-success">
                    {{ session('status') }}
                </h6>
            @endif

            <div class="card">
                <div class="card-header">
                    <h4>Modify plan details
                        <a href="{{ url('planes') }}" class="btn btn-danger float-end">BACK</a>
                    </h4>
                </div>
                <div class="card-body">

                    <form action="{{ url('update-plane/'.$planeUser->id) }}" method="POST">
                        @csrf
                        @method('PUT')

                        <div class="form-group mb-3">
                            <label for="">Plan Name</label>
                            <input type="text" name="name" value="{{$planeUser->name}}" class="form-control" required autocomplete="name">
                        </div>
                        <div class="form-group mb-3">
                            <label for="">Plan Amount</label>
                            <input type="text" name="amount" value="{{$planeUser->amount}}" class="form-control" required autocomplete="amount">
                        </div>
                        <div class="form-group mb-3">
                        <label for="">Plan Duration</label>
                       
                        <select name="duration" id="plane_duration" class="form-control">
                          <option value="3 months">3 months</option>
                          <option value="6 months">6 months</option>
                          <option value="9 months">9 months</option>
                          <option value="12 months">12 months</option>
                        </select>
                        </div>
                        @foreach(json_decode($planeUser->features) as $key=>$features)
                        <div class="input_fields_remove" id="addrow">
                            <label for="">Plan Features</label>
                            <style> 
                              input {
                                    width: 95%;
                            }
                            </style>
                           
                           
                         
                            <input type="text" name="features[]" value="{{$features}}" required autocomplete="features[]">@if($key !=0)<a class="remove_field"> <i class="fa fa-minus" aria-hidden="true"></i>@else <a class="add_field_button"> <i class="fa fa-plus" aria-hidden="true"></i></a> @endif</a>
                           
                           
                           
                        </div>
                        @endforeach
                        </br>
                        <div class="form-group mb-3">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
    
   
    <!-- /.content -->
</div>
<script>
$(document).ready(function() {
    
	var max_fields      = 10;
	var remove   		= $(".input_fields_remove");
	var add_button      = $(".add_field_button");
	
	var x = 1;
	$(add_button).click(function(e){

        // console.log('here');
		if(x < max_fields){ 
			x++;
            $('.input_fields_remove:last').after('<div><label for="">Plane Features</label> <input type="text" name="features[]"/> <a class="remove_field"><i class="fa fa-minus" aria-hidden="true"></i></a></div>');
			//$('#addrow').append('<div><label for="">Plane Features</label> <input type="text" name="features[]"/> <a class="remove_field"><i class="fa fa-minus" aria-hidden="true"></i></a></div>');
            
		}
	});
	
	$(document).on("click",".remove_field", function(e){
        // alert('here');
		e.preventDefault();
        $(this).parent('div').remove();
        x--;
	})
});
</script>
@endsection