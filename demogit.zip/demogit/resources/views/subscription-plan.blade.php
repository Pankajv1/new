@extends('layouts.app')
@section('content')
    <section class="pricing-section">
        <div class="container">
            <div class="text-center fs-5">
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eos, molestiae mollitia soluta est perferendis
                    nam
                    pariatur odio suscipit accusamus maxime aliquam tenetur quam repudiandae adipisci similique aut aliquid
                    quibusdam rem.</p>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eos, molestiae mollitia soluta est perferendis
                    nam
                    pariatur odio suscipit accusamus maxime aliquam tenetur quam repudiandae adipisci similique aut aliquid
                    quibusdam rem.</p>
            </div>
            <div class="sec-title text-center">
                <span class="title">Get plan</span>
                <h2>Choose a Plan</h2>
            </div>

            <div class="outer-box">
                <div class="row">
                    @foreach ($plans as $item)
                        <div class="pricing-block col-lg-4 col-md-4 col-sm-12 wow fadeInUp">
                            <div class="inner-box first-pay-height">
                                <div class="icon-box">
                                    <div class="icon-outer"><i class="fa fa-usd" aria-hidden="true"></i></div>
                                </div>
                                <div class="price-box">
                                    <div class="title"> {{ $item->name }}</div>
                                    <h4 class="price">USD ${{ $item->amount }} </h4>
                                    <h4 class="price">
                                        @if($item->duration == "week" || $item->duration == "month" || $item->duration == "yesr")
                                            {{ Str::ucfirst($item->duration)."ly" }}
                                        @else
                                            {{ Str::ucfirst($item->duration) }}
                                        @endif
                                    </h4>
                                </div>
                                <ul class="features">
                                    @foreach (json_decode($item->features) as $value)
                                        <li class="true">{{ $value }}</li>

                                    @endforeach
                                </ul>
                                <div class="btn-box mt-5">
                                    @if (Auth::check())
                                        <a href="{{ route('purchase.plan', [$item->id]) }}" class="theme-btn">Buy
                                            Now</a>
                                    @else
                                        <a href="{{ route('login.user', [$item->id]) }}" class="theme-btn">Buy
                                            Now</a>
                                    @endif
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </section>
@endsection
