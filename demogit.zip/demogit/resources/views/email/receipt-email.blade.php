<!doctype html>
<html lang="en-US">
<head>
    <meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
    <title>Subscription Invoice</title>
    <meta name="description" content="Subscription Receipt">
    <style type="text/css">
        #table {
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        #table td,
        #table th {
            border: 0.5px solid #dddddd;
            padding: 13px 0px;
        }

        #table tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        #table th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #f2f2f2;
            color: white;
        }

        td {
            max-width: 50%;
        }

        table {
            width: 100%;
            table-layout: fixed;
        }

        .conpany-logo {
            width: 35%;
            margin-top: 20px;
            background: #2a2a2a;
            padding: 10px;
            border-radius: 10px;
        }

    </style>
</head>

<body marginheight="0" topmargin="0" marginwidth="0" style="margin: 0px; background-color: #f2f3f8;" leftmargin="0">
    <table cellspacing="0" border="0" cellpadding="0" width="100%" bgcolor="#f2f3f8"
        style="@import url(https://fonts.googleapis.com/css?family=Rubik:300,400,500,700|Open+Sans:300,400,600,700); font-family: 'Open Sans', sans-serif;">
        <tr>
            <td>
                <table style="background-color: #f2f3f8; max-width:670px;  margin:0 auto;margin-top: 20px;" width="100%" border="0" align="center" cellpadding="0" cellspacing="0" id="table">
                    <tr>
                        <td style="text-align:center;background: #2a2a2a;">
                            <a href="{{ url('/') }}" title="logo" target="_blank">
                                <img src="{{asset('img/bsoft.png')}}" alt="" class="conpany-logo">
                            </a>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <table width="95%" border="0" align="center" cellpadding="0" cellspacing="0" style=" text-align:center;-webkit-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);-moz-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);box-shadow:0 6px 18px 0 rgba(0,0,0,.06);">
                                <tr>
                                    <td>Plan Name: </td>
                                    <td> {{ $user['Plan_name'] }}</td>
                                </tr>
                                <tr>
                                    <td>Plan Amount: </td>
                                    <td> $ {{ $user['amount'] }}</td>
                                </tr>
                                <tr>
                                    <td>Subscription Start Date : </td>
                                    <td> {{ date('M d, Y', strtotime($user['start_date'])) }}</td>
                                </tr>
                                <tr>
                                    <td>Subscription End Date : </td>
                                    <td> {{ date('M d, Y', strtotime($user['end_date'])) }}</td>
                                </tr>
                                @if(@$user['subscription_id']  != null)
                                <tr>
                                    <td>Subscription ID </td>
                                    <td> {{ $user['subscription_id'] }}</td>
                                </tr>
                                @endif
                                <tr>
                                    <td>License Key</td>
                                    <td> {{ $user['license_key'] }}</td>
                                </tr>
                                @if(@$user['url']  !="")
                                <tr>
                                    <td style="padding:0 35px;padding-bottom: 20px;" colspan="2">
                                        <span
                                            style="display:inline-block; vertical-align:middle; margin:29px 0 26px;  width:100px;"></span>
                                        <p style="color:#455056; font-size:15px;line-height:24px; margin:0;">
                                            If You want to download Your subscription Receipt Please Click
                                        </p>
                                        <a href="{{ $user['url'] }}"
                                            style="background:#212529;text-decoration:none !important; font-weight:500; margin-top:35px; color:#fff;text-transform:uppercase; font-size:14px;padding:10px 24px;display:inline-block;border-radius:50px;">Download
                                            Invoice</a>
                                    </td>
                                </tr>
                                @endif
                            </table>
                        </td>
                </table>
            </td>
        </tr>
    </table>
</body>

</html>
