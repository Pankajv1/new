<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password Reset Mail</title>
</head>
<body>
    <div>
        <table width="100%" cellpadding="0" cellspacing="0"
            style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative; background-color: rgba(237, 242, 247, 1); margin: 0; padding: 0; width: 100%">
            <tbody>
                <tr>
                    <td align="center" style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative">
                        <table width="100%" cellpadding="0" cellspacing="0" style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative; margin: 0; padding: 0; width: 100%">
                            <tbody>
                                <tr>
                                    <td
                                        style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative; padding: 25px 0; text-align: center">
                                        <a href="{{ url('/') }}"
                                            style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative; color: rgba(61, 72, 82, 1); font-size: 19px; font-weight: bold; text-decoration: none; display: inline-block">
                                            <img src="{{ asset('img/bsoft.png') }}" alt="" style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative; max-width: 100%; border: none; height: 75px; max-height: 75px; width: auto">
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td width="100%" cellpadding="0" cellspacing="0"
                                        style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative; background-color: rgba(237, 242, 247, 1); border-bottom: 1px solid rgba(237, 242, 247, 1); border-top: 1px solid rgba(237, 242, 247, 1); margin: 0; padding: 0; width: 100%">
                                        <table align="center" width="570" cellpadding="0" cellspacing="0"
                                            style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative; background-color: rgba(255, 255, 255, 1); border-color: rgba(232, 229, 239, 1); border-radius: 2px; border-width: 1px; box-shadow: 0 2px rgba(0, 0, 150, 0.02), 2px 4px rgba(0, 0, 150, 0.01); margin: 0 auto; padding: 0; width: 570px">
                                            <tbody>
                                                <tr>
                                                    <td
                                                        style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative; max-width: 100vw; padding: 32px">
                                                        <h1
                                                            style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative; color: rgba(61, 72, 82, 1); font-size: 18px; font-weight: bold; margin-top: 0; text-align: left">
                                                            Hello {{ $user->first_name . ' ' . $user->last_name }}!
                                                        </h1>
                                                        <p
                                                            style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative; font-size: 16px; line-height: 1.5em; margin-top: 0; text-align: left">
                                                            Congratulations! Your Passwor  has been successfully Reset
                                                            on <a href="{{ url('/login') }}">BsoftTechnology</a>
                                                        </p>
                                                        <p
                                                            style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative; font-size: 16px; line-height: 1.5em; margin-top: 0; text-align: left">
                                                            Please login with below mention credentials.
                                                        </p>
                                                        <p
                                                            style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative; font-size: 16px; line-height: 1.5em; margin-top: 0; text-align: left">
                                                            Username:- {{ $user->email }}
                                                        </p>
                                                        <p
                                                            style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative; font-size: 16px; line-height: 1.5em; margin-top: 0; text-align: left">
                                                            Password:- {{ $password }}
                                                        </p>
                                                        <table align="center" width="100%" cellpadding="0"
                                                            cellspacing="0"
                                                            style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative; margin: 30px auto; padding: 0; text-align: center; width: 100%">
                                                            <tbody>
                                                                <tr>
                                                                    <td align="center"
                                                                        style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative">
                                                                        <table width="100%" border="0" cellpadding="0"
                                                                            cellspacing="0"
                                                                            style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td align="center"
                                                                                        style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative">
                                                                                        <table border="0"
                                                                                            cellpadding="0" cellspacing="0" style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative">
                                                                                            <tbody>
                                                                                                <tr>
                                                                                                    <td
                                                                                                        style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative">
                                                                                                        <a href="{{ route('login') }}"
                                                                                                            rel="noopener"
                                                                                                            style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative; border-radius: 4px; color: rgba(255, 255, 255, 1); display: inline-block; overflow: hidden; text-decoration: none; background-color: rgba(45, 55, 72, 1); border-bottom: 8px solid rgba(45, 55, 72, 1); border-left: 18px solid rgba(45, 55, 72, 1); border-right: 18px solid rgba(45, 55, 72, 1); border-top: 8px solid rgba(45, 55, 72, 1)">Login</a>
                                                                                                    </td>
                                                                                                </tr>
                                                                                            </tbody>
                                                                                        </table>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                        <p
                                                            style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative; font-size: 16px; line-height: 1.5em; margin-top: 0; text-align: left">
                                                            Regards,<br>
                                                            BsoftTechnology
                                                        </p>
                                                        <table width="100%" cellpadding="0" cellspacing="0"
                                                            style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative; border-top: 1px solid rgba(232, 229, 239, 1); margin-top: 25px; padding-top: 25px">
                                                            <tbody>
                                                                <tr>
                                                                    <td
                                                                        style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative">
                                                                        <p
                                                                            style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative; line-height: 1.5em; margin-top: 0; text-align: left; font-size: 14px">
                                                                            If you're having trouble clicking the
                                                                            "Login" button, copy and paste the URL below
                                                                            into your web browser:
                                                                            <span
                                                                                style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative; word-break: break-all">
                                                                                <a href="{{ url('/login') }}"
                                                                                    style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative; color: rgba(56, 105, 212, 1)">{{ url('/login') }}
                                                                                </a>
                                                                            </span>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td
                                        style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative">
                                        <table align="center" width="570" cellpadding="0" cellspacing="0"
                                            style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative; margin: 0 auto; padding: 0; text-align: center; width: 570px">
                                            <tbody>
                                                <tr>
                                                    <td align="center"
                                                        style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative; max-width: 100vw; padding: 32px">
                                                        <p
                                                            style="box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; position: relative; line-height: 1.5em; margin-top: 0; color: rgba(176, 173, 197, 1); font-size: 12px; text-align: center">
                                                            © {{date('Y')}} BsoftTechnology. All rights reserved.
                                                        </p>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>
