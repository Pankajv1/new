@extends('layouts.appdashboard')
@section('content')
<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Customers</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="{{ route('home') }}">Dashboard</a></li>
                        <li class="breadcrumb-item active">Customers</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                @include('includes.message')
            </div>
            <div class="col-md-6">
            </div>
            <div class="col-md-6 text-right">
                <button class="btn btn-dark" data-toggle="modal" data-placement="bottom" title="Add Admin" data-target="#add_customer">Add Customer</button>
            </div>
        </div>
        <div class="row mt-5" style="padding-bottom:100px !important;">
            <div class="col-md-12">
                 <div class="table-responsive">
                <table class="table table-bordered table-striped" id="myTable">
                    <thead>
                        <tr>
                            <th >&#160;&#160;First&#160;Name&#160;&#160;</th>
                            <th > &#160;&#160;Last&#160;Name&#160;&#160;</th>
                            <th>Email</th>
                            <th>Company</th>
                            <th>Phone</th>
                            <th>Package </th>
                            <th >&#160;&#160;&#160;&#160;Start&#160;Date&#160;&#160;&#160;&#160;</th>
                            <th >&#160;&#160;&#160;&#160;End&#160;Date&#160;&#160;&#160;&#160;</th>
                            <th>Package Status</th>
                            <th>Trial Period</th>
                            <th >&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Action&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($customers as $item)
                            <tr>
                                <td>{{ $item->first_name }}</td>
                                <td>{{ $item->last_name }}</td>
                                <td>{{ $item->email }}</td>
                                
                                <td>{{ $item->company_name }}</td>
                                <td>{{ $item->phone }}</td>
                                <td>{{ Str::ucfirst($item->name) }}</td>
                                <td>{{ $item->subscription_start_date == "" ? "" :date('d-M-Y', strtotime($item->subscription_start_date)) }}</td>
                                <td>{{ $item->subscription_end_date == "" ? "" : date('d-M-Y', strtotime($item->subscription_end_date)) }}</td>
                                <td><span class="badge badge-{{Str::ucfirst($item->status) == "Active" ? "success":"danger"}}">{{ $item->status=="" ? "InActive": Str::ucfirst($item->status) }}</td>
                                <td>@if( Str::ucfirst($item->status) !="Active") <input type="button" value="Trial Period" class="btn btn-dark" onclick="trial_period({{$item->id}})"></span>@endif</td>
                                <td  >
                                    <a  data-toggle="tooltip" data-placement="bottom" title="Reset Password" data-id="{{ $item->id }}" class="btn btn-dark btn-md resetpwd" data-target="#reset_password">
                                        <i class="fa fa-key" aria-hidden="true"></i>
                                    </a>
                                    <a  data-toggle="tooltip" data-placement="bottom" title="History" data-id="{{ $item->id }}" attr ="{{$item->first_name}}" class="btn btn-dark btn-md history" data-target="#history">
                                        <i class="fa fa-history" aria-hidden="true"></i>
                                    </a>
                                    <a href="{{ url('fetch-user/' . $item->id) }}" data-toggle="modal" data-placement="bottom" title="Edit details" data-target="#editUser" data-id="{{ $item->id }}" class="btn btn-secondary btn-md editbtn">
                                        <i class="fas fa-pen"></i>
                                    </a>
                                    @if(Str::ucfirst($item->status) != "Active")
                                    <label class="switch" data-placement="bottom" title="Status">

                                        <input type="checkbox" @if(@$item->active_status == "Active") checked @endif data-id ={{ @$item->id}} class="status_update" >
                                        <span class="slider round"></span>
                                    </label>
                                    {{-- <a href="{{ url('delete-plan/' . $item->id) }}" data-toggle="tooltip" data-placement="bottom" title="Delete" data-id="{{ $item->id }}" class="btn btn-dark btn-md deletebtn">
                                        <i class="fas fa-trash"></i>
                                    </a> --}}
                                
                               @endif
                                   
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
             </div> 
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="reset_password" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <form id="reset_user_password"  method="POST" action="{{ route('reset.password') }}">
            @csrf
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Reset Password</h4>
                    <button type="button" class="close cancel" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <input type="hidden" value="" id="hidden_userID" name="hidden_userID">
                    <div class="form-group">
                        <label for="">New Password<span class="text-danger">*</span></label>
                        <input id="new_password" type="password" class="form-control" name="new_password"  >
                        <span toggle="#new_password" class="fa fa-lg fa-eye field-icon toggle-password"></span>
                    </div>
                    <div class="form-group">
                        <label for="">Confirm Password</label>
                        <input id="new_confirm_password" type="password" class="form-control" name="new_confirm_password" required>
                        <span toggle="#new_confirm_password" class="fa fa-lg fa-eye field-icon toggle-password"></span>
                    </div>

                  
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary add_user cancel" data-dismiss="modal">Cancel</button>
                    <input type="submit" value="Save" id="resetpassword" class="btn btn-dark">
                </div>
            </div>
        </form>
    </div>
</div>
<div class="modal fade" id="add_customer" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <form id="addcustomerform">
            @csrf
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Customer Details</h4>
                    <button type="button" class="close cancel" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="">First Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="first_name" id="fname" value="{{ old('name') }}" autofocus onkeydown="return /[a-zA-Z0-9 ]/i.test(event.key)">
                        <span id="lblError" style="color: red"></span>
                    </div>
                    <div class="form-group">
                        <label for="">Last Name</label>
                        <input type="text" class="form-control" name="last_name" value="{{ old('name') }}" autofocus onkeydown="return /[a-zA-Z0-9 ]/i.test(event.key)" >
                    </div>

                    <div class="form-group">
                        <label for="">Email<span class="text-danger">*</span></label>
                        <input id="email" type="email" class="form-control" name="email" value="{{ old('email') }}" >
                    </div>
                    <div class="form-group">
                        <label for="">Company Name</label>
                        <input id="company_name" type="text" class="form-control" name="company_name" value="{{ old('company_name') }}" autofocus onkeydown="return /[a-zA-Z0-9 ]/i.test(event.key)">
                    </div>
                    <div class="form-group">
                        <label for="">Phone No.</label>
                        <input id="phone" type="text" class="form-control phone-format" name="phone" value="{{ old('phone') }}" autocomplete="phone">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary add_user cancel" data-dismiss="modal">Cancel</button>
                    <input type="button" value="Save" id="ajaxSubmit" class="btn btn-dark">
                </div>
            </div>
        </form>
    </div>
</div>
<div class="modal fade" id="editUser" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <form id="updateUserForm">
            @csrf
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Edit Admin Details</h4>
                    <button type="button" class="close cancelbtn cancel" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="">First Name<span class="text-danger">*</span></label>
                        <input type="hidden" id="id_val" name="id">
                        <input type="text" class="form-control" name="first_name" id="edit_fname" value="{{ old('name') }}" autocomplete="name" autofocus onkeydown="return /[a-zA-Z0-9 ]/i.test(event.key)">
                    </div>
                    <div class="form-group">
                        <label for="">Last Name</label>
                        <input type="text" class="form-control" name="last_name" id="edit_lname" value="{{ old('name') }}" autofocus onkeydown="return /[a-zA-Z0-9 ]/i.test(event.key)" >
                    </div>

                    <div class="form-group">
                        <label for="">Email<span class="text-danger">*</span></label>
                        <input id="edit_email_address" type="email" class="form-control" name="email" value="{{ old('email') }}" >
                    </div>
                    <div class="form-group">
                        <label for="">Company Name</label>
                        <input id="edit_company_name" type="text" class="form-control" name="company_name" value="{{ old('company_name') }}" autofocus onkeydown="return /[a-zA-Z0-9 ]/i.test(event.key)">
                    </div>
                    <div class="form-group">
                        <label for="">Phone No.</label>
                        <input id="edit_phone" type="text" class="form-control phone-format" name="phone" value="{{ old('phone') }}" autocomplete="phone">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary add_user cancelbtn cancel" data-dismiss="modal">Cancel</button>
                    <input type="submit" value="Update" id="updateUserForm" class="btn btn-dark">
                </div>
            </div>
        </form>
    </div>
</div>

  
    
    <!-- The Modal -->
  <div  id="historymodal" class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
  
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title" id="c_name">Customer History</h4>
          <button type="button" class="close cancelbtn cancel" data-dismiss="modal">&times;</button>
        </div>
  
        <!-- Modal body -->
        <div class="modal-body">
            <table class="table table-striped">
      <thead>
        <tr>
          <th>IP Address</th>
          <th>Login</th>
          <th>Logout</th>
        </tr>
      </thead>
      <tbody id="historybody">
        
      </tbody>
    </table>
    </div>
  
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-dark cancelbtn cancel" data-dismiss="modal">Close</button>
        </div>
  
      </div>
    </div>
  </div>
  </div>


@endsection
@section('script')
<script>
    $(document).ready(function() {
        $('.resetpwd').click(function(e) 
        {
           
           var userID =  $(this).data("id");
           $('#reset_password').modal('toggle');
           $('#reset_password').modal('show');
           $('#hidden_userID').val(userID);
        })
        $("#add_customer").on("hidden.bs.modal", function(){
			  $('#fname-error').html('');
              $('#email-error').html('');
              $(this).find('form').trigger('reset');
        }); 
        $(".phone-format").keypress(function (e) {
    if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
      return false;
    }
    var curchr = this.value.length;
    var curval = $(this).val();
    if (curchr == 3 && curval.indexOf("(") <= -1) {
      $(this).val("+1(" + curval + ")" + "-");
    } else if (curchr == 6 && curval.indexOf("(") > -1) {
      $(this).val(curval + ")-");
    } else if (curchr == 8 && curval.indexOf(")") > -1) {
      $(this).val(curval + "-");
    } else if (curchr == 11) {
      $(this).val(curval + "-");
      $(this).attr('maxlength', '16');
    }
  });
        jQuery.validator.addMethod("lettersonly", function(value, element) 
            {
                return this.optional(element) || /^[a-z," "]+$/i.test(value);
            }, "Letters and spaces only please");

        jQuery.validator.addMethod("customemail", 
            function(value, element) {
            return /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.((com)|(org)|(co.in)|(net))$/.test(value);
            }, 
        "Sorry, the domain extension is not allowed."
        );
        $('#myTable').DataTable({
            "paging": true,
            fixedHeader:true
        });
        var validator = $('#addcustomerform').validate({
            rules: {
                first_name: {
                    required: true,
                },
                email: {
                    required: true,
                    customemail: true,
                },
            },
            messages: {
                first_name: {
                    required: "First Name is required.",
                },
                email: {
                    required: "Email is required",
                    customemail: "Please enter a valid email address."
                },
            },
            errorPlacement: function(label, element) {
                label.addClass(' text-danger');
                element.parent().append(label);

            },
        });
        $(".cancel").click(function() {
            validator.resetForm();
           
           $('.modal fade').modal('hide');
           
           $('#reset_password').modal('hide');
           $('#historymodal').modal('hide');
           
        });
        jQuery('#ajaxSubmit').click(function(e) {
        e.preventDefault();

        if ($('#addcustomerform').valid() == false) {
            return false;
        }

        let formData = $('#addcustomerform').serialize();
        
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            }
        });

        jQuery.ajax({
            url: "{{ url('savecustomer') }}",
            dataType: "json",
            method: 'post',
            data: formData,
            beforeSend:function() {
                swal({
                    title: "Processing",
                    text: 'Please Wait...',
                    buttons:false,
                    icon: "warning",
                    allowOutsideClick: false,
                    allowEscapeKey: false
                });
            },
            success: function(result) {
                swal.close();
                if (result.status) {
                    swal({
                        title: "Done",
                        text: result.message, 
                        icon: "success",
                        closeOnClickOutside: false,
                        dangerMode: false,
                    })
                    .then((willDelete) => {
                        if (willDelete) {
                            location.reload();
                        }
                    });
                } else {
                    swal("Oops!", result.message, 'error');
                    swal({
                        title: "Oops!",
                        text: result.message, 
                        icon: "error",
                        closeOnClickOutside: false,
                        dangerMode: false,
                    })
                    .then((willDelete) => {
                        if (willDelete) {
                           
                        }
                    });
                }  
            },
            error: function(error) {
                swal({
                    title: "Oops!",
                    text: "Something went wrong. Try again later.", 
                    icon: "error",
                    closeOnClickOutside: false,
                    dangerMode: false,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        //location.reload();
                    }
                });
            }
        });
    });
    $(document).on('click','.editbtn',function(e) {
     
        let id = $(this).attr('data-id');
            
            $.ajax({
                url : "{{ url('fetch-user') }}",
                type: 'GET',
                data : {
                    id:id,
                  _token:"{{ csrf_token() }}"
                },
                success:function(output) {
                    console.log(output);
                    if (output.status) {
                      // alert(output.data.password)
                      $('#id_val').val(output.data.id);
                      $('#edit_fname').val(output.data.first_name);
                      $('#edit_lname').val(output.data.last_name);
                      $('#edit_email_address').val(output.data.email);
                      $('#edit_company_name').val(output.data.company_name);
                      $('#edit_phone').val(output.data.phone);

                      $('#editUser').css('display','block');
                      $('#editUser').addClass('show');
                    }
                },
                error:function(err) {
                  alert(err);
                }
            });
      });
      var validates = $('#updateUserForm').validate({
            rules: {
                first_name: {
                    required: true,
                },
                email: {
                    required: true,
                    customemail: true
                },
            },
            messages: {
                first_name: {
                    required: "First Name is required.",
                },
                email: {
                    required: "Email is required",
                    customemail: "Please enter a valid email address."
                },
            },
            errorPlacement: function(label, element) {
                label.addClass(' text-danger');
                element.parent().append(label);

            },
        });
        $(document).on('submit','#updateUserForm',function(e) {


        e.preventDefault();
        
        if ($('#updateUserForm').valid() == false) {
            return false;
        }

        var form = $('#updateUserForm')[0];
        let formData = new FormData(form);
            
        formData.append('_token',"{{ csrf_token() }}");

        $.ajax({
            url : "{{ url('update-user') }}",
            type: 'post',
            data : formData,
            contentType: false,
            cache: false,
            processData:false,
            beforeSend:function() {
                swal({
                    title: "Processing",
                    text: 'Please Wait...',
                    buttons:false,
                    icon: "warning",
                    allowOutsideClick: false,
                    allowEscapeKey: false
                });
            },
            success: function(output) {
                swal.close();
                if (output.status) {
                    swal({
                        title: "Done",
                        text: output.message, 
                        icon: "success",
                        closeOnClickOutside: false,
                        dangerMode: false,
                    })
                    .then((willDelete) => {
                        if (willDelete) {
                            location.reload();
                        }
                    });
                } else {
                    swal("Oops!", output.message, 'error');
                    swal({
                        title: "Oops!",
                        text: output.message, 
                        icon: "error",
                        closeOnClickOutside: false,
                        dangerMode: false,
                    })
                    .then((willDelete) => {
                        if (willDelete) {
                           // location.reload();
                        }
                    });
                }  
            },
            error: function(error) {
                swal({
                    title: "Oops!",
                    text: "Something went wrong. Try again later.", 
                    icon: "error",
                    closeOnClickOutside: false,
                    dangerMode: false,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        //location.reload();
                    }
                });
            }
        });
       $('.resetpwd').click(function(e) 
        {
           
           var userID =  $(this).data("id");
           $('#reset_password').modal('toggle');
           $('#reset_password').modal('show');
           $('#hidden_userID').val(userID);
        })
    });
    $(document).on('click', '.deletebtn', function (e) {
        //    alert('here');
        e.preventDefault();
        let id = $(this).attr('data-id');

        swal({
            title: "Are you sure you want to delete?",
            text: "Once deleted, you will not be able to recover this record!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
            })
            .then((willDelete) => {
            if (willDelete) {
                $.ajax({
                    type: "post",
                    data : {
                            id:id,
                            _token:"{{ csrf_token() }}"
                        },
                    url: "{{ url('delete-user') }}",
                    
                    success: function (output){
                        
                        if (output.status) {
                            swal("Your record has been deleted Successfully!", {
                            icon: "success",
                            }).then(function(){ 
                                location.reload();
                            });
                            // location.reload();
                        } else {
                            alert(output.message);
                        }
                    
                    },
                    error: function (output) {
                        console.log('Error:', output);
                    }
                });
            } else {
                //swal("Your record is safe!");
            }
        });          
    });   
    $('#reset_user_password').validate({
                rules: {
					
                    new_password: {
                        required: true,
                        minlength: 8,
					     
                    },
                    new_confirm_password: {
						 minlength: 8,
                         equalTo: "#new_password"
                    }                
                },
                messages: {
                    new_password: {
                        required: "New Password is required",
						minlength:"Password must be minimum length 8",
						
                      
                    },
                    new_confirm_password: {
                        required: "Confirm New Password is required.",
                        equalTo: "New Password And Confirm New Password must be same!"
                    },
                   
                },
                errorPlacement: function(label, element) {
                    label.addClass('mt-2 text-danger');
                    element.parent().append(label);
                },
                submitHandler: function(form) {
                    $(form).submit();
                }
            });
            $(".toggle-password").click(function() {

                $(this).toggleClass("fa-eye fa-eye-slash");
                var input = $($(this).attr("toggle"));
                if (input.attr("type") == "password") {
                input.attr("type", "text");
                } else {
                input.attr("type", "password");
                }
            });
    });
    function trial_period(userID)
    {
       
       var csrf_token="{{csrf_token()}}";
            jQuery.ajax({
                url: "/trial_period",
                method: 'post',
                data: {
                    userID: userID,
                '_token':csrf_token
                
                },
                success: function(result){
                    if(result == 'success') {
                        swal(result, "", "success");
                        setTimeout(() => {
                            location.reload(true);
                        }, 1000);
                    } else {
                        swal({
                            title: result,
                            icon: "warning",
                            dangerMode: true,
                        });
                    } 
                }
            });
    }
    $(document).on('click', '.history', function (e) 
        {
            var user_name = $(this).attr('attr');
            var userID = $(this).data('id')
            var csrf_token="{{csrf_token()}}";
            $('#c_name').html(user_name+"  History");
            jQuery.ajax({
                url: "/history",
                method: 'post',
                data: {
                    userID: userID,
                '_token':csrf_token
                
                },
                success: function(result){
                    console.log(result.data);
                 if(result.data.length == 0)
                 {
                    var html ='<tr><td colspan="3">No History Found</td></tr>';
                    $('#historymodal').modal('show');
                        $('#historybody').html(html);
                        
                    
                 }
                 else
                 {
                    var html = '';
                    result.data.forEach(function (userdata) {
                        console.log(userdata.id);
                            html +=`<tr><td>${userdata.ip_address}</td><td>${userdata.login_at}</td><td>${userdata.logout_at}</td></tr>`;
                        });
                        
                        $('#historymodal').modal('show');
                        $('#historybody').html(html);
                 }
                }
            })
        })
     $(document).on('click', '.status_update', function (e) 
      {
       var userID =  $(this).closest('.status_update').attr('data-id');
       var csrf_token="{{csrf_token()}}";
            jQuery.ajax({
                url: "/change-user-status",
                method: 'post',
                data: {
                    userID: userID,
                '_token':csrf_token
                
                },
                success: function(result){
                    if(result == 'error') {
						swal({
                            title: "Something Went Wrong !",
                            icon: "warning",
                            dangerMode: true,
                        });
                        
                    } else {
                        swal("User "+result+" successfully!", "", "success");
                    } 
                }
            });
        });
</script>
@endsection
