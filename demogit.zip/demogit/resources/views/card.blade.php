@extends('layouts.app')
@section('content')
<section>
    <div class="container">
        <div class="row gx-0 gy-3">
            <div class="col-md-12">
                @include('includes.message')
            </div>
            <div class="col-md-6">
                <div class="pricing-block mb-0 cardBlock">
                    <div class="inner-box first-pay-height">
                        <div class="icon-box">
                            <div class="icon-outer"><i class="fa fa-usd" aria-hidden="true"></i></div>
                        </div>
                        <div class="price-box">
                            <div class="title">{{ $plan->name }}</div>
                            <h4 class="price">USD ${{ $plan->amount }} </h4>
                            <h4 class="price">
                                @if($plan->duration == "week" || $plan->duration == "month" || $plan->duration == "yesr")
                                    {{ Str::ucfirst($plan->duration)."ly" }}
                                @else
                                    {{ Str::ucfirst($plan->duration) }}
                                @endif
                            </h4>
                        </div>
                        <ul class="features">
                            @foreach (json_decode($plan->features) as $feature)
                                <li class="true">{{ $feature }}</li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
			         
                <form action="/stripecustomer" method="POST" id="payment-form" class="datpayment-form pymntForm">
                    @csrf
                    <div class="dpf-card-placeholder">
					<div class="text-center font-weight-bold" style="font-size: 25px; background-color: #40cbb4;border-radius: 6px;">
                    @if(@$subscription->amount_due  && $subscription->plan_id != $plan->id)
                    <div > <span>Pay Amount $ {{($subscription->amount_due != 0)?$subscription->amount_due/100:"0"}} <span>
                    </div>
                    @elseif ($subscription === null ) 
                    <div > <span>Pay Amount $ {{$plan->amount}} <span></div>
                    
                     @elseif($subscription !== null && $subscription->plan_id != $plan->id)
                       @if(isset($subscription->amount_due))
                         <div > <span>Pay Amount $ {{0}}<span></div>
                       @else
                       <div > <span>Pay Amount $ {{$plan->amount}} <span></div>
                      @endif
                   @endif
               </div>
					</div>
                    <div class="dpf-input-container">
                        <div class="dpf-input-row">
                            <input type="hidden" value="{{ $plan->id }}" name="plan_id">
                            <input type="hidden" value="{{ $plan->duration }}" name="plan_name">
                            <input type="hidden" value="{{ $plan->amount }}" name="plan_amount">
                            <label class="dpf-input-label">Card number</label>
                            <div class="dpf-input-container with-icon">
                                <span class="dpf-input-icon"><i class="fa fa-credit-card" aria-hidden="true"></i></span>
                                <input type="text" class="dpf-input" size="20" id="card_number" data-type="number" name="number">
                                <input type="hidden" class="dpf-input" id="card_number2" id="card_number2" name="number">
                            </div>
                        </div>
                
                        <div class="dpf-input-row">
                            <div class="dpf-input-column">
                                <input type="hidden" size="2" data-type="exp_month" placeholder="MM" name="exp_month">
                                <input type="hidden" size="2" data-type="exp_year" placeholder="YY" name="exp_year">
                
                                <label class="dpf-input-label">Exp Date</label>
                                <div class="dpf-input-container">
                                    <input type="text" class="dpf-input" id="expiry" data-type="expiry" name="expiry">
                                </div>
                            </div>
                            <div class="dpf-input-column ml-3">
                                <label class="dpf-input-label">CVV</label>
                                <div class="dpf-input-container">
                                    <input type="text" class="dpf-input" size="4" id="cvv" data-type="cvc" name="cvc">
                                </div>
                            </div>
                        </div>
                
                        <div class="dpf-input-row">
                            <label class="dpf-input-label">Name of Holder</label>
                            <div class="dpf-input-container">
                                <input type="text" size="4" class="dpf-input" data-type="name" id="name_on_card" name="name">
                            </div>
                        </div>
                        <div class="dpf-input-row chechitem">
                            <label for="terms_agree" class="checklbl">
                                <input type="checkbox" id="terms_agree" />
                                Your Card is saved for recurring payments.
                            </label>
                        </div>
                        <button type="button" onclick="cardFormValidate()" class="dpf-submit">
                            @if($subscription->plan_id != $plan->id)
                                  Pay now
                                  @else
                                  Add Card
                                @endif
                        </button>
                        <div id="demo-log" class="invisible"></div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

@endsection
@section('script')
<script src="https://igorescobar.github.io/jQuery-Mask-Plugin/js/jquery.mask.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-creditcardvalidator/1.2.0/jquery.creditCardValidator.js" integrity="sha512-L4i6hMNkLZn8tib5ZqsaUt1ehC0ckCpMjMTGIO5anwZqTxqDf5tTXklmxeqYIFWey6IDSzICxKNr7dQcUhPYDQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script type="text/javascript">
    function cardFormValidate(){
        var cardValid = 0;
        //card number validation
        $('#card_number2').validateCreditCard(function(result){
            if(result.valid) {
                $("#card_number").removeClass('required');
                $("#card_number").parent().removeClass('dpf-row-invalid');
                cardValid = 1;
                console.log("valid");
            } else {
                console.log("invalid");
                $("#card_number").addClass('required');
                $("#card_number").parent().addClass('dpf-row-invalid');
                cardValid = 0;
            }
        });
        
        //card details validation
        var cardName = $("#name_on_card").val();
        var expiry = $("#expiry").val();
        expiry = expiry.split(' / ');
        var expMonth = expiry[0];
        var expYear = expiry[1];
        var cvv = $("#cvv").val();
        var regName = /^[a-z ,.'-]+$/i;
        var regMonth = /^01|02|03|04|05|06|07|08|09|10|11|12$/;
        var expression =  `^${new Date().getFullYear().toString().substr(-2)}|${(+new Date().getFullYear().toString().substr(-2) + +1)}|${(+new Date().getFullYear().toString().substr(-2) + +2)}|${(+new Date().getFullYear().toString().substr(-2) + +3)}|${(+new Date().getFullYear().toString().substr(-2) + +4)}$`;
        var regYear = new RegExp(expression); ///^22|23|24|25|26$/;
        var terms_agree = $("#terms_agree").is(":checked");
        // console.log(terms_agree);
        // return false;
        var regCVV = /^[0-9]{3,3}$/;
        if (cardValid == 0) {
            console.log("valid2");
            $("#card_number").addClass('required');
            $("#card_number").parent().addClass('dpf-row-invalid');
            $("#card_number").focus();
            return false;
        }else if (!regMonth.test(expMonth)) {
            $("#card_number").removeClass('required');
            $("#card_number").parent().removeClass('dpf-row-invalid');
            $("#expiry").addClass('required');
            $("#expiry").parent().addClass('dpf-row-invalid');
            $("#expiry").focus();
            return false;
        }else if (!regYear.test(expYear)) {
            $("#card_number").removeClass('required');
            $("#card_number").parent().removeClass('dpf-row-invalid');
            $("#expiry").addClass('required');
            $("#expiry").parent().addClass('dpf-row-invalid');
            $("#expiry").focus();
            return false;
        }else if (!regCVV.test(cvv)) {
            $("#card_number").removeClass('required');
            $("#card_number").parent().removeClass('dpf-row-invalid');
            $("#expiry").removeClass('required');
            $("#expiry").parent().removeClass('dpf-row-invalid');
            $("#cvv").addClass('required');
            $("#cvv").parent().addClass('dpf-row-invalid');
            $("#cvv").focus();
            return false;
        } else if (!regName.test(cardName)) {
            $("#card_number").removeClass('required');
            $("#card_number").parent().removeClass('dpf-row-invalid');
            $("#expiry").removeClass('required');
            $("#expiry").parent().removeClass('dpf-row-invalid');
            $("#cvv").removeClass('required');
            $("#cvv").parent().removeClass('dpf-row-invalid');
            $("#name_on_card").addClass('required');
            $("#name_on_card").parent().removeClass('dpf-row-invalid');
            $("#name_on_card").focus();
            return false;
        } else if (!terms_agree) {
            $(".chechitem").append('<span style="color:red">Please check this checkbox.</span>');
            return false;
        } else {
            $("#card_number").removeClass('required');
            $("#card_number").parent().removeClass('dpf-row-invalid');
            $("#expiry").removeClass('required');
            $("#expiry").parent().removeClass('dpf-row-invalid');
            $("#cvv").removeClass('required');
            $("#cvv").parent().removeClass('dpf-row-invalid');
            $("#name_on_card").removeClass('required');
            $("#name_on_card").parent().removeClass('dpf-row-invalid');
            $(".dpf-submit").html('Processing');
            $(".dpf-submit").prop('disabled', true);
            $("#payment-form").submit();
            return true;
        }
    }
    $(document).ready(function() {
        $("#card_number").change(function(){
            let card_number = $(this).val();
            $("#card_number2").val(card_number.replace(/ /g,''));
        })
    });
    var payment_form = new DatPayment({
        form_selector: '#payment-form',
        card_container_selector: '.dpf-card-placeholder',
        number_selector: '.dpf-input[data-type="number"]',
        date_selector: '.dpf-input[data-type="expiry"]',
        cvc_selector: '.dpf-input[data-type="cvc"]',
        name_selector: '.dpf-input[data-type="name"]',
        submit_button_selector: '.dpf-submit',
        placeholders: {
            number: '•••• •••• •••• ••••',
            expiry: '••/••',
            cvc: '•••',
            name: 'Enter the card holder name'
        },
        validators: {
            number: function(number) {
                return Stripe.card.validateCardNumber(number);
            },
            expiry: function(expiry) {
                var expiry = expiry.split(' / ');
                return Stripe.card.validateExpiry(expiry[0] || 0, expiry[1] || 0);
            },
            cvc: function(cvc) {
                return Stripe.card.validateCVC(cvc);
            },
            name: function(value) {
                return value.length > 0;
            }
        }
    });
    var demo_log_div = document.getElementById("demo-log");
    payment_form.form.addEventListener('payment_form:submit', function(e) {
        var form_data = e.detail;
        payment_form.unlockForm();
        demo_log_div.innerHTML += "<br>" + JSON.stringify(form_data);
    });
    payment_form.form.addEventListener('payment_form:field_validation_success', function(e) {
        var input = e.detail;
        demo_log_div.innerHTML += "<br>field_validation_success:" + input.getAttribute("data-type");

    });
    payment_form.form.addEventListener('payment_form:field_validation_failed', function(e) {
        var input = e.detail;
        demo_log_div.innerHTML += "<br>field_validation_failed:" + input.getAttribute("data-type");
    });
</script>
@endsection