@extends('layouts.apptest')

@section('content')
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard v1</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">

            @if (session('status'))
                <h6 class="alert alert-success">
                    {{ session('status') }}
                </h6>
            @endif

            <div class="card">
                <div class="card-header">
                    <h4>Add plan details</h4>
                </div>
                <div class="card-body">

                    <form action="{{ url('save-planeuser') }}" method="POST">
                        @csrf

                        <div class="form-group mb-3">
                            <label for="">Plan Name</label>
                            <input type="text" name="name" class="form-control" required autocomplete="name">
                        </div>
                        <div class="form-group mb-3">
                            <label for="">Plan Amount</label>
                            <input type="text" name="amount" class="form-control" required autocomplete="amount">
                        </div>
                        <div class="form-group mb-3">
                        <label for="Plane Duration">Plan Duration</label>
                        <select name="duration" id="plane_duration" class="form-control">
                          <option value="3 months">3 months</option>
                          <option value="6 months">6 months</option>
                          <option value="9 months">9 months</option>
                          <option value="12 months">12 months</option>
                        </select>
                        </div>
                        <div class="input_fields_remove">
                            <label for="">Plan Features</label>
                            <style> 
                              input {
                                    width: 95%;
                            }
                            </style>
                            <input type="text" name="features[]" required autocomplete="features[]" >
                            <a class="add_field_button"><i class="fa fa-plus" aria-hidden="true"></i></a>
                        </div><br>
                        <div class="form-group mb-3">
                            <button style = "position:relative; right:-360px; bottom:-37px" type="submit" class="btn btn-primary">Save</button><br>
                            <a href="{{ url('planes') }}" class="btn btn-danger float-end">Next</a>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
    <!-- /.content -->
</div>
<script>
$(document).ready(function() {
    
	var max_fields      = 10;
	var remove   		= $(".input_fields_remove");
	var add_button      = $(".add_field_button");
	
	var x = 1;
	$(add_button).click(function(e){
	
    //    console.log('testing');
		if(x < max_fields){ 
			x++;
			$(remove).append('<div><label for="">Plane Features</label> <input type="text" name="features[]"/><a class="remove_field"> <i class="fa fa-minus" aria-hidden="true"></i></a></div>');
		}
	});
	
	$(document).on("click",".remove_field", function(e){
		e.preventDefault();
        $(this).parent('div').remove();
        x--;
	})
});
</script>
@endsection


