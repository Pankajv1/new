@extends('layouts.appdashboard')
@section('content')
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Active Licenses</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="{{ route('home') }}">Dashboard</a></li>
                            <li class="breadcrumb-item active">Active Licenses</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    @include('includes.message')
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-md-12">
                    <table class="table table-bordered table-striped" id="myTable">
                        <thead>
                            <tr>
                                <th>Domain Name</th>
                                <th>Activation Date</th>
                                <th>License Valid Till</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($activeLicense as $license)
                                <tr>
                                    <td><a href="{{ $license->domain_name }}" target="_blank">{{ $license->domain_name }}</a></td>
                                    <td>{{ date("M d, Y", strtotime($license->activation_date)) }}</td>
                                    <td>{{ date("M d, Y", strtotime($license->subscription_end_date)) }}</td>
                                    <td>{{ Str::ucfirst($license->status) }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('script')
<script>
    $(document).ready(function() {
        $('#myTable').DataTable();
    });
</script>
@endsection
