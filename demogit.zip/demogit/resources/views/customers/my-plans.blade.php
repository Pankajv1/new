@extends('layouts.appdashboard')
@section('content')
    <div class="content-wrapper">
        <section class="pricing-section mb-5">
            <div class="sec-title p-4 text">
                <h2 class="d-inline">{{ ($subscription !== null) ? 'My Active' : 'Purchase' }} Subscription</h2>
                @if($subscription !== null)<h2 class="d-inline" style="float: right;">License Key :   <div id="license" style="display:none;">{{$subscription->license_key}}</div><span style="font-size: 20px;">{{substr($subscription->license_key, 0, 5)}}....<span><button id="lisence_key_copy" class="btn btn-dark"  onclick="copyText('license');" >Copy</button></h2>@endif
            </div>
            <div class="container mt-3">
               
                <div class="outer-box">
                    <div class="row">
                        <div class="col-lg-9 col-md-5 col-sm-5 text-bold m-auto mt-2 mb-1">
                            @include('includes.message')
                        </div>
                        <ul class="nav nav-pills mb-3 m-auto d-flex justify-content-center align-items-center" id="pills-tab" role="tablist">
                           
                            @foreach ($plans as $key => $plan)
                                @if ($subscription !== null && $plan->id == $subscription->plan_id || $plan->status == "Active")
                                    <li class="nav-item  col-lg-3 col-md-6 col-sm-12" role="presentation">
                                        <a class="nav-link {{ ($subscription === null && $key+1 == 1) ? 'active': ($subscription !== null && $plan->id == $subscription->plan_id) ? 'active' : '' }} w-100" id="pills-{{$key+1}}-tab" data-bs-toggle="pill" data-bs-target="#plan-{{$key+1}}" type="button" role="tab" aria-controls="pills-home" aria-selected="false">
                                            <div class="row card-design m-auto" id="bg{{ $key+1 }}">
                                                <div class="col-4 col-lg-5 col-md-5 col-sm-12">
                                                    <div class="icon-box" id="bg{{ $key+1 }}-icon">
                                                        <i class="fas fa-dollar-sign"></i>
                                                    </div>
                                                </div>
                                                <div class="price-box col-8 col-lg-7 col-md-7 col-sm-12 p-0">
                                                    <div class="card-content">
                                                        <div class="main-content text-dark">{{ Str::ucfirst($plan->name) }}</div>
                                                        <h4 class="sub-content">${{$plan->amount}}</h4>
                                                        <h4 class="sub-content">
                                                            @if($plan->duration == "week" || $plan->duration == "month" || $plan->duration == "yesr")
                                                                {{ Str::ucfirst($plan->duration)."ly" }}
                                                            @else
                                                                {{ Str::ucfirst($plan->duration) }}
                                                            @endif
                                                        </h4>
                                                    </div>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                @endif
                            @endforeach
                        </ul>
                           
                        <div class="col-lg-5 col-md-5 col-sm-5 text-center m-auto mt-4 mb-5">
                            <div class="tab-content" id="pills-tabContent">
                                @if($delete_plan != null)
                                @foreach ($delete_plan as $key => $plan)
                                @if ($subscription !== null && $plan->id == $subscription->plan_id || $plan->status == "Active")
                                    <div class="tab-pane fade show {{ ($subscription === null && $key == 1) ? 'active': ($subscription !== null && $plan->id == $subscription->plan_id) ? 'active' : '' }}" id="plan-{{$key}}" role="tabpanel" aria-labelledby="pills-{{$key}}-tab">
                                        <div class="row m-auto main-contnt-box ">
                                            <div class="col-lg-12 col-md-12 col-sm-12 d-flex justify-content-center">
                                                <div class="main-content-iconset">
                                                    <i class="fas fa-dollar-sign"></i>
                                                </div>
                                            </div>
                                            <div class="price-box col-lg-12 col-md-12 col-sm-12 p-0">
                                                <div class="card-content p-0 m-0 ml-2 text-center">
                                                    <h2 class="tab-main-subcontent p-2 fbig-globe">${{ $plan->amount }}/<span>{{ Str::ucfirst($plan->name) }}</span></h2>
                                                    @foreach (json_decode($plan->features) as $feature)
                                                        <hr>
                                                        <div class="tab-main-content p-1">
                                                            <h4>{{ $feature }}</h4>
                                                        </div>    
                                                    @endforeach
                                                    @if ($subscription != null && $plan->id == $subscription->plan_id)
                                                        <hr>
                                                        <div class="tab-main-content p-1">
                                                            <h4>Start Date - {{ date("M d, Y", strtotime($subscription->latestInvoice->subscription_start_date)) }}</h4>
                                                        </div>
                                                        <hr>
                                                        <div class="tab-main-content p-1">
                                                            <h4>End Date - {{ date("M d, Y", strtotime($subscription->latestInvoice->subscription_end_date)) }}</h4>
                                                        </div>
                                                        <hr>
                                                        <div class="tab-main-content p-1">
                                                            <h4>Next Billing Date - {{ date("M d, Y", strtotime($subscription->latestInvoice->subscription_end_date)) }}</h4>
                                                        </div>
                                                    @endif
                                                    <hr>
                                                    <div class="tab-main-content p-1">
                                                        <h4>No. of Domains - {{ $plan->no_of_domains }}</h4>
                                                    </div>
                                                    <hr>
                                                    <div class="mt-4 mb-2">
                                                    
                                                        @if($subscription != null && $plan->id == $subscription->plan_id)
              
                                                            <a href="{{ route('invoices') }}" class="btn btn-dark">Invoices</a>
                                                            <a href="{{ route('cancel.plan', [base64_encode($subscription->id)]) }}" class="btn btn-secondary" onclick="cancelConfirmation(event)" data-subscription-id="{{ $subscription->id }}">Cancel Subscription</a>
                                                        @else 
                                                            <a  href="{{ route('show.update.newplan', [base64_encode($plan->id)]) }}" class="btn btn-dark" class="btn btn-dark">Subscribe</a>
                                                        @endif
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endif
                            @endforeach
                            @endif
                                @foreach ($plans as $key => $plan)
                                    @if ($subscription !== null && $plan->id == $subscription->plan_id || $plan->status == "Active")
                                        <div class="tab-pane fade show {{ ($subscription === null && $key+1 == 1) ? 'active': ($subscription !== null && $plan->id == $subscription->plan_id) ? 'active' : '' }}" id="plan-{{$key+1}}" role="tabpanel" aria-labelledby="pills-{{$key+1}}-tab">
                                            <div class="row m-auto main-contnt-box ">
                                                <div class="col-lg-12 col-md-12 col-sm-12 d-flex justify-content-center">
                                                    <div class="main-content-iconset">
                                                        <i class="fas fa-dollar-sign"></i>
                                                    </div>
                                                </div>
                                                <div class="price-box col-lg-12 col-md-12 col-sm-12 p-0">
                                                    <div class="card-content p-0 m-0 ml-2 text-center">
                                                        <h2 class="tab-main-subcontent p-2 fbig-globe">${{ $plan->amount }}/<span>{{ Str::ucfirst($plan->name) }}</span></h2>
                                                        @foreach (json_decode($plan->features) as $feature)
                                                            <hr>
                                                            <div class="tab-main-content p-1">
                                                                <h4>{{ $feature }}</h4>
                                                            </div>    
                                                        @endforeach
                                                        @if ($subscription != null && $plan->id == $subscription->plan_id)
                                                            <hr>
                                                            <div class="tab-main-content p-1">
                                                                <h4>Start Date - {{ date("M d, Y", strtotime($subscription->latestInvoice->subscription_start_date)) }}</h4>
                                                            </div>
                                                            <hr>
                                                            <div class="tab-main-content p-1">
                                                                <h4>End Date - {{ date("M d, Y", strtotime($subscription->latestInvoice->subscription_end_date)) }}</h4>
                                                            </div>
                                                            <hr>
                                                            <div class="tab-main-content p-1">
                                                                <h4>Next Billing Date - {{ date("M d, Y", strtotime($subscription->latestInvoice->subscription_end_date)) }}</h4>
                                                            </div>
                                                        @endif
                                                        <hr>
                                                        <div class="tab-main-content p-1">
                                                            <h4>No. of Domains - {{ $plan->no_of_domains }}</h4>
                                                        </div>
                                                        <hr>
                                                        <div class="mt-4 mb-2">
                                                        
                                                            @if($subscription != null && $plan->id == $subscription->plan_id)
                                                              @if($plan->duration !="trial")
                                                                <a href="{{ route('show.update.plan', [base64_encode($subscription->id)]) }}" class="btn btn-dark">Update Card</a>
                                                              @endif
                                                                <a href="{{ route('invoices') }}" class="btn btn-dark">Invoices</a>
                                                                <a href="{{ route('cancel.plan', [base64_encode($subscription->id)]) }}" class="btn btn-secondary" onclick="cancelConfirmation(event)" data-subscription-id="{{ $subscription->id }}">Cancel Subscription</a>
                                                            @else 
                                                                @if($plan->duration =="trial")
                                                                <a  href="{{ route('show.update.trialplan', [base64_encode($plan->id)]) }}" class="btn btn-dark" class="btn btn-dark">Subscribe</a>
                                                                @else
                                                                <a  href="{{ route('show.update.newplan', [base64_encode($plan->id)]) }}" class="btn btn-dark" class="btn btn-dark">Subscribe</a>
                                                                @endif
                                                            @endif
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    @endif
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
@section('script')
<script>
    function cancelConfirmation(ev) {
        ev.preventDefault();
        var urlToRedirect = ev.currentTarget.getAttribute('href'); // use currentTarget because the click may be on the nested i tag and not a tag causing the href to be empty
        console.log(urlToRedirect); // verify if this is the right URL
        swal({
            title: "Are you sure you want to delete?",
            text: "After cancelling the subscription the associated license key will expire.",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
        .then((willDelete) => {
            // redirect with javascript here as per your logic after showing the alert using the urlToRedirect value
            if (willDelete) {
                window.location.href = urlToRedirect;
            }
        });
    }
    function copyText(element) {
  var $copyText = document.getElementById(element).innerText;
  
  var button = document.getElementById('lisence_key_copy');
  navigator.clipboard.writeText($copyText).then(function() {
    var originalText = button.innerText;
    button.innerText = 'Copied!';
    setTimeout(function(){
      button.innerText = originalText;
      }, 750);
  }, function() {
    button.style.cssText = "background-color: var(--red);";
    button.innerText = 'Error';
  });
}
</script>
@endsection
