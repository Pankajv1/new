@extends('layouts.appdashboard')
@section('content')
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Invoices</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="{{ route('home') }}">Dashboard</a></li>
                            <li class="breadcrumb-item active">Invoices</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    @include('includes.message')
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-md-12">
                    <table class="table table-bordered table-striped" id="myTable">
                        <thead>
                            <tr>
                                <th>Package</th>
                                <th>Duration</th>
                                <th>Subscription Start Date</th>
                                <th>Subscription End Date</th>
                                <th>Card No</th>
                                <th>Status</th>
                                <th style="width: 160.8px !important;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                         
                            @foreach ($invoices as $invoice)
                            
                                <tr>
                                    <td>{{ Str::ucfirst(@$invoice->plan->name ?$invoice->plan->name:$deleted_plan[$invoice->plan_id]['name']) }}</td>
                                    <td>{{ Str::ucfirst(@$invoice->plan->duration?$invoice->plan->duration:$deleted_plan[$invoice->plan_id]['duration']) }}</td>
                                    <td>{{ date("M d, Y", strtotime(@$invoice->subscription_start_date)) }}</td>
                                    <td>{{ date("M d, Y", strtotime(@$invoice->subscription_end_date)) }}</td>
                                    <td>**** **** **** {{ base64_decode(@$invoice->card->card_no) }}</td>
                                    <td>{{ Str::ucfirst(@$invoice->status) }}</td>
                                    <td>
                                        @php
                                            $details = (Array)@$invoice->invoice_details;
                                            $data = json_decode(@$details[0]); 
                                        @endphp
                                        @if(@$data->hosted_invoice_url)
                                        <a href="{{ @$data->hosted_invoice_url }}" target="_blank" class="btn btn-dark btn-md">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        @else
                                        <a >
                                            Trial Period
                                        </a>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('script')
<script>
    $(document).ready(function() {
        $('#myTable').DataTable();
    });
</script>
@endsection
