@php 
    $layout = ($header == 'inside') ? 'layouts.appdashboard' : 'layouts.app';
@endphp
@extends($layout)
@section('content')
@if ($header == "inside")
    <div class="content-wrapper mt-3 mb-10">
        <section>
            <div class="container mb-10">
                <div class="row">
                    <div class="col-9 m-auto p-0 mb-2">
                        <div class="alert alert-success text-center mb-0">
                            <p class="m-0 text-center">Dear @if(Auth::check()) {{ Auth::user()->first_name.',' }} @endif Your Subscription has been {{base64_decode($subscription_status)}} successfully!</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-9 m-auto">
                        <div class="row success-box">
                            <div class="col-12 col-md-12 col-lf-12 text-center">
                                <img src="{{asset('img/tick.png')}}" class="img-fluid w-25">
                            </div>
                            <div class="col-12 col-md-12 col-lf-12 all-padd-ing">
                                <h5>Plan: <span class="float-end">{{ Str::ucfirst(@$subscription_details->plan->name) }}</span></h5>
                            </div>
                            <div class="col-12 col-md-12 col-lf-12 all-padd-ing">
                                <h5>Amount: <span class="float-end">${{ @$subscription_details->plan->amount }} </span></h5>
                            </div>
                            <div class="col-12 col-md-12 col-lf-12 all-padd-ing">
                                <h5>Subscription Start Date: <span class="float-end">{{ date('M d, Y', strtotime($subscription_details->latestInvoice->subscription_start_date)) }} </span></h5>
                            </div>
                            <div class="col-12 col-md-12 col-lf-12 all-padd-ing">
                                <h5>Subscription End Date: <span class="float-end">{{ date('M d, Y', strtotime($subscription_details->latestInvoice->subscription_end_date)) }}</span></h5>
                            </div>
                            <div class="col-12 col-md-12 col-lf-12 all-padd-ing">
                                <h5>Next Billing Date: <span class="float-end">{{ date('M d, Y', strtotime($subscription_details->latestInvoice->subscription_end_date)) }}</span></h5>
                            </div>
                            <div class="col-12 col-md-12 col-lf-12 all-padd-ing">
                                <h5>Subscription ID: <span class="float-end">{{ $subscription_details->stripe_subscription_id }}</span></h5>
                            </div>
                            <div class="col-12 col-md-12 col-lf-12 all-padd-ing">
                                <h5>License Key: <span class="float-end">{{ $subscription_details->license_key }}</span></h5>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-4 mb-10">
                    <div class="col-md-9 m-auto text-center">
                        <a href="{{ url('/home') }}" class="btn btn-dark">Dashboard</a>
                    </div>
                </div>
            </div>
        </section>
    </div>
@else
    <section>
        <div class="container">
            <div class="row">
                <div class="col-9 m-auto p-0 mb-2">
                    <div class="alert alert-success text-center mb-0">
                        <p class="m-0 text-center">Dear @if(Auth::check()) {{ Auth::user()->first_name.',' }} @endif Your Subscription has been {{base64_decode($subscription_status)}} successfully!</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-9 m-auto">
                    <div class="row success-box">
                        <div class="col-12 col-md-12 col-lf-12 text-center">
                            <img src="{{asset('img/tick.png')}}" class="img-fluid w-25">
                        </div>
                        <div class="col-12 col-md-12 col-lf-12 all-padd-ing">
                            <h5>Plan: <span class="float-end">{{ Str::ucfirst($subscription_details['plan_name']) }}</span></h5>
                        </div>
                        <div class="col-12 col-md-12 col-lf-12 all-padd-ing">
                            <h5>Amount: <span class="float-end">${{ @$subscription_details->plan->amount }} </span></h5>
                        </div>
                        <div class="col-12 col-md-12 col-lf-12 all-padd-ing">
                            <h5>Subscription Start Date: <span class="float-end">{{ date('M d, Y', strtotime($subscription_details->latestInvoice->subscription_start_date)) }} </span></h5>
                        </div>
                        <div class="col-12 col-md-12 col-lf-12 all-padd-ing">
                            <h5>Subscription End Date: <span class="float-end">{{ date('M d, Y', strtotime($subscription_details->latestInvoice->subscription_end_date)) }}</span></h5>
                        </div>
                        <div class="col-12 col-md-12 col-lf-12 all-padd-ing">
                            <h5>Next Billing Date: <span class="float-end">{{ date('M d, Y', strtotime($subscription_details->latestInvoice->subscription_end_date)) }}</span></h5>
                        </div>
                        <div class="col-12 col-md-12 col-lf-12 all-padd-ing">
                            <h5>Subscription ID: <span class="float-end">{{ $subscription_details->stripe_subscription_id }}</span></h5>
                        </div>
                        <div class="col-12 col-md-12 col-lf-12 all-padd-ing">
                            <h5>License Key: <span class="float-end">{{ $subscription_details->license_key }}</span></h5>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-md-9 m-auto text-center">
                    <a href="{{ url('/home') }}" class="btn btn-dark">Dashboard</a>
                </div>
            </div>
        </div>
    </section>
@endif
@endsection
