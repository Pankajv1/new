
@extends('layouts.error')
@section('content')
    <section class="pricing-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="error-template" style="text-align: center;">
                        <h1 style="padding-top: 93px;">
                            Oops!</h1>
                        <h2>
                            419 Page Expired </h2>
                        <div class="error-details">
                            Sorry, an error has occured, Requested page not found!
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
