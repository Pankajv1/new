<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bsoft</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="{{ asset('img/bsoft.png') }}"/>
    <link href="{{URL::asset('css/style.css')}}" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body class="bg-image">
    <div class="container">
        <div class="row d-flex justify-content-center align-items-center screen-height-set">
            <div class="col-sm-4">
                <div class="logo-box">
                    <a href="{{route('subscription.plan')}}"> 
                        <img src="{{ asset('img/bsoft.png') }}" alt="Bsoft Technology">
                    </a>
                </div>
                <div class="login-box">
                    <p class="text-white">Reset Password </p>
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    <form method="POST" action="{{ route('password.email') }}">
                        @csrf
                        <div class="mb-3">
                            <label for="email" class="col-md-4 col-form-label text-md-end">{{ __('Email Address') }}</label>
                            <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>
                            @error('email')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                        <div class="row">
                            <div class="col-lg-6 mb-3">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Reset Password') }}
                                </button>
                            </div>
                            <div class="col-lg-6 text-center">
                                <h6 class="text-white cust-log"><a href="{{ route('login') }}" class="text-white">Login</a></h6>
                            </div>
                        </div>
                    </form>
                    <div class="text-center mt-4">
                        <h6 class="text-white">Don't have an accunt <a href="{{ route('register') }}" class="text-white">SignUp</a></h6>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>