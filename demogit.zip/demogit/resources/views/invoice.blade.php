@extends('layouts.app')

@section('content')

<style>
       .paid-content{
    font-size: 19px;
    font-weight: 600;
    }
.heading-rec{
    font-size: 30px;
    font-weight: 600;
}

</style>

     <section class="pricing-section" >
     
           
     
          <div class="container" id="htmlContent">
          
            
              <div class="row mt-5">
                  <div class="col-12 col-md-8 col-lg-8 m-auto">
                      <h4 class="heading-rec">Receipt</h4>
                    
                      <table class="table mt-3 border-0">
                          <tbody>
                           
                            <tr>
                              <th scope="row" class="border-0">Invoice number &nbsp; &nbsp; &nbsp; &nbsp; {{$receipt_array['invoice_number']}}<br>
                                  Receipt number &nbsp; &nbsp; &nbsp; &nbsp; {{ @$receipt_array['receipt_number']}}<br>
                                  Date Paid    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;   {{$receipt_array['created']}} <br>
                                  Payment Method  &nbsp; &nbsp;   {{strtoupper($receipt_array['cardname'])}} - {{$receipt_array['lastdigit']}}
                              </th>
                              <td class="border-0"></td>
                              <td class="border-0"></td>
                              <td class="border-0"></td>
                            </tr>
                            <tr>
                              <th scope="row" class="border-0">{{$receipt_array['account_name']}}</th>
                              <td class="border-0">Bill to<br>
                                {{$receipt_array['customer_email']}}</td>
                              <td class="border-0"></td>
                              <td class="border-0"></td>
                            </tr>
                            <tr>
                              <th scope="row" class="border-0"><h4 class="paid-content">${{$receipt_array['amount_paid']/100}} paid on {{$receipt_array['created']}}</h4></th>
                              <td class="border-0"></td>
                              <td class="border-0"></td>
                              <td class="border-0"></td>
                            </tr>
                          </tbody>
                        </table>
                         @php 
                          function amount($amount)
                                {
                                   if (substr(strval($amount), 0, 1) == "-")
                                   {
                                      return '-$'.str_replace('-','',$amount);
                                   } 
                                   else 
                                   {
                                      return '$'.$amount;
                                   }
                                    
                                }
                         @endphp
                      <table class="table table-bordered mt-3">
                          <thead>
                            <tr>
                              <th scope="col">Description</th>
                              <th scope="col">Qty</th>
                              <th scope="col">Unit price</th>
                              <th scope="col">Amount</th>
                            </tr>
                          </thead>
                          <tbody>
                            @php $totalamount =0; @endphp
                            @foreach($receipt_array['invoice_line_item'] as $key=>$value)
                              @php  $totalamount += $value['amount']/100;  @endphp
                                <tr>
                                    <th scope="row">{{$value['description']}}<br>{{date('M d Y',$value['start'])}} – {{date('M d Y',$value['end'])}}</th>
                                    <td>1</td>
                                    @if($value['amount'] > 0)
                                    <td>{{amount($value['amount']/100)}}</td>
                                    @else
                                    <td></td>
                                    @endif
                                    <td>{{amount($value['amount']/100)}}</td>
                                </tr>
                             
                            @endforeach
                            <tr class="p-2">
                              <th scope="row"></th>
                              <td>Subtotal</td>
                              <td></td>
                              <td>{{amount($totalamount)}}</td>
                            </tr>
                            <tr class="p-2">
                              <th scope="row"></th>
                              <td>Total</td>
                              <td></td>
                              <td>{{amount($totalamount)}}</td>
                            </tr>
                            @if(($receipt_array['starting_balance']/100) !== 0)
                            <tr class="p-2">
                              <th scope="row"></th>
                              <td>Applied balance</td>
                              <td></td>
                              <td>{{amount($receipt_array['starting_balance']/100)}}</td>
                            </tr>
                            @endif
                            @if(($receipt_array['amount_paid']/100) !== 0)
                            <tr class="p-2">
                                <th scope="row"></th>
                                <td>Amount Paid</td>
                                <td></td>
                                <td>{{amount($receipt_array['amount_paid']/100)}}</td>
                              </tr>
                            @endif
                          </tbody>
                        </table>
                  </div>
              </div>
      
          </div>
    
@endsection
</section>
