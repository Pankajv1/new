<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bsoft Technology Dashboard</title>
    <!-- Google Font: Source Sans Pro -->
    <link rel="icon" type="image/png" href="<?php echo e(asset('img/bsoft.png')); ?>"/>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('assest/plugins/fontawesome-free/css/all.min.css')); ?>">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Tempusdominus Bootstrap 4 -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('assest/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css')); ?>">
    <!-- iCheck -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('assest/plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
    <!-- JQVMap -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('assest/plugins/jqvmap/jqvmap.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('assest/dist/css/adminlte.min.css')); ?>">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('assest/plugins/overlayScrollbars/css/OverlayScrollbars.min.css')); ?>">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('assest/plugins/daterangepicker/daterangepicker.css')); ?>">
    <!-- summernote -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('assest/plugins/summernote/summernote-bs4.min.css')); ?>">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/admin-style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/plan.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('dist/css/DatPayment.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('dist/css/example.css')); ?>">
    <!-- Data tables -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">

</head>

<body class="sidebar-mini layout-fixed">
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link siderbar-minimize" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>
        </ul>
        <ul class="navbar-nav ms-auto mr-3">
            <div class="nav-item dropdown">
                <a id="dLabel" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <span>
                        <?php if(Auth::check()): ?> <?php echo e(Auth::user()->first_name); ?> <?php endif; ?> <i class="fa fa-caret-down" aria-hidden="true"></i>
                    </span>
                </a>
                <ul class="dropdown-menu" role="menu" aria-labelledby="dLabel">
                    <a class="dropdown-item" href="<?php echo e(route('changepassword')); ?>">Change Password</a>
                  <a class="dropdown-item" href="<?php echo e(URL::to('logout')); ?>">
                        <?php echo e(__('Logout')); ?>

                    </a>

                </ul>
            </div>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
            </form>
        </ul>
    </nav>
        <aside class="main-sidebar sidebar-dark-primary elevation-4">
            <a href="/home" class="brand-link">
                <span class="brand-text font-weight-light">Bsoft Technology</span>
            </a>
            <div class="sidebar os-host os-theme-light os-host-overflow os-host-overflow-y os-host-resize-disabled os-host-transition os-host-scrollbar-horizontal-hidden">
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                        data-accordion="false">
                        <li class="nav-item">
                            <a href="<?php echo e(route('home')); ?>" class="nav-link">
                                <i class="nav-icon fas fa-th"></i>
                                <p>Dashboard</p>
                            </a>
                        </li>
                        <?php if(Auth::user()->hasRole('admin')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('user.list')); ?>" class="nav-link">
                                    <i class="nav-icon fas fa-user"></i>
                                    <p>Admins</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('view.packages')); ?>" class="nav-link">
                                    <i class="nav-icon fas fa-file"></i>
                                    <p>Packages</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('customer.list')); ?>" class="nav-link">
                                    <i class="nav-icon fas fa-users"></i>
                                    <p>Customers</p>
                                </a>
                            </li>
                        <?php elseif(Auth::user()->hasRole('user')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('customer.list')); ?>" class="nav-link">
                                    <i class="nav-icon fas fa-user"></i>
                                    <p>Customers</p>
                                </a>
                            </li>
                        <?php else: ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('my.plans')); ?>" class="nav-link">
                                    <i class="nav-icon fas fa-columns"></i>
                                    <p>My Plans</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('invoices')); ?>" class="nav-link">
                                    <i class="nav-icon fas fa-file"></i>
                                    <p>Invoices</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('active.domains')); ?>" class="nav-link">
                                    <i class="nav-icon fas fa-ellipsis-h"></i>
                                    <p>Active Domains</p>
                                </a>
                            </li>
                        <?php endif; ?>
                       
                    </ul>
                </nav>
            </div>
        </aside>
        <main class="py-1">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
</body>
<footer class="main-footer" style=" background-color: #fff;
    border-top: 1px solid #dee2e6;
    color: #869099;
    padding: 1rem;
    width: 100% !important;
    position: fixed !important;
    bottom: 0;">Bsoft Technology. All rights reserved.
</footer>
<!-- jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?php echo e(URL::asset('assest/plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
    $.widget.bridge('uibutton', $.ui.button)

</script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(URL::asset('assest/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assest/plugins/jquery-knob/jquery.knob.min.js')); ?>"></script>
<!-- daterangepicker -->
<script src="<?php echo e(URL::asset('assest/plugins/moment/moment.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assest/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?php echo e(URL::asset('assest/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js')); ?>">
</script>
<!-- Summernote -->
<script src="<?php echo e(URL::asset('assest/plugins/summernote/summernote-bs4.min.js')); ?>"></script>
<!-- overlayScrollbars -->
<script src="<?php echo e(URL::asset('assest/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(URL::asset('assest/dist/js/adminlte.js')); ?>"></script>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<!--<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>-->
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script type="text/javascript" src="https://js.stripe.com/v2/"></script>
    <script type="text/javascript" src="<?php echo e(URL::asset('dist/js/DatPayment.js')); ?>"></script>
<script>
    $( document ).ready(function() {

        if(sessionStorage.getItem('sidebar') === 'true') {
            $('body').addClass('sidebar-collapse');
        }
        $(".siderbar-minimize").click(function(){
            if(sessionStorage.getItem('sidebar') === null) {
                sessionStorage.setItem('sidebar', true);
            } else {
                sessionStorage.removeItem("sidebar");
            }
        });
    })
</script>
<?php echo $__env->yieldContent('script'); ?>
</html>
<?php /**PATH E:\xampp7.3\htdocs\svnbsoft\bsofttechnology\resources\views\layouts\appdashboard.blade.php ENDPATH**/ ?>