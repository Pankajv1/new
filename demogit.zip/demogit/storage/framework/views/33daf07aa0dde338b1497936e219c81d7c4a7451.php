<!DOCTYPE html>
<html lang="en">

<head>
    <title>Bsoft</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="<?php echo e(asset('img/bsoft.png')); ?>"/>
    <link href="<?php echo e(URL::asset('css/style.css')); ?>" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body class="bg-image">
    <div class="container">
        <div class="row d-flex justify-content-center align-items-center screen-height-set">
            <div class="col-sm-4">
                <div class="logo-box">
                    <a href="<?php echo e(route('subscription.plan')); ?>"> 
                        <img src="<?php echo e(asset('img/bsoft.png')); ?>" alt="Bsoft Technology">
                    </a>
                </div>
                <div class="login-box">
                    <h4 class="text-white">Welcome Back!</h4>
                    <p class="text-white">Enter your login credentials:</p>
                    <?php if(Session::has('error')): ?>
                    <div class="alert alert-danger"style="text-align: center;"><?php echo e(Session::get('error')); ?></div>
                 <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label class="form-label text-white">Email address</label>
                            <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div> 
                        <label class="form-label text-white">Password</label>
                        <div class="input-group mb-3">
                            
                            <input id="password" type="password"  class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required
                            autocomplete="current-password" aria-label="Amount (to the nearest dollar)">
                            <div class="input-group-append">
                              <span class="input-group-text" style="padding: 0.75rem 0.75rem !important;"> <span toggle="#password" class="fa fa-lg fa-eye field-icon toggle-password"></span></span>
                            </div>
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      
                        <div class="mb-3 form-check cust-form">
                            

                            <a class="btn btn-link text-white" href="<?php echo e(route('password.request')); ?>">
                                Forgot Password?
                            </a>
                        </div>
                        
                        <div class="text-end mb-4">
                            <button type="submit" class="btn-button-deco" style="min-width: 302px !important;">Login</button>
                        </div>
                    </form>
                    <div class="text-center mt-4">
                        <h6 class="text-white">Don't have an accunt <a href="<?php echo e(route('register')); ?>"
                                class="text-white">Sign up</a></h6>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
    $(".toggle-password").click(function() {

$(this).toggleClass("fa-eye fa-eye-slash");
var input = $($(this).attr("toggle"));
if (input.attr("type") == "password") {
input.attr("type", "text");
} else {
input.attr("type", "password");
}
});
    </script>
</html>
<?php /**PATH E:\xampp7.3\htdocs\svnbsoft\bsofttechnology\resources\views/auth/login.blade.php ENDPATH**/ ?>