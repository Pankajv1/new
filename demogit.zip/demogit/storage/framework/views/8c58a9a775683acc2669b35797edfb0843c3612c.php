

<?php $__env->startSection('content'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard v1</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">

            <?php if(session('status')): ?>
                <h6 class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </h6>
            <?php endif; ?>

            <div class="card">
                <div class="card-header">
                    <h4>Modify plan details
                        <a href="<?php echo e(url('planes')); ?>" class="btn btn-danger float-end">BACK</a>
                    </h4>
                </div>
                <div class="card-body">

                    <form action="<?php echo e(url('update-plane/'.$planeUser->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="form-group mb-3">
                            <label for="">Plan Name</label>
                            <input type="text" name="name" value="<?php echo e($planeUser->name); ?>" class="form-control" required autocomplete="name">
                        </div>
                        <div class="form-group mb-3">
                            <label for="">Plan Amount</label>
                            <input type="text" name="amount" value="<?php echo e($planeUser->amount); ?>" class="form-control" required autocomplete="amount">
                        </div>
                        <div class="form-group mb-3">
                        <label for="">Plan Duration</label>
                       
                        <select name="duration" id="plane_duration" class="form-control">
                          <option value="3 months">3 months</option>
                          <option value="6 months">6 months</option>
                          <option value="9 months">9 months</option>
                          <option value="12 months">12 months</option>
                        </select>
                        </div>
                        <?php $__currentLoopData = json_decode($planeUser->features); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$features): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="input_fields_remove" id="addrow">
                            <label for="">Plan Features</label>
                            <style> 
                              input {
                                    width: 95%;
                            }
                            </style>
                           
                           
                         
                            <input type="text" name="features[]" value="<?php echo e($features); ?>" required autocomplete="features[]"><?php if($key !=0): ?><a class="remove_field"> <i class="fa fa-minus" aria-hidden="true"></i><?php else: ?> <a class="add_field_button"> <i class="fa fa-plus" aria-hidden="true"></i></a> <?php endif; ?></a>
                           
                           
                           
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </br>
                        <div class="form-group mb-3">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
    
   
    <!-- /.content -->
</div>
<script>
$(document).ready(function() {
    
	var max_fields      = 10;
	var remove   		= $(".input_fields_remove");
	var add_button      = $(".add_field_button");
	
	var x = 1;
	$(add_button).click(function(e){

        // console.log('here');
		if(x < max_fields){ 
			x++;
            $('.input_fields_remove:last').after('<div><label for="">Plane Features</label> <input type="text" name="features[]"/> <a class="remove_field"><i class="fa fa-minus" aria-hidden="true"></i></a></div>');
			//$('#addrow').append('<div><label for="">Plane Features</label> <input type="text" name="features[]"/> <a class="remove_field"><i class="fa fa-minus" aria-hidden="true"></i></a></div>');
            
		}
	});
	
	$(document).on("click",".remove_field", function(e){
        // alert('here');
		e.preventDefault();
        $(this).parent('div').remove();
        x--;
	})
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apptest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp7.3\htdocs\svnbsoft\bsofttechnology\resources\views\edit.blade.php ENDPATH**/ ?>