

<?php $__env->startSection('content'); ?>
<div class="alert alert-success text-center">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
    <p>Dear  <?php if(Auth::check()): ?>  <?php echo e(Auth::user()->name); ?> <?php endif; ?>  Your Subscription Has been successfully !</p>
</div>

<section>
    <div class="container">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6 text-center">
              
                <h3>Plan: <?php echo e(Str::ucfirst($subscription_details['plan_name'])); ?></h3>
                <h3>Amount: $<?php echo e($subscription_details['plan_amount']); ?></h3>
                <h3>Plan Start : <?php echo e(date("m-d-Y", strtotime($subscription_details['create_date']))); ?></h3>
                <h3>Plan End : <?php echo e(date("m-d-Y", strtotime($subscription_details['end_date']))); ?></h3>
                <h3>Subscription ID : <?php echo e($subscription_details['subscriptionID']); ?></h3>

            </div>
            <div class="col-md-3"></div>
            <div class="col-md-3"></div>
            <div class="col-md-6">
               
            </div>
            <div class="col-md-3"></div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp7.3\htdocs\svnbsoft\bsofttechnology\resources\views\user\message.blade.php ENDPATH**/ ?>