
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Packages</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Packages</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <?php echo $__env->make('includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-6">
                </div>
                <div class="col-md-6 text-right">
                    <a href="<?php echo e(route('add.package')); ?>" class="btn btn-dark float-end" data-placement="bottom" title="Add package">Add Package</a>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-md-12">
                    <table class="table table-bordered table-striped" id="myTable">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Amount</th>
                                <th>Duration</th>
                                <th>No. of Domains</th>
								<th>Trial Days</th>
                                <th>Features</th>
                                <th style="width: 160.8px !important;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
						
                            <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(Str::ucfirst($plan->name)); ?></td>
                                    <td><?php echo e($plan->amount); ?></td>
                                    <td><?php echo e(Str::ucfirst($plan->duration)); ?></td>
                                    <td><?php echo e($plan->no_of_domains); ?></td>
									<td><?php echo e($plan->trial_days); ?></td>
                                    <td>
                                        <?php echo e(implode(',', json_decode($plan->features))); ?>

                                    </td>
                                    <td>
                                        <a href="<?php echo e(url('edit-package/' . $plan->id)); ?>" class="btn btn-secondary btn-md" data-placement="bottom" title="Edit">
                                            <i class="fas fa-pen"></i>
                                        </a>
                                       
                                            <a href="<?php echo e(url('delete-package/' . $plan->id)); ?>" class="btn btn-dark btn-md" data-placement="bottom" title="Delete" onclick="deletepackage(event)" >
                                                <i class="fas fa-trash"></i>
                                            </a>
                                 
                                        <label class="switch" data-placement="bottom" title="Status">

                                            <input type="checkbox" <?php if($plan->status =="Active"): ?> checked <?php endif; ?> data-id =<?php echo e($plan->id); ?> class="status_update" >
                                            <span class="slider round"></span>
                                          </label>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        $('#myTable').DataTable();
    });
    $(".status_update").click(function(e){
       var plan_id =  $(this).closest('.status_update').attr('data-id');
       var csrf_token="<?php echo e(csrf_token()); ?>";
            jQuery.ajax({
                url: "/change-status",
                method: 'post',
                data: {
                plan_id: plan_id,
                '_token':csrf_token
                
                },
                success: function(result){
                    if(result == 'error') {
						swal({
                            title: "Something Went Wrong !",
                            icon: "warning",
                            dangerMode: true,
                        });
                        
                    } else {
                        swal("Package "+result+" successfully!", "", "success");
                    } 
                }
            });
        });
        function deletepackage(ev)
        {
            
            ev.preventDefault();
            var urlToRedirect = ev.currentTarget.getAttribute('href'); // use currentTarget because the click may be on the nested i tag and not a tag causing the href to be empty
            console.log(urlToRedirect); // verify if this is the right URL
            swal({
                title: "Are you sure you want to delete?",
                text: "Delete Package",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                // redirect with javascript here as per your logic after showing the alert using the urlToRedirect value
                if (willDelete) {
                    window.location.href = urlToRedirect;
                }
            });
    
        }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appdashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp7.3\htdocs\svnbsoft\bsofttechnology\resources\views/admin/plan/index.blade.php ENDPATH**/ ?>