
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Admins</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Admins</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
            </div>
            <div class="col-md-6 text-right">
                <button class="btn btn-dark" data-toggle="modal" data-target="#addUser">Add Admins</button>
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-md-12">
                <table class="table table-bordered table-striped" id="myTable">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->email); ?></td>
                                <td>
                                    <a href="<?php echo e(url('edit-plan/' . $item->id)); ?>" class="btn btn-secondary btn-md">
                                        <i class="fas fa-pen"></i>
                                    </a>
                                    <a href="<?php echo e(url('delete-plan/' . $item->id)); ?>" class="btn btn-dark btn-md">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="addUser" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <form id="addUserForm">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Admin Details</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>

                </div>
                <div class="modal-body">
                    <div class="form-group mb-3">
                        <label for="">Name</label>
                        <input id="name" type="text" class="form-control" name="name" id="name"
                            value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                    </div>

                    <div class="form-group mb-3">
                        <label for="">Email</label>
                        <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>"
                            required autocomplete="email">
                    </div>
                    <div class="form-group mb-3">
                        <label for="">Password</label>
                        <input id="password" type="password" class="form-control" name="password" required
                            autocomplete="new-password">
                    </div>
                    <div class="form-group mb-3">
                        <label for="">Confirm Password</label>
                        <input type="password" class="form-control" name="password_confirmation"
                            id="password_confirmation" required autocomplete="new-password">
                        <div><span class="error password_confirmation"></span></div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary add_user" data-dismiss="modal">Close</button>
                    <input type="button" value="Save" id="ajaxSubmit" class="btn btn-dark">
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        $('#myTable').DataTable();
        $("#addUser").on("hidden.bs.modal", function(){
            $(this).find('form').trigger('reset');
        });
        

        // initialize the plugin
        $('#addUserForm').validate({
            rules: {
                name: {
                    required: true
                },
                email: {
                    required: true,
                    email: true
                },
                password: {
                    required: true,
                    minlength: 6
                },
                password_confirmation: {
                    required: true,
                    equalTo: "#password"
                }
            },
            messages: {
                name: {
                    required: "Name is required"
                },
                email: {
                    required: "Email is required",
                    email: "Please enter a valid email"
                },
                password: {
                    required: "Password is required",
                    minlength: "Password length must be of atleast 6 characters"
                },
                password_confirmation: {
                    required: "Confirm Password is required",
                    equalTo: "Password not matched"
                },
            },
            errorPlacement: function(label, element) {
                label.addClass('mt-2 text-danger');
                element.parent().append(label);

            },

            highlight: function(element, errorClass) {

                $(element).parent().addClass('has-danger');
                $(element).addClass('form-control-danger');

            },

            unhighlight: function(element, errorClass, validClass) {
                $(element).parents().removeClass('has-danger');
                $(element).removeClass('form-control-danger');
                $(element).parents('.form-group').addClass('has-success');
            }
        });
    });

    jQuery('#ajaxSubmit').click(function(e) {
        e.preventDefault();

        if ($('#addUserForm').valid() == false) {
            return false;
        }

        let formData = $('#addUserForm').serialize();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            }
        });

        jQuery.ajax({
            url: "<?php echo e(url('saveuser')); ?>",
            dataType: "json",
            method: 'post',
            data: formData,

            success: function(result) {
                $('#addUser').modal('toggle');
                swal("Done!", result.message, 'success');
            }
        });
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appdashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp7.3\htdocs\svnbsoft\bsofttechnology\resources\views\user\index.blade.php ENDPATH**/ ?>