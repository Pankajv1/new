
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <section class="pricing-section">
        <div class="container update-container">
            <div class="sec-title text-left mt-2">
                <h5>Update Subscription <?php echo e(($subscription !== null && $subscription->plan_id ==$plan->id) ? 'Payment Method' : ''); ?></h5>
                <?php if($subscription !== null && $subscription->plan_id ==$plan->id): ?>
                    <h4>Next Billing Date - <?php echo e(date("M d, Y", strtotime($subscription->latestInvoice->subscription_end_date))); ?></h4>
                <?php endif; ?>
            </div>
            <div class="row mt-2">
                <div class="col-lg-12 col-md-5 col-sm-5 text-bold m-auto mt-2 mb-1">
                    <?php echo $__env->make('includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-12 col-md-4 col-lg-4 mb-10">
                    <div class="box-creditcontent p-4 mb-10">
                        <li class="nav-item col-lg-12 col-md-12 col-sm-12">
                            <a class="nav-link active w-100">
                                <div class="row card-design m-auto" id="bg0">
                                    <div class="col-4 col-lg-5 col-md-5 col-sm-12">
                                        <div class="update-icon-box" id="bg0-icon">
                                            <i class="fas fa-dollar-sign"></i>
                                        </div>
                                    </div>
                                    <div class="price-box col-8 col-lg-7 col-md-7 col-sm-12 p-0">
                                        <div class="card-content">
                                            <div class="main-content text-dark"><?php echo e(Str::ucfirst($plan->name)); ?></div>
                                            <h4 class="sub-content">$<?php echo e($plan->amount); ?></h4>
                                            <h4 class="sub-content">
                                                <?php if($plan->duration == "week" || $plan->duration == "month" || $plan->duration == "yesr"): ?>
                                                    <?php echo e(Str::ucfirst($plan->duration)."ly"); ?>

                                                <?php else: ?>
                                                    <?php echo e(Str::ucfirst($plan->duration)); ?>

                                                <?php endif; ?>
                                            </h4>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <hr>
                        <div class="price-box col-lg-12 col-md-12 col-sm-12 p-0">
                            <div class="card-content p-0 m-0 ml-2 text-center">
                                <h2 class="tab-main-subcontent p-2 fbig-globe">$<?php echo e($plan->amount); ?>/<span>
                                    <?php if($plan->duration == "week" || $plan->duration == "month" || $plan->duration == "yesr"): ?>
                                        <?php echo e(Str::ucfirst($plan->duration)."ly"); ?>

                                    <?php else: ?>
                                        <?php echo e(Str::ucfirst($plan->duration)); ?>

                                    <?php endif; ?>
                                </span></h2>
                                <?php $__currentLoopData = json_decode($plan->features); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <hr>
                                    <div class="tab-main-content3 p-1 "><h4 class="text-dark"><?php echo e($feature); ?></h4></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if($subscription != null &&  @$plan->id == @$subscription->plan_id): ?>
                                    <hr>
                                    <div class="tab-main-content3 p-1">
                                        <h4 class="text-dark">Start Date - <?php echo e(date("M d, Y", strtotime($subscription->latestInvoice->subscription_start_date))); ?></h4>
                                    </div>
                                    <hr>
                                    <div class="tab-main-content3 p-1">
                                        <h4 class="text-dark">End Date - <?php echo e(date("M d, Y", strtotime($subscription->latestInvoice->subscription_end_date))); ?></h4>
                                    </div>
                                  
                                <?php endif; ?>
                                <hr>
                                <div class="tab-main-content3 p-1 "><h4 class="text-dark">No. of Domains - <?php echo e($plan->no_of_domains); ?></h4></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-8 col-lg-8 mb-5">
                   
                    <form action="/stripecustomer" method="POST" id="payment-form" class="datpayment-form inside-payment-form">
                        <?php echo csrf_field(); ?>
                            <input type="hidden" value="<?php echo e($plan->duration); ?>" name="plan_name">
                            <input type="hidden" value="<?php echo e($plan->amount); ?>" name="plan_amount">
                            <input type="hidden" value="<?php echo e($plan->id); ?>" name="plan_id">
                            
                          <div class="text-center font-weight-bold text-light" style="font-size: 25px; background-color: #39a391;border-radius: 6px;">
							   <?php if(@$subscription->amount_due  && $subscription->plan_id != $plan->id): ?>
							   <div > <span>Pay Amount $ <?php echo e(($subscription->amount_due != 0)?$subscription->amount_due/100:"0"); ?> <span>
							   </div>
							   <?php elseif($subscription === null ): ?> 
							   <div > <span>Pay Amount $ <?php echo e($plan->amount); ?> <span></div>
							   
								<?php elseif($subscription !== null && $subscription->plan_id != $plan->id): ?>
								  <?php if(isset($subscription->amount_due)): ?>
									<div > <span>Pay Amount $ <?php echo e(0); ?><span></div>
								  <?php else: ?>
								  <div > <span>Pay Amount $ <?php echo e($plan->amount); ?> <span></div>
								 <?php endif; ?>
							  <?php endif; ?>
						  </div>
                        <div class="dpf-card-placeholder"></div>
                        <div class="dpf-input-container">
                            <div class="dpf-input-row">
                                <label class="dpf-input-label">Card number</label>
                                <div class="dpf-input-container with-icon">
                                    <span class="dpf-input-icon"><i class="fa fa-credit-card" aria-hidden="true"></i></span>
                                    <input type="text" class="dpf-input" id="card_number" size="20" data-type="number" name="number" >
                                    <input type="hidden" class="dpf-input" id="card_number2" name="number" value="<?php echo e(old('number')); ?>">
                                </div>
                            </div>
                    
                            <div class="dpf-input-row">
                                <div class="dpf-input-column">
                                    <input type="hidden" size="2" data-type="exp_month" placeholder="MM" name="exp_month">
                                    <input type="hidden" size="2" data-type="exp_year" placeholder="YY" name="exp_year">
                                    <label class="dpf-input-label">Exp Date</label>
                                    <div class="dpf-input-container">
                                        <input type="text" class="dpf-input" id="expiry" data-type="expiry" name="expiry">
                                    </div>
                                </div>
                                <div class="dpf-input-column">
                                    <label class="dpf-input-label">CVV</label>
                                    <div class="dpf-input-container">
                                        <input type="text" class="dpf-input" size="4" data-type="cvc" id="cvv" name="cvc">
                                    </div>
                                </div>
                            </div>
                    
                            <div class="dpf-input-row">
                                <label class="dpf-input-label">Name of Holder</label>
                                <div class="dpf-input-container">
                                    <input type="text" size="4" class="dpf-input" data-type="name" id="name_on_card" name="name">
                                </div>
                            </div>
                            <div class="dpf-input-row chechitem">
                                <div class="dpf-input-container">
                                    <label for="terms_agree" class="checklbl">
                                        <input type="checkbox" id="terms_agree" />
                                        Your Card is saved for future payments.
                                    </label>
                                </div>
                                <div class="dpf-input-container" id="show_error">
                                </div>
                            </div>
                            <button type="button" onclick="cardFormValidate()" class="dpf-submit">
                                <?php if(@$subscription->plan_id != $plan->id): ?>
                                  Pay now
                                  <?php else: ?>
                                  Add Card
                                <?php endif; ?>
                            </button>
                            <div id="demo-log" class="invisible"></div>
                        </div>
                    </form>
                    <div class="mt-4">
                        <h4>Saved Cards</h4>
                    </div>
                    <table class="table table-bordered mt-3 mb-5">
                        <thead>
                            <tr>
                                <th scope="col">&nbsp;&nbsp;&nbsp;&nbsp;</th>
                                <th scope="col">Card Number</th>
                                <th scope="col">Expiration Date</th>
                                <th scope="col">&nbsp;&nbsp;&nbsp;&nbsp;</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = Auth::user()->cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                    <tr>
                                        <th scope="row" class="text-center"><input class="form-check-input" type="radio" <?php if(@$subscription->card_id == @$card->id ): ?> checked <?php endif; ?>  name="flexRadioDefault" id="flexRadioDefault1" value="abcd"></th>
                                        <td>**** **** **** <?php echo e(base64_decode($card->card_no)); ?></td>
                                        <td><?php echo e(base64_decode($card->exp_month)); ?>/<?php echo e(base64_decode($card->exp_year)); ?></td>
                                        <td>
                                            <?php if(@$subscription->card_id !== @$card->id ): ?>
                                            <form action="/stripecustomer" method="POST">
                                                 <?php echo csrf_field(); ?>
                                                 <input type="hidden" value="<?php echo e($plan->id); ?>" name="plan_id">
                                                 <input type="hidden" value="<?php echo e($card->id); ?>" name="card_id">
                                                 <input type="submit" value="Set to Autopay" class="btn btn-dark">
                                                 <a  href="<?php echo e(route('delete.card', [base64_encode($card->id)])); ?>" class="btn btn-dark" onclick="cancelConfirmationcard(event)">Delete Card</a>
                                            </form>
                                            <?php elseif($subscription !== null && $subscription->plan_id != $plan->id): ?>

                                            <form action="/stripecustomer" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" value="<?php echo e($plan->id); ?>" name="plan_id">
                                                <input type="hidden" value="<?php echo e($card->id); ?>" name="card_id">
                                                <input type="submit" value="Pay" class="btn btn-dark">
                                               
                                           </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section> 
</div>   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="https://igorescobar.github.io/jQuery-Mask-Plugin/js/jquery.mask.min.js"></script>   
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-creditcardvalidator/1.2.0/jquery.creditCardValidator.js" integrity="sha512-L4i6hMNkLZn8tib5ZqsaUt1ehC0ckCpMjMTGIO5anwZqTxqDf5tTXklmxeqYIFWey6IDSzICxKNr7dQcUhPYDQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
    function cardFormValidate(){
        var cardValid = 0;
        //card number validation
        $('#card_number2').validateCreditCard(function(result){
            if(result.valid) {
                $("#card_number").removeClass('required');
                $("#card_number").parent().removeClass('dpf-row-invalid');
                cardValid = 1;
            } else {
                $("#card_number").addClass('required');
                $("#card_number").parent().addClass('dpf-row-invalid');
                cardValid = 0;
            }
        });
        
        //card details validation
        var cardName = $("#name_on_card").val();
        var expiry = $("#expiry").val();
        expiry = expiry.split(' / ');
        var expMonth = expiry[0];
        var expYear = expiry[1];
        var cvv = $("#cvv").val();
        var regName = /^[a-z ,.'-]+$/i;
        var regMonth = /^01|02|03|04|05|06|07|08|09|10|11|12$/;
        var expression =  `^${new Date().getFullYear().toString().substr(-2)}|${(+new Date().getFullYear().toString().substr(-2) + +1)}|${(+new Date().getFullYear().toString().substr(-2) + +2)}|${(+new Date().getFullYear().toString().substr(-2) + +3)}|${(+new Date().getFullYear().toString().substr(-2) + +4)}$`;
        var regYear = new RegExp(expression); ///^22|23|24|25|26$/;
        var terms_agree = $("#terms_agree").is(":checked");
        var regCVV = /^[0-9]{3,3}$/;
        if (cardValid == 0) {
            $("#card_number").addClass('required');
            $("#card_number").parent().addClass('dpf-row-invalid');
            $("#card_number").focus();
            return false;
        }else if (!regMonth.test(expMonth)) {
            $("#card_number").removeClass('required');
            $("#card_number").parent().removeClass('dpf-row-invalid');
            $("#expiry").addClass('required');
            $("#expiry").parent().addClass('dpf-row-invalid');
            $("#expiry").focus();
            return false;
        }else if (!regYear.test(expYear)) {
            $("#card_number").removeClass('required');
            $("#card_number").parent().removeClass('dpf-row-invalid');
            $("#expiry").addClass('required');
            $("#expiry").parent().addClass('dpf-row-invalid');
            $("#expiry").focus();
            return false;
        }else if (!regCVV.test(cvv)) {
            $("#card_number").removeClass('required');
            $("#card_number").parent().removeClass('dpf-row-invalid');
            $("#expiry").removeClass('required');
            $("#expiry").parent().removeClass('dpf-row-invalid');
            $("#cvv").addClass('required');
            $("#cvv").parent().addClass('dpf-row-invalid');
            $("#cvv").focus();
            return false;
        }else if (!regName.test(cardName)) {
            $("#card_number").removeClass('required');
            $("#card_number").parent().removeClass('dpf-row-invalid');
            $("#expiry").removeClass('required');
            $("#expiry").parent().removeClass('dpf-row-invalid');
            $("#cvv").removeClass('required');
            $("#cvv").parent().removeClass('dpf-row-invalid');
            $("#name_on_card").addClass('required');
            $("#name_on_card").parent().removeClass('dpf-row-invalid');
            $("#name_on_card").focus();
            return false;
        } else if (!terms_agree) {
            $("#show_error").html('<span style="color:red; margin-left:0%;">Please check this checkbox.</span>');
            return false;
        } else {
            $("#card_number").removeClass('required');
            $("#card_number").parent().removeClass('dpf-row-invalid');
            $("#expiry").removeClass('required');
            $("#expiry").parent().removeClass('dpf-row-invalid');
            $("#cvv").removeClass('required');
            $("#cvv").parent().removeClass('dpf-row-invalid');
            $("#name_on_card").removeClass('required');
            $("#name_on_card").parent().removeClass('dpf-row-invalid');
            $(".dpf-submit").html('Processing');
            $(".dpf-submit").prop('disabled', true);
            $("#payment-form").submit();
            return true;
        }
    }
    $(document).ready(function() {
        $("#card_number").change(function(){
            let card_number = $(this).val();
            $("#card_number2").val(card_number.replace(/ /g,''));
        })
    });

    var payment_form = new DatPayment({
        form_selector: '#payment-form',
        card_container_selector: '.dpf-card-placeholder',
        number_selector: '.dpf-input[data-type="number"]',
        date_selector: '.dpf-input[data-type="expiry"]',
        cvc_selector: '.dpf-input[data-type="cvc"]',
        name_selector: '.dpf-input[data-type="name"]',
        submit_button_selector: '.dpf-submit',
        placeholders: {
            number: '•••• •••• •••• ••••',
            expiry: '••/••',
            cvc: '•••',
            name: 'Enter the card holder name'
        },
        validators: {
            number: function(number) {
                return Stripe.card.validateCardNumber(number);
            },
            expiry: function(expiry) {
                var expiry = expiry.split(' / ');
                return Stripe.card.validateExpiry(expiry[0] || 0, expiry[1] || 0);
            },
            cvc: function(cvc) {
                return Stripe.card.validateCVC(cvc);
            },
            name: function(value) {
                return value.length > 0;
            }
        }
    });
    var demo_log_div = document.getElementById("demo-log");
    payment_form.form.addEventListener('payment_form:submit', function(e) {
        var form_data = e.detail;
        payment_form.unlockForm();
        demo_log_div.innerHTML += "<br>" + JSON.stringify(form_data);
    });
    payment_form.form.addEventListener('payment_form:field_validation_success', function(e) {
        var input = e.detail;
        demo_log_div.innerHTML += "<br>field_validation_success:" + input.getAttribute("data-type");

    });
    payment_form.form.addEventListener('payment_form:field_validation_failed', function(e) {
        var input = e.detail;
        demo_log_div.innerHTML += "<br>field_validation_failed:" + input.getAttribute("data-type");
    });
	function cancelConfirmationcard(ev) {
        ev.preventDefault();
      
        var urlToRedirect = ev.currentTarget.getAttribute('href'); // use currentTarget because the click may be on the nested i tag and not a tag causing the href to be empty
        console.log(urlToRedirect); // verify if this is the right URL
        swal({
            title: "Are you sure want to delete?",
            text: "Delete Card",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
        .then((willDelete) => {
            // redirect with javascript here as per your logic after showing the alert using the urlToRedirect value
            if (willDelete) {
                window.location.href = urlToRedirect;
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appdashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp7.3\htdocs\svnbsoft\bsofttechnology\resources\views/customers/update-plans.blade.php ENDPATH**/ ?>