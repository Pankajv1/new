

<?php $__env->startSection('content'); ?>

<section class="pricing-section">
    <div class="container">
        <div class="text-center fs-5">
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eos, molestiae mollitia soluta est perferendis nam
                pariatur odio suscipit accusamus maxime aliquam tenetur quam repudiandae adipisci similique aut aliquid quibusdam rem.</p>
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eos, molestiae mollitia soluta est perferendis nam
                pariatur odio suscipit accusamus maxime aliquam tenetur quam repudiandae adipisci similique aut aliquid quibusdam rem.</p>
        </div>
        <div class="sec-title text-center">
            <span class="title">Get plan</span>
            <h2>Choose a Plan</h2>
        </div>

        <div class="outer-box">
            <div class="row">
                <!-- Pricing Block -->
                <div class="pricing-block col-lg-3 col-md-6 col-sm-12 wow fadeInUp">
                    <div class="inner-box first-pay-height">
                        <div class="icon-box">
                            <div class="icon-outer"><i class="fa fa-usd" aria-hidden="true"></i></div>
                        </div>
                        <div class="price-box">
                            <div class="title"> 1 PRO</div>
                            <h4 class="price">USD 49 / Year</h4>
                        </div>
                        <ul class="features">
                            <li class="true">100+ Basic & Pro Widgets</li>
                            <li class="true">300+ Basic & Pro Templates</li>
                            <li class="true">60+ Pro Website Kits</li>
                            <li class="false">Theme Builder</li>
                            <li class="false">WooCommerce Store Builder</li>
                            <li class="false">Landing Page Builder</li>
                            <li class="false">Premium Support</li>
                        </ul>
                        <div class="btn-box mt-5">
                            <a href="#" class="theme-btn">BUY plan</a>
                        </div>
                    </div>
                </div>

                <!-- Pricing Block -->
                <div class="pricing-block col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="400ms">
                    <div class="inner-box">
                        <div class="icon-box">
                            <div class="icon-outer"><i class="fa fa-usd" aria-hidden="true"></i></div>
                        </div>
                        <div class="price-box">
                            <div class="title">Full Pass</div>
                            <h4 class="price">$99.99</h4>
                        </div>
                        <ul class="features">
                            <li class="true">100+ Basic & Pro Widgets</li>
                            <li class="true">300+ Basic & Pro Templates</li>
                            <li class="true">60+ Pro Website Kits</li>
                            <li class="false">Theme Builder</li>
                            <li class="false">WooCommerce Store Builder</li>
                            <li class="false">Landing Page Builder</li>
                            <li class="false">Premium Support</li>
                            <li class="false">Experts Network Profile</li>
                        </ul>
                        <div class="btn-box">
                            <a href="#" class="theme-btn">BUY plan</a>
                        </div>
                    </div>
                </div>

                <!-- Pricing Block -->
                <div class="pricing-block col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="800ms">
                    <div class="inner-box">
                        <div class="icon-box">
                            <div class="icon-outer"><i class="fa fa-usd" aria-hidden="true"></i></div>
                        </div>
                        <div class="price-box">
                            <div class="title">Group Pass</div>
                            <h4 class="price">$199.99</h4>
                        </div>
                        <ul class="features">
                            <li class="true">100+ Basic & Pro Widgets</li>
                            <li class="true">300+ Basic & Pro Templates</li>
                            <li class="true">60+ Pro Website Kits</li>
                            <li class="false">Theme Builder</li>
                            <li class="false">WooCommerce Store Builder</li>
                            <li class="false">Landing Page Builder</li>
                            <li class="false">Premium Support</li>
                            <li class="false">Experts Network Profile</li>
                        </ul>
                        <div class="btn-box">
                            <a href="#" class="theme-btn">BUY plan</a>
                        </div>
                    </div>
                </div>

                <div class="pricing-block col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="800ms">
                    <div class="inner-box">
                        <div class="icon-box">
                            <div class="icon-outer"><i class="fa fa-usd" aria-hidden="true"></i></div>
                        </div>
                        <div class="price-box">
                            <div class="title">Group Pass</div>
                            <h4 class="price">$199.99</h4>
                        </div>
                        <ul class="features">
                            <li class="true">100+ Basic & Pro Widgets</li>
                            <li class="true">300+ Basic & Pro Templates</li>
                            <li class="true">60+ Pro Website Kits</li>
                            <li class="false">Theme Builder</li>
                            <li class="false">WooCommerce Store Builder</li>
                            <li class="false">Landing Page Builder</li>
                            <li class="false">Premium Support</li>
                            <li class="false">Experts Network Profile</li>
                        </ul>
                        <div class="btn-box">
                            <a href="#" class="theme-btn">BUY plan</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp7.3\htdocs\svnbsoft\bsofttechnology\resources\views\payment.blade.php ENDPATH**/ ?>