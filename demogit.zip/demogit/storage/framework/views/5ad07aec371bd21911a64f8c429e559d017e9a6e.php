
<?php $__env->startSection('content'); ?>
    <section class="pricing-section">
        <div class="container">
            <div class="text-center fs-5">
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eos, molestiae mollitia soluta est perferendis
                    nam
                    pariatur odio suscipit accusamus maxime aliquam tenetur quam repudiandae adipisci similique aut aliquid
                    quibusdam rem.</p>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eos, molestiae mollitia soluta est perferendis
                    nam
                    pariatur odio suscipit accusamus maxime aliquam tenetur quam repudiandae adipisci similique aut aliquid
                    quibusdam rem.</p>
            </div>
            <div class="sec-title text-center">
                <span class="title">Get plan</span>
                <h2>Choose a Plan</h2>
            </div>

            <div class="outer-box">
                <div class="row">
                    <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="pricing-block col-lg-4 col-md-4 col-sm-12 wow fadeInUp">
                            <div class="inner-box first-pay-height">
                                <div class="icon-box">
                                    <div class="icon-outer"><i class="fa fa-usd" aria-hidden="true"></i></div>
                                </div>
                                <div class="price-box">
                                    <div class="title"> <?php echo e($item->name); ?></div>
                                    <h4 class="price">USD $<?php echo e($item->amount); ?> </h4>
                                    <h4 class="price">
                                        <?php if($item->duration == "week" || $item->duration == "month" || $item->duration == "yesr"): ?>
                                            <?php echo e(Str::ucfirst($item->duration)."ly"); ?>

                                        <?php else: ?>
                                            <?php echo e(Str::ucfirst($item->duration)); ?>

                                        <?php endif; ?>
                                    </h4>
                                </div>
                                <ul class="features">
                                    <?php $__currentLoopData = json_decode($item->features); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="true"><?php echo e($value); ?></li>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <div class="btn-box mt-5">
                                    <?php if(Auth::check()): ?>
                                        <a href="<?php echo e(route('purchase.plan', [$item->id])); ?>" class="theme-btn">Buy
                                            Now</a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('login.user', [$item->id])); ?>" class="theme-btn">Buy
                                            Now</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp7.3\htdocs\svnbsoft\bsofttechnology\resources\views\subscription-plan.blade.php ENDPATH**/ ?>