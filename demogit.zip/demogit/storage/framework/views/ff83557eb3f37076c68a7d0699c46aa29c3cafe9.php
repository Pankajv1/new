<?php 
    $layout = ($header == 'inside') ? 'layouts.appdashboard' : 'layouts.app';
?>

<?php $__env->startSection('content'); ?>
<?php if($header == "inside"): ?>
    <div class="content-wrapper mt-3 mb-10">
        <section>
            <div class="container mb-10">
                <div class="row">
                    <div class="col-9 m-auto p-0 mb-2">
                        <div class="alert alert-success text-center mb-0">
                            <p class="m-0 text-center">Dear <?php if(Auth::check()): ?> <?php echo e(Auth::user()->first_name.','); ?> <?php endif; ?> Your Subscription has been <?php echo e(base64_decode($subscription_status)); ?> successfully!</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-9 m-auto">
                        <div class="row success-box">
                            <div class="col-12 col-md-12 col-lf-12 text-center">
                                <img src="<?php echo e(asset('img/tick.png')); ?>" class="img-fluid w-25">
                            </div>
                            <div class="col-12 col-md-12 col-lf-12 all-padd-ing">
                                <h5>Plan: <span class="float-end"><?php echo e(Str::ucfirst(@$subscription_details->plan->name)); ?></span></h5>
                            </div>
                            <div class="col-12 col-md-12 col-lf-12 all-padd-ing">
                                <h5>Amount: <span class="float-end">$<?php echo e(@$subscription_details->plan->amount); ?> </span></h5>
                            </div>
                            <div class="col-12 col-md-12 col-lf-12 all-padd-ing">
                                <h5>Subscription Start Date: <span class="float-end"><?php echo e(date('M d, Y', strtotime($subscription_details->latestInvoice->subscription_start_date))); ?> </span></h5>
                            </div>
                            <div class="col-12 col-md-12 col-lf-12 all-padd-ing">
                                <h5>Subscription End Date: <span class="float-end"><?php echo e(date('M d, Y', strtotime($subscription_details->latestInvoice->subscription_end_date))); ?></span></h5>
                            </div>
                            <div class="col-12 col-md-12 col-lf-12 all-padd-ing">
                                <h5>Next Billing Date: <span class="float-end"><?php echo e(date('M d, Y', strtotime($subscription_details->latestInvoice->subscription_end_date))); ?></span></h5>
                            </div>
                            <div class="col-12 col-md-12 col-lf-12 all-padd-ing">
                                <h5>Subscription ID: <span class="float-end"><?php echo e($subscription_details->stripe_subscription_id); ?></span></h5>
                            </div>
                            <div class="col-12 col-md-12 col-lf-12 all-padd-ing">
                                <h5>License Key: <span class="float-end"><?php echo e($subscription_details->license_key); ?></span></h5>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-4 mb-10">
                    <div class="col-md-9 m-auto text-center">
                        <a href="<?php echo e(url('/home')); ?>" class="btn btn-dark">Dashboard</a>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php else: ?>
    <section>
        <div class="container">
            <div class="row">
                <div class="col-9 m-auto p-0 mb-2">
                    <div class="alert alert-success text-center mb-0">
                        <p class="m-0 text-center">Dear <?php if(Auth::check()): ?> <?php echo e(Auth::user()->first_name.','); ?> <?php endif; ?> Your Subscription has been <?php echo e(base64_decode($subscription_status)); ?> successfully!</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-9 m-auto">
                    <div class="row success-box">
                        <div class="col-12 col-md-12 col-lf-12 text-center">
                            <img src="<?php echo e(asset('img/tick.png')); ?>" class="img-fluid w-25">
                        </div>
                        <div class="col-12 col-md-12 col-lf-12 all-padd-ing">
                            <h5>Plan: <span class="float-end"><?php echo e(Str::ucfirst($subscription_details['plan_name'])); ?></span></h5>
                        </div>
                        <div class="col-12 col-md-12 col-lf-12 all-padd-ing">
                            <h5>Amount: <span class="float-end">$<?php echo e(@$subscription_details->plan->amount); ?> </span></h5>
                        </div>
                        <div class="col-12 col-md-12 col-lf-12 all-padd-ing">
                            <h5>Subscription Start Date: <span class="float-end"><?php echo e(date('M d, Y', strtotime($subscription_details->latestInvoice->subscription_start_date))); ?> </span></h5>
                        </div>
                        <div class="col-12 col-md-12 col-lf-12 all-padd-ing">
                            <h5>Subscription End Date: <span class="float-end"><?php echo e(date('M d, Y', strtotime($subscription_details->latestInvoice->subscription_end_date))); ?></span></h5>
                        </div>
                        <div class="col-12 col-md-12 col-lf-12 all-padd-ing">
                            <h5>Next Billing Date: <span class="float-end"><?php echo e(date('M d, Y', strtotime($subscription_details->latestInvoice->subscription_end_date))); ?></span></h5>
                        </div>
                        <div class="col-12 col-md-12 col-lf-12 all-padd-ing">
                            <h5>Subscription ID: <span class="float-end"><?php echo e($subscription_details->stripe_subscription_id); ?></span></h5>
                        </div>
                        <div class="col-12 col-md-12 col-lf-12 all-padd-ing">
                            <h5>License Key: <span class="float-end"><?php echo e($subscription_details->license_key); ?></span></h5>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-md-9 m-auto text-center">
                    <a href="<?php echo e(url('/home')); ?>" class="btn btn-dark">Dashboard</a>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp7.3\htdocs\svnbsoft\bsofttechnology\resources\views\message.blade.php ENDPATH**/ ?>