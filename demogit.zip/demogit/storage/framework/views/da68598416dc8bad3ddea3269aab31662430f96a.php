

<?php $__env->startSection('content'); ?>

<style>
       .paid-content{
    font-size: 19px;
    font-weight: 600;
    }
.heading-rec{
    font-size: 30px;
    font-weight: 600;
}

</style>

     <section class="pricing-section" >
     
           
     
          <div class="container" id="htmlContent">
          
            
              <div class="row mt-5">
                  <div class="col-12 col-md-8 col-lg-8 m-auto">
                      <h4 class="heading-rec">Receipt</h4>
                    
                      <table class="table mt-3 border-0">
                          <tbody>
                           
                            <tr>
                              <th scope="row" class="border-0">Invoice number &nbsp; &nbsp; &nbsp; &nbsp; <?php echo e($receipt_array['invoice_number']); ?><br>
                                  Receipt number &nbsp; &nbsp; &nbsp; &nbsp; <?php echo e(@$receipt_array['receipt_number']); ?><br>
                                  Date Paid    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;   <?php echo e($receipt_array['created']); ?> <br>
                                  Payment Method  &nbsp; &nbsp;   <?php echo e(strtoupper($receipt_array['cardname'])); ?> - <?php echo e($receipt_array['lastdigit']); ?>

                              </th>
                              <td class="border-0"></td>
                              <td class="border-0"></td>
                              <td class="border-0"></td>
                            </tr>
                            <tr>
                              <th scope="row" class="border-0"><?php echo e($receipt_array['account_name']); ?></th>
                              <td class="border-0">Bill to<br>
                                <?php echo e($receipt_array['customer_email']); ?></td>
                              <td class="border-0"></td>
                              <td class="border-0"></td>
                            </tr>
                            <tr>
                              <th scope="row" class="border-0"><h4 class="paid-content">$<?php echo e($receipt_array['amount_paid']/100); ?> paid on <?php echo e($receipt_array['created']); ?></h4></th>
                              <td class="border-0"></td>
                              <td class="border-0"></td>
                              <td class="border-0"></td>
                            </tr>
                          </tbody>
                        </table>
                         <?php 
                          function amount($amount)
                                {
                                   if (substr(strval($amount), 0, 1) == "-")
                                   {
                                      return '-$'.str_replace('-','',$amount);
                                   } 
                                   else 
                                   {
                                      return '$'.$amount;
                                   }
                                    
                                }
                         ?>
                      <table class="table table-bordered mt-3">
                          <thead>
                            <tr>
                              <th scope="col">Description</th>
                              <th scope="col">Qty</th>
                              <th scope="col">Unit price</th>
                              <th scope="col">Amount</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php $totalamount =0; ?>
                            <?php $__currentLoopData = $receipt_array['invoice_line_item']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php  $totalamount += $value['amount']/100;  ?>
                                <tr>
                                    <th scope="row"><?php echo e($value['description']); ?><br><?php echo e(date('M d Y',$value['start'])); ?> – <?php echo e(date('M d Y',$value['end'])); ?></th>
                                    <td>1</td>
                                    <?php if($value['amount'] > 0): ?>
                                    <td><?php echo e(amount($value['amount']/100)); ?></td>
                                    <?php else: ?>
                                    <td></td>
                                    <?php endif; ?>
                                    <td><?php echo e(amount($value['amount']/100)); ?></td>
                                </tr>
                             
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr class="p-2">
                              <th scope="row"></th>
                              <td>Subtotal</td>
                              <td></td>
                              <td><?php echo e(amount($totalamount)); ?></td>
                            </tr>
                            <tr class="p-2">
                              <th scope="row"></th>
                              <td>Total</td>
                              <td></td>
                              <td><?php echo e(amount($totalamount)); ?></td>
                            </tr>
                            <?php if(($receipt_array['starting_balance']/100) !== 0): ?>
                            <tr class="p-2">
                              <th scope="row"></th>
                              <td>Applied balance</td>
                              <td></td>
                              <td><?php echo e(amount($receipt_array['starting_balance']/100)); ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php if(($receipt_array['amount_paid']/100) !== 0): ?>
                            <tr class="p-2">
                                <th scope="row"></th>
                                <td>Amount Paid</td>
                                <td></td>
                                <td><?php echo e(amount($receipt_array['amount_paid']/100)); ?></td>
                              </tr>
                            <?php endif; ?>
                          </tbody>
                        </table>
                  </div>
              </div>
      
          </div>
    
<?php $__env->stopSection(); ?>
</section>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp7.3\htdocs\svnbsoft\bsofttechnology\resources\views\invoice.blade.php ENDPATH**/ ?>