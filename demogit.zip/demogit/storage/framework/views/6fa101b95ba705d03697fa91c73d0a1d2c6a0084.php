
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Invoices</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Invoices</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <?php echo $__env->make('includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-md-12">
                    <table class="table table-bordered table-striped" id="myTable">
                        <thead>
                            <tr>
                                <th>Package</th>
                                <th>Duration</th>
                                <th>Subscription Start Date</th>
                                <th>Subscription End Date</th>
                                <th>Card No</th>
                                <th>Status</th>
                                <th style="width: 160.8px !important;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                         
                            <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                                <tr>
                                    <td><?php echo e(Str::ucfirst(@$invoice->plan->name ?$invoice->plan->name:$deleted_plan[$invoice->plan_id]['name'])); ?></td>
                                    <td><?php echo e(Str::ucfirst(@$invoice->plan->duration?$invoice->plan->duration:$deleted_plan[$invoice->plan_id]['duration'])); ?></td>
                                    <td><?php echo e(date("M d, Y", strtotime(@$invoice->subscription_start_date))); ?></td>
                                    <td><?php echo e(date("M d, Y", strtotime(@$invoice->subscription_end_date))); ?></td>
                                    <td>**** **** **** <?php echo e(base64_decode(@$invoice->card->card_no)); ?></td>
                                    <td><?php echo e(Str::ucfirst(@$invoice->status)); ?></td>
                                    <td>
                                        <?php
                                            $details = (Array)@$invoice->invoice_details;
                                            $data = json_decode(@$details[0]); 
                                        ?>
                                        <?php if(@$data->hosted_invoice_url): ?>
                                        <a href="<?php echo e(@$data->hosted_invoice_url); ?>" target="_blank" class="btn btn-dark btn-md">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <?php else: ?>
                                        <a >
                                            Trial Period
                                        </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        $('#myTable').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appdashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp7.3\htdocs\svnbsoft\bsofttechnology\resources\views\customers\invoices.blade.php ENDPATH**/ ?>