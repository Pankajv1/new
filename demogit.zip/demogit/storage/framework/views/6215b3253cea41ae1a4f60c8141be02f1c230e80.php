<?php $__env->startSection('content'); ?>
    <section class="pricing-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="error-template" style="text-align: center;">
                        <h1 style="padding-top: 93px;">
                            Oops!</h1>
                        <h2>
                            419 Page Expired </h2>
                        <div class="error-details">
                            Sorry, an error has occured, Requested page not found!
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp7.3\htdocs\svnbsoft\bsofttechnology\resources\views/errors/419.blade.php ENDPATH**/ ?>