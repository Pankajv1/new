<!doctype html>

<html>
    <body>
            <main >
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
</html>
<?php /**PATH E:\xampp7.3\htdocs\svnbsoft\bsofttechnology\resources\views\layouts\appnew.blade.php ENDPATH**/ ?>