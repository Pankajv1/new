
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Customers</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Customers</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <?php echo $__env->make('includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-md-6">
            </div>
            <div class="col-md-6 text-right">
                <button class="btn btn-dark" data-toggle="modal" data-placement="bottom" title="Add Admin" data-target="#addUser">Add Customer</button>
            </div>
        </div>
        <div class="row mt-5" style="padding-bottom:100px !important;">
            <div class="col-md-12">
			<div class="table-responsive">
                <table class="table table-bordered table-striped" id="myTable" tyle="width:100%;">
                    <thead>
                        <tr>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Company</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->first_name); ?></td>
                                <td><?php echo e($item->last_name); ?></td>
                                <td><?php echo e($item->company_name); ?></td>
                                <td><?php echo e($item->email); ?></td>
                                <td><?php echo e($item->phone); ?></td>
                                <td>
                                    <a href="<?php echo e(url('fetch-user/' . $item->id)); ?>" data-toggle="modal" data-placement="bottom" title="Edit details" data-target="#editUser" data-id="<?php echo e($item->id); ?>" class="btn btn-secondary btn-md editbtn">
                                        <i class="fas fa-pen"></i>
                                    </a>
                                    <a href="<?php echo e(url('delete-plan/' . $item->id)); ?>" data-toggle="tooltip" data-placement="bottom" title="Delete" data-id="<?php echo e($item->id); ?>" class="btn btn-dark btn-md deletebtn">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
			 </div>	
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="addUser" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <form id="addUserForm">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Admin Details</h4>
                    <button type="button" class="close cancel" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="">First Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="first_name" id="fname" value="<?php echo e(old('name')); ?>" autofocus onkeydown="return /[a-zA-Z0-9 ]/i.test(event.key)">
                        <span id="lblError" style="color: red"></span>
                    </div>
                    <div class="form-group">
                        <label for="">Last Name</label>
                        <input type="text" class="form-control" name="last_name" value="<?php echo e(old('name')); ?>" autofocus onkeydown="return /[a-zA-Z0-9 ]/i.test(event.key)" >
                    </div>

                    <div class="form-group">
                        <label for="">Email<span class="text-danger">*</span></label>
                        <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" >
                    </div>
                    <div class="form-group">
                        <label for="">Company Name</label>
                        <input id="company_name" type="text" class="form-control" name="company_name" value="<?php echo e(old('company_name')); ?>" autofocus onkeydown="return /[a-zA-Z0-9 ]/i.test(event.key)">
                    </div>
                    <div class="form-group">
                        <label for="">Phone No.</label>
                        <input id="phone" type="text" class="form-control phone-format" name="phone" value="<?php echo e(old('phone')); ?>" autocomplete="phone">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary add_user cancel" data-dismiss="modal">Cancel</button>
                    <input type="button" value="Save" id="ajaxSubmit" class="btn btn-dark">
                </div>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="editUser" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <form id="updateUserForm">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Edit Admin Details</h4>
                    <button type="button" class="close cancelbtn" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="">First Name<span class="text-danger">*</span></label>
                        <input type="hidden" id="id_val" name="id">
                        <input type="text" class="form-control" name="first_name" id="edit_fname" value="<?php echo e(old('name')); ?>" autocomplete="name" autofocus onkeydown="return /[a-zA-Z0-9 ]/i.test(event.key)">
                    </div>
                    <div class="form-group">
                        <label for="">Last Name</label>
                        <input type="text" class="form-control" name="last_name" id="edit_lname" value="<?php echo e(old('name')); ?>" autofocus onkeydown="return /[a-zA-Z0-9 ]/i.test(event.key)" >
                    </div>

                    <div class="form-group">
                        <label for="">Email<span class="text-danger">*</span></label>
                        <input id="edit_email_address" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" >
                    </div>
                    <div class="form-group">
                        <label for="">Company Name</label>
                        <input id="edit_company_name" type="text" class="form-control" name="company_name" value="<?php echo e(old('company_name')); ?>" autofocus onkeydown="return /[a-zA-Z0-9 ]/i.test(event.key)">
                    </div>
                    <div class="form-group">
                        <label for="">Phone No.</label>
                        <input id="edit_phone" type="text" class="form-control phone-format" name="phone" value="<?php echo e(old('phone')); ?>" autocomplete="phone">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary add_user cancelbtn" data-dismiss="modal">Cancel</button>
                    <input type="submit" value="Update" id="updateUserForm" class="btn btn-dark">
                </div>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        $('#myTable').DataTable();
        $("#addUser").on("hidden.bs.modal", function(){
			  $('#fname-error').html('');
              $('#email-error').html('');
              $(this).find('form').trigger('reset');
        }); 

        jQuery.validator.addMethod("lettersonly", function(value, element) 
            {
                return this.optional(element) || /^[a-z," "]+$/i.test(value);
            }, "Letters and spaces only please");

        jQuery.validator.addMethod("customemail", 
            function(value, element) {
            return /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.((com)|(org)|(co.in)|(net))$/.test(value);
            }, 
        "Sorry, the domain extension is not allowed."
        );

        // initialize the plugin
        var validator = $('#addUserForm').validate({
            rules: {
                first_name: {
                    required: true,
                },
                email: {
                    required: true,
                    customemail: true,
                },
            },
            messages: {
                first_name: {
                    required: "First Name is required.",
                },
                email: {
                    required: "Email is required",
                    customemail: "Please enter a valid email address."
                },
            },
            errorPlacement: function(label, element) {
                label.addClass(' text-danger');
                element.parent().append(label);

            },
        });
        $(".cancel").click(function() {
            validator.resetForm();
        });

       $(".phone-format").keypress(function (e) {
    if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
      return false;
    }
    var curchr = this.value.length;
    var curval = $(this).val();
    if (curchr == 3 && curval.indexOf("(") <= -1) {
      $(this).val("+1(" + curval + ")" + "-");
    } else if (curchr == 4 && curval.indexOf("(") > -1) {
      $(this).val(curval + ")-");
    } else if (curchr == 5 && curval.indexOf(")") > -1) {
      $(this).val(curval + "-");
    } else if (curchr == 9) {
      $(this).val(curval + "-");
        $(this).attr('maxlength', '18');
    }
  });

    });

    jQuery('#ajaxSubmit').click(function(e) {
        e.preventDefault();

        if ($('#addUserForm').valid() == false) {
            return false;
        }

        let formData = $('#addUserForm').serialize();
        
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            }
        });

        jQuery.ajax({
            url: "<?php echo e(url('saveuser')); ?>",
            dataType: "json",
            method: 'post',
            data: formData,
            beforeSend:function() {
                swal({
                    title: "Processing",
                    text: 'Please Wait...',
                    buttons:false,
                    icon: "warning",
                    allowOutsideClick: false,
                    allowEscapeKey: false
                });
            },
            success: function(result) {
                swal.close();
                if (result.status) {
                    swal({
                        title: "Done",
                        text: result.message, 
                        icon: "success",
                        closeOnClickOutside: false,
                        dangerMode: false,
                    })
                    .then((willDelete) => {
                        if (willDelete) {
                            location.reload();
                        }
                    });
                } else {
                    swal("Oops!", result.message, 'error');
                    swal({
                        title: "Oops!",
                        text: result.message, 
                        icon: "error",
                        closeOnClickOutside: false,
                        dangerMode: false,
                    })
                    .then((willDelete) => {
                        if (willDelete) {
                           
                        }
                    });
                }  
            },
            error: function(error) {
                swal({
                    title: "Oops!",
                    text: "Something went wrong. Try again later.", 
                    icon: "error",
                    closeOnClickOutside: false,
                    dangerMode: false,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        //location.reload();
                    }
                });
            }
        });
    });

    $(document).on('click','.editbtn',function(e) {
        // alert("here");
        // e.preventDefault();
        let id = $(this).attr('data-id');
            
            $.ajax({
                url : "<?php echo e(url('fetch-user')); ?>",
                type: 'GET',
                data : {
                    id:id,
                  _token:"<?php echo e(csrf_token()); ?>"
                },
                success:function(output) {
                    console.log(output);
                    if (output.status) {
                      // alert(output.data.password)
                      $('#id_val').val(output.data.id);
                      $('#edit_fname').val(output.data.first_name);
                      $('#edit_lname').val(output.data.last_name);
                      $('#edit_email_address').val(output.data.email);
                      $('#edit_company_name').val(output.data.company_name);
                      $('#edit_phone').val(output.data.phone);

                      $('#editUser').css('display','block');
                      $('#editUser').addClass('show');
                    }
                },
                error:function(err) {
                  alert(err);
                }
            });
    });  

    $(document).ready(function(){

        jQuery.validator.addMethod("customemail", 
            function(value, element) {
            return /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.((com)|(org)|(co.in)|(net))$/.test(value);
            }, 
        "Sorry, the domain extension is not allowed."
        );
        var validates = $('#updateUserForm').validate({
            rules: {
                first_name: {
                    required: true,
                },
                email: {
                    required: true,
                    customemail: true
                },
            },
            messages: {
                first_name: {
                    required: "First Name is required.",
                },
                email: {
                    required: "Email is required",
                    customemail: "Please enter a valid email address."
                },
            },
            errorPlacement: function(label, element) {
                label.addClass(' text-danger');
                element.parent().append(label);

            },
        });
        $(".cancelbtn").click(function() {
            validates.resetForm();
        });
        
    });
    


    $(document).on('submit','#updateUserForm',function(e) {
        // alert('here');

        e.preventDefault();
        
        if ($('#updateUserForm').valid() == false) {
            return false;
        }

        var form = $('#updateUserForm')[0];
        let formData = new FormData(form);
            
        formData.append('_token',"<?php echo e(csrf_token()); ?>");

        $.ajax({
            url : "<?php echo e(url('update-user')); ?>",
            type: 'post',
            data : formData,
            contentType: false,
            cache: false,
            processData:false,
            beforeSend:function() {
                swal({
                    title: "Processing",
                    text: 'Please Wait...',
                    buttons:false,
                    icon: "warning",
                    allowOutsideClick: false,
                    allowEscapeKey: false
                });
            },
            success: function(output) {
                swal.close();
                if (output.status) {
                    swal({
                        title: "Done",
                        text: output.message, 
                        icon: "success",
                        closeOnClickOutside: false,
                        dangerMode: false,
                    })
                    .then((willDelete) => {
                        if (willDelete) {
                            location.reload();
                        }
                    });
                } else {
                    swal("Oops!", output.message, 'error');
                    swal({
                        title: "Oops!",
                        text: output.message, 
                        icon: "error",
                        closeOnClickOutside: false,
                        dangerMode: false,
                    })
                    .then((willDelete) => {
                        if (willDelete) {
                           // location.reload();
                        }
                    });
                }  
            },
            error: function(error) {
                swal({
                    title: "Oops!",
                    text: "Something went wrong. Try again later.", 
                    icon: "error",
                    closeOnClickOutside: false,
                    dangerMode: false,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        //location.reload();
                    }
                });
            }
        });

    });

    $(document).on('click', '.deletebtn', function (e) {
        //    alert('here');
        e.preventDefault();
        let id = $(this).attr('data-id');

        swal({
            title: "Are you sure you want to delete?",
            text: "Once deleted, you will not be able to recover this record!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
            })
            .then((willDelete) => {
            if (willDelete) {
                $.ajax({
                    type: "post",
                    data : {
                            id:id,
                            _token:"<?php echo e(csrf_token()); ?>"
                        },
                    url: "<?php echo e(url('delete-user')); ?>",
                    
                    success: function (output){
                        
                        if (output.status) {
                            swal("Your record has been deleted Successfully!", {
                            icon: "success",
                            }).then(function(){ 
                                location.reload();
                            });
                            // location.reload();
                        } else {
                            alert(output.message);
                        }
                    
                    },
                    error: function (output) {
                        console.log('Error:', output);
                    }
                });
            } else {
                //swal("Your record is safe!");
            }
        });          
    });   


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appdashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp7.3\htdocs\svnbsoft\bsofttechnology\resources\views\admin\customer\index.blade.php ENDPATH**/ ?>