
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="pricing-section mb-5">
            <div class="sec-title p-4 text">
                <h2 class="d-inline"><?php echo e(($subscription !== null) ? 'My Active' : 'Purchase'); ?> Subscription</h2>
                <?php if($subscription !== null): ?><h2 class="d-inline" style="float: right;">License Key :   <div id="license" style="display:none;"><?php echo e($subscription->license_key); ?></div><span style="font-size: 20px;"><?php echo e(substr($subscription->license_key, 0, 5)); ?>....<span><button id="lisence_key_copy" class="btn btn-dark"  onclick="copyText('license');" >Copy</button></h2><?php endif; ?>
            </div>
            <div class="container mt-3">
               
                <div class="outer-box">
                    <div class="row">
                        <div class="col-lg-9 col-md-5 col-sm-5 text-bold m-auto mt-2 mb-1">
                            <?php echo $__env->make('includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <ul class="nav nav-pills mb-3 m-auto d-flex justify-content-center align-items-center" id="pills-tab" role="tablist">
                           
                            <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($subscription !== null && $plan->id == $subscription->plan_id || $plan->status == "Active"): ?>
                                    <li class="nav-item  col-lg-3 col-md-6 col-sm-12" role="presentation">
                                        <a class="nav-link <?php echo e(($subscription === null && $key+1 == 1) ? 'active': ($subscription !== null && $plan->id == $subscription->plan_id) ? 'active' : ''); ?> w-100" id="pills-<?php echo e($key+1); ?>-tab" data-bs-toggle="pill" data-bs-target="#plan-<?php echo e($key+1); ?>" type="button" role="tab" aria-controls="pills-home" aria-selected="false">
                                            <div class="row card-design m-auto" id="bg<?php echo e($key+1); ?>">
                                                <div class="col-4 col-lg-5 col-md-5 col-sm-12">
                                                    <div class="icon-box" id="bg<?php echo e($key+1); ?>-icon">
                                                        <i class="fas fa-dollar-sign"></i>
                                                    </div>
                                                </div>
                                                <div class="price-box col-8 col-lg-7 col-md-7 col-sm-12 p-0">
                                                    <div class="card-content">
                                                        <div class="main-content text-dark"><?php echo e(Str::ucfirst($plan->name)); ?></div>
                                                        <h4 class="sub-content">$<?php echo e($plan->amount); ?></h4>
                                                        <h4 class="sub-content">
                                                            <?php if($plan->duration == "week" || $plan->duration == "month" || $plan->duration == "yesr"): ?>
                                                                <?php echo e(Str::ucfirst($plan->duration)."ly"); ?>

                                                            <?php else: ?>
                                                                <?php echo e(Str::ucfirst($plan->duration)); ?>

                                                            <?php endif; ?>
                                                        </h4>
                                                    </div>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                           
                        <div class="col-lg-5 col-md-5 col-sm-5 text-center m-auto mt-4 mb-5">
                            <div class="tab-content" id="pills-tabContent">
                                <?php if($delete_plan != null): ?>
                                <?php $__currentLoopData = $delete_plan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($subscription !== null && $plan->id == $subscription->plan_id || $plan->status == "Active"): ?>
                                    <div class="tab-pane fade show <?php echo e(($subscription === null && $key == 1) ? 'active': ($subscription !== null && $plan->id == $subscription->plan_id) ? 'active' : ''); ?>" id="plan-<?php echo e($key); ?>" role="tabpanel" aria-labelledby="pills-<?php echo e($key); ?>-tab">
                                        <div class="row m-auto main-contnt-box ">
                                            <div class="col-lg-12 col-md-12 col-sm-12 d-flex justify-content-center">
                                                <div class="main-content-iconset">
                                                    <i class="fas fa-dollar-sign"></i>
                                                </div>
                                            </div>
                                            <div class="price-box col-lg-12 col-md-12 col-sm-12 p-0">
                                                <div class="card-content p-0 m-0 ml-2 text-center">
                                                    <h2 class="tab-main-subcontent p-2 fbig-globe">$<?php echo e($plan->amount); ?>/<span><?php echo e(Str::ucfirst($plan->name)); ?></span></h2>
                                                    <?php $__currentLoopData = json_decode($plan->features); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <hr>
                                                        <div class="tab-main-content p-1">
                                                            <h4><?php echo e($feature); ?></h4>
                                                        </div>    
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($subscription != null && $plan->id == $subscription->plan_id): ?>
                                                        <hr>
                                                        <div class="tab-main-content p-1">
                                                            <h4>Start Date - <?php echo e(date("M d, Y", strtotime($subscription->latestInvoice->subscription_start_date))); ?></h4>
                                                        </div>
                                                        <hr>
                                                        <div class="tab-main-content p-1">
                                                            <h4>End Date - <?php echo e(date("M d, Y", strtotime($subscription->latestInvoice->subscription_end_date))); ?></h4>
                                                        </div>
                                                        <hr>
                                                        <div class="tab-main-content p-1">
                                                            <h4>Next Billing Date - <?php echo e(date("M d, Y", strtotime($subscription->latestInvoice->subscription_end_date))); ?></h4>
                                                        </div>
                                                    <?php endif; ?>
                                                    <hr>
                                                    <div class="tab-main-content p-1">
                                                        <h4>No. of Domains - <?php echo e($plan->no_of_domains); ?></h4>
                                                    </div>
                                                    <hr>
                                                    <div class="mt-4 mb-2">
                                                    
                                                        <?php if($subscription != null && $plan->id == $subscription->plan_id): ?>
              
                                                            <a href="<?php echo e(route('invoices')); ?>" class="btn btn-dark">Invoices</a>
                                                            <a href="<?php echo e(route('cancel.plan', [base64_encode($subscription->id)])); ?>" class="btn btn-secondary" onclick="cancelConfirmation(event)" data-subscription-id="<?php echo e($subscription->id); ?>">Cancel Subscription</a>
                                                        <?php else: ?> 
                                                            <a  href="<?php echo e(route('show.update.newplan', [base64_encode($plan->id)])); ?>" class="btn btn-dark" class="btn btn-dark">Subscribe</a>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                                <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($subscription !== null && $plan->id == $subscription->plan_id || $plan->status == "Active"): ?>
                                        <div class="tab-pane fade show <?php echo e(($subscription === null && $key+1 == 1) ? 'active': ($subscription !== null && $plan->id == $subscription->plan_id) ? 'active' : ''); ?>" id="plan-<?php echo e($key+1); ?>" role="tabpanel" aria-labelledby="pills-<?php echo e($key+1); ?>-tab">
                                            <div class="row m-auto main-contnt-box ">
                                                <div class="col-lg-12 col-md-12 col-sm-12 d-flex justify-content-center">
                                                    <div class="main-content-iconset">
                                                        <i class="fas fa-dollar-sign"></i>
                                                    </div>
                                                </div>
                                                <div class="price-box col-lg-12 col-md-12 col-sm-12 p-0">
                                                    <div class="card-content p-0 m-0 ml-2 text-center">
                                                        <h2 class="tab-main-subcontent p-2 fbig-globe">$<?php echo e($plan->amount); ?>/<span><?php echo e(Str::ucfirst($plan->name)); ?></span></h2>
                                                        <?php $__currentLoopData = json_decode($plan->features); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <hr>
                                                            <div class="tab-main-content p-1">
                                                                <h4><?php echo e($feature); ?></h4>
                                                            </div>    
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($subscription != null && $plan->id == $subscription->plan_id): ?>
                                                            <hr>
                                                            <div class="tab-main-content p-1">
                                                                <h4>Start Date - <?php echo e(date("M d, Y", strtotime($subscription->latestInvoice->subscription_start_date))); ?></h4>
                                                            </div>
                                                            <hr>
                                                            <div class="tab-main-content p-1">
                                                                <h4>End Date - <?php echo e(date("M d, Y", strtotime($subscription->latestInvoice->subscription_end_date))); ?></h4>
                                                            </div>
                                                            <hr>
                                                            <div class="tab-main-content p-1">
                                                                <h4>Next Billing Date - <?php echo e(date("M d, Y", strtotime($subscription->latestInvoice->subscription_end_date))); ?></h4>
                                                            </div>
                                                        <?php endif; ?>
                                                        <hr>
                                                        <div class="tab-main-content p-1">
                                                            <h4>No. of Domains - <?php echo e($plan->no_of_domains); ?></h4>
                                                        </div>
                                                        <hr>
                                                        <div class="mt-4 mb-2">
                                                        
                                                            <?php if($subscription != null && $plan->id == $subscription->plan_id): ?>
                                                              <?php if($plan->duration !="trial"): ?>
                                                                <a href="<?php echo e(route('show.update.plan', [base64_encode($subscription->id)])); ?>" class="btn btn-dark">Update Card</a>
                                                              <?php endif; ?>
                                                                <a href="<?php echo e(route('invoices')); ?>" class="btn btn-dark">Invoices</a>
                                                                <a href="<?php echo e(route('cancel.plan', [base64_encode($subscription->id)])); ?>" class="btn btn-secondary" onclick="cancelConfirmation(event)" data-subscription-id="<?php echo e($subscription->id); ?>">Cancel Subscription</a>
                                                            <?php else: ?> 
                                                                <?php if($plan->duration =="trial"): ?>
                                                                <a  href="<?php echo e(route('show.update.trialplan', [base64_encode($plan->id)])); ?>" class="btn btn-dark" class="btn btn-dark">Subscribe</a>
                                                                <?php else: ?>
                                                                <a  href="<?php echo e(route('show.update.newplan', [base64_encode($plan->id)])); ?>" class="btn btn-dark" class="btn btn-dark">Subscribe</a>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    function cancelConfirmation(ev) {
        ev.preventDefault();
        var urlToRedirect = ev.currentTarget.getAttribute('href'); // use currentTarget because the click may be on the nested i tag and not a tag causing the href to be empty
        console.log(urlToRedirect); // verify if this is the right URL
        swal({
            title: "Are you sure you want to delete?",
            text: "After cancelling the subscription the associated license key will expire.",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
        .then((willDelete) => {
            // redirect with javascript here as per your logic after showing the alert using the urlToRedirect value
            if (willDelete) {
                window.location.href = urlToRedirect;
            }
        });
    }
    function copyText(element) {
  var $copyText = document.getElementById(element).innerText;
  
  var button = document.getElementById('lisence_key_copy');
  navigator.clipboard.writeText($copyText).then(function() {
    var originalText = button.innerText;
    button.innerText = 'Copied!';
    setTimeout(function(){
      button.innerText = originalText;
      }, 750);
  }, function() {
    button.style.cssText = "background-color: var(--red);";
    button.innerText = 'Error';
  });
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appdashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp7.3\htdocs\svnbsoft\bsofttechnology\resources\views/customers/my-plans.blade.php ENDPATH**/ ?>